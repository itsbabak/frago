package net.typeblog.socks;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.ServiceConnection;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.IBinder;
import android.os.SystemClock;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.ListPreference;
import android.preference.PreferenceCategory;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.widget.CompoundButton;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import net.typeblog.socks.util.Profile;
import net.typeblog.socks.util.ProfileManager;
import net.typeblog.socks.util.UniversalProxyRelay;
import net.typeblog.socks.util.Utility;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

import static net.typeblog.socks.util.Constants.*;

public class ProfileFragment extends PreferenceFragment implements Preference.OnPreferenceClickListener, Preference.OnPreferenceChangeListener,
        CompoundButton.OnCheckedChangeListener {
    private ProfileManager mManager;
    private Profile mProfile;

    private Switch mSwitch;
    private boolean mRunning = false;
    private boolean mStarting = false, mStopping = false;
    private final Handler mStopHandler = new Handler(Looper.getMainLooper());
    private final Runnable mStopTimeout = new Runnable() {
        @Override public void run() {
            if (!mStopping) return;
            mRunning = false;
            updateState();
        }
    };
    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName p1, IBinder binder) {
            mBinder = IVpnService.Stub.asInterface(binder);
            try {
                mRunning = mBinder.isRunning();
            } catch (Exception ignored) { mRunning = false; }
            if (mStarting && !mRunning) {
                keepSwitchOnWhileStarting();
                return;
            }
            updateState();
        }

        @Override
        public void onServiceDisconnected(ComponentName p1) {
            mBinder = null;
            mRunning = false;
            if (mStarting) {
                keepSwitchOnWhileStarting();
            } else {
                updateState();
            }
        }
    };
    private IVpnService mBinder;

    private ListPreference mPrefProfile;
    private EditTextPreference mPrefTlsPositions;
    private Preference mPrefDesyncMode;
    private ListPreference mPrefFakeTtl;
    private ListPreference mPrefTlsCount;
    private Preference mPrefDnsHosts;
    private Preference mPrefAppList;
    private Preference mPrefPingTest;
    private volatile boolean mPinging = false;

    // Protocol & Outbound Preferences
    private PreferenceCategory mProtoCategory;
    private ListPreference mPrefProtocol;
    private Preference mPrefImportUri;
    private EditTextPreference mPrefServer;
    private EditTextPreference mPrefPort;
    private EditTextPreference mPrefUsername;
    private ListPreference mPrefSsMethod;
    private EditTextPreference mPrefPassword;
    private EditTextPreference mPrefVlessSni;
    private EditTextPreference mPrefVlessWsPath;
    private CheckBoxPreference mPrefVlessTls;
    private CheckBoxPreference mPrefChainFragment;

    private PreferenceCategory mTlsCategory, mDnsCategory, mAdvancedCategory;
    private android.preference.PreferenceScreen mScreen;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings);
        mScreen = getPreferenceScreen();
        mScreen.setOrderingAsAdded(false);
        setHasOptionsMenu(true);
        mManager = new ProfileManager(getActivity().getApplicationContext());
        initPreferences();
        reload();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.main, menu);

        MenuItem s = menu.findItem(R.id.switch_main);
        mSwitch = s.getActionView().findViewById(R.id.switch_action_button);
        mSwitch.setOnCheckedChangeListener(this);
        checkState();
    }

    @Override public void onResume() {
        super.onResume();
        if (!mReceiverRegistered && getActivity() != null) {
            IntentFilter filter = new IntentFilter(SocksVpnService.ACTION_STATE);
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                getActivity().registerReceiver(mStateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                getActivity().registerReceiver(mStateReceiver, filter);
            }
            mReceiverRegistered = true;
        }
        if (mSwitch != null) checkState();
    }

    @Override public void onPause() {
        if (mReceiverRegistered && getActivity() != null) {
            try { getActivity().unregisterReceiver(mStateReceiver); } catch (Exception ignored) { }
            mReceiverRegistered = false;
        }
        if (mBound && getActivity() != null) {
            try { getActivity().unbindService(mConnection); } catch (Exception ignored) { }
            mBound = false; mBinder = null;
        }
        super.onPause();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.prof_add) {
            addProfile();
            return true;
        } else if (id == R.id.prof_del) {
            removeProfile();
            return true;
        } else if (id == R.id.prof_rename) {
            renameProfile();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onPreferenceClick(Preference p) {
        if (p == mPrefAppList) { showAppPicker(); return true; }
        if (p == mPrefDnsHosts) { showDnsHostEditor(); return true; }
        if (p == mPrefPingTest) { runPingTest(); return true; }
        if (p == mPrefImportUri) { showUriImportDialog(); return true; }
        return false;
    }

    @Override
    public boolean onPreferenceChange(Preference p, Object newValue) {
        if (p == mPrefProfile) {
            String name = newValue.toString();
            mProfile = mManager.getProfile(name);
            mManager.switchDefault(name);
            reload();
            return true;
        } else if (p == mPrefProtocol) {
            String proto = newValue.toString();
            mProfile.setProtocol(proto);
            // Independent by default: disable fragment unless explicitly checked
            if (!UniversalProxyRelay.PROTO_BYEDPI.equals(proto)) {
                mProfile.setChainFragmentEnabled(false);
            }
            if (UniversalProxyRelay.PROTO_SHADOWSOCKS.equals(proto) && mProfile.getUsername().isEmpty()) {
                mProfile.setUsername("aes-256-gcm");
            }
            reload();
            return true;
        } else if (p == mPrefServer) {
            String host = newValue.toString().trim();
            mProfile.setServer(host);
            mPrefServer.setSummary(host.isEmpty() ? "Not set" : host);
            return true;
        } else if (p == mPrefPort) {
            try {
                int port = Integer.parseInt(newValue.toString().trim());
                if (port < 1 || port > 65535) throw new NumberFormatException();
                mProfile.setPort(port);
                mPrefPort.setSummary(Integer.toString(port));
                return true;
            } catch (Exception e) {
                Toast.makeText(getActivity(), "Invalid port (1-65535)", Toast.LENGTH_SHORT).show();
                return false;
            }
        } else if (p == mPrefUsername) {
            String u = newValue.toString().trim();
            mProfile.setUsername(u);
            mPrefUsername.setSummary(u.isEmpty() ? "Optional" : u);
            return true;
        } else if (p == mPrefSsMethod) {
            String m = newValue.toString();
            mProfile.setUsername(m);
            mPrefSsMethod.setSummary(m);
            return true;
        } else if (p == mPrefPassword) {
            String pass = newValue.toString().trim();
            mProfile.setPassword(pass);
            updatePasswordSummary();
            return true;
        } else if (p == mPrefVlessSni) {
            String sni = newValue.toString().trim();
            mProfile.setVlessSni(sni);
            mPrefVlessSni.setSummary(sni.isEmpty() ? "Same as server host" : sni);
            return true;
        } else if (p == mPrefVlessWsPath) {
            String path = newValue.toString().trim();
            mProfile.setVlessWsPath(path);
            mPrefVlessWsPath.setSummary(path.isEmpty() ? "Empty (Raw TCP mode)" : path);
            return true;
        } else if (p == mPrefVlessTls) {
            boolean tls = Boolean.parseBoolean(newValue.toString());
            mProfile.setVlessTls(tls);
            updateProtocolVisibility();
            return true;
        } else if (p == mPrefChainFragment) {
            boolean chain = Boolean.parseBoolean(newValue.toString());
            mProfile.setChainFragmentEnabled(chain);
            updateProtocolVisibility();
            return true;
        } else if (p == mPrefTlsCount) {
            try {
                int records = Integer.parseInt(newValue.toString());
                if (records < 1 || records > 16) throw new IllegalArgumentException("Choose between 1 and 16 TLS records");
                String positions = net.typeblog.socks.util.ByeDpiSettings.defaultPositionsForRecordCount(records);
                mProfile.setTlsRecordPositions(positions);
                if (mPrefTlsPositions != null) mPrefTlsPositions.setText(positions);
                if (mPrefTlsCount != null) {
                    mPrefTlsCount.setValue(Integer.toString(records));
                    resetList(mPrefTlsCount);
                }
                updateTlsSummary();
                updateDesyncSummary();
                return true;
            } catch (Exception error) {
                Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_LONG).show();
                return false;
            }
        } else if (p == mPrefTlsPositions) {
            try {
                String normalized = net.typeblog.socks.util.ByeDpiSettings.normalizePositions(newValue.toString());
                mProfile.setTlsRecordPositions(normalized);
                if (mPrefTlsCount != null) mPrefTlsCount.setValue(Integer.toString(net.typeblog.socks.util.ByeDpiSettings.recordCount(normalized)));
                updateTlsSummary();
                return true;
            } catch (IllegalArgumentException error) {
                Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_LONG).show();
                return false;
            }
        } else if (p == mPrefDesyncMode) {
            String mode = net.typeblog.socks.util.ByeDpiSettings.normalizeDesyncMode(newValue.toString());
            mProfile.setDesyncMode(mode);
            updateDesyncSummary();
            return true;
        } else if (p == mPrefFakeTtl) {
            try {
                int ttl = net.typeblog.socks.util.ByeDpiSettings.normalizeFakeTtl(Integer.parseInt(newValue.toString()));
                mProfile.setFakeTtl(ttl);
                mPrefFakeTtl.setValue(Integer.toString(ttl));
                mPrefFakeTtl.setSummary("TTL = " + ttl);
                return true;
            } catch (Exception error) {
                Toast.makeText(getActivity(), "Invalid TTL", Toast.LENGTH_SHORT).show();
                return false;
            }
        } else {
            return false;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton p1, boolean checked) {
        if (mStarting || mStopping) {
            if (mSwitch != null) {
                mSwitch.setOnCheckedChangeListener(null);
                mSwitch.setChecked(mRunning || mStarting);
                mSwitch.setOnCheckedChangeListener(this);
            }
            return;
        }
        if (checked) {
            startVpn();
        } else {
            stopVpn();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 0) return;
        if (resultCode == Activity.RESULT_OK) {
            try {
                Utility.startVpn(getActivity(), mProfile);
                checkState();
            } catch (Exception error) {
                Toast.makeText(getActivity(), R.string.connection_start_failed, Toast.LENGTH_LONG).show();
                resetMainSwitch();
            }
        } else {
            mRunning = false;
            updateState();
        }
    }

    private void initPreferences() {
        Activity ctx = getActivity();
        mPrefProfile = (ListPreference) findPreference(PREF_PROFILE);
        mAdvancedCategory = (PreferenceCategory) findPreference("advanced");
        mPrefAppList = findPreference(PREF_ADV_APP_LIST);

        if (mAdvancedCategory != null) {
            CheckBoxPreference prefPerApp = (CheckBoxPreference) findPreference(PREF_ADV_PER_APP);
            CheckBoxPreference prefAppBypass = (CheckBoxPreference) findPreference(PREF_ADV_APP_BYPASS);
            CheckBoxPreference prefAuto = (CheckBoxPreference) findPreference(PREF_ADV_AUTO_CONNECT);
            if (prefPerApp != null) mAdvancedCategory.removePreference(prefPerApp);
            if (prefAppBypass != null) mAdvancedCategory.removePreference(prefAppBypass);
            if (prefAuto != null) mAdvancedCategory.removePreference(prefAuto);

            if (ctx != null) {
                mPrefPingTest = new Preference(ctx);
                mPrefPingTest.setKey("ping_delay_test");
                mPrefPingTest.setTitle("Test Connection (Ping Delay)");
                mPrefPingTest.setSummary("Tap to measure real HTTPS delay");
                mPrefPingTest.setPersistent(false);
                mPrefPingTest.setOnPreferenceClickListener(this);
                mAdvancedCategory.addPreference(mPrefPingTest);
            }
        }

        if (mPrefAppList != null) {
            mPrefAppList.setTitle("Bypass Apps (Exclude from VPN)");
        }

        // Build Outbound Protocol Category dynamically
        if (ctx != null && mScreen != null) {
            mProtoCategory = new PreferenceCategory(ctx);
            mProtoCategory.setKey("outbound_protocol_category");
            mProtoCategory.setTitle("Connection Protocol");
            mScreen.addPreference(mProtoCategory);

            mPrefProtocol = new ListPreference(ctx);
            mPrefProtocol.setKey("outbound_protocol");
            mPrefProtocol.setTitle("Protocol Mode");
            mPrefProtocol.setEntries(new CharSequence[]{
                    "ByeDPI (TLS Record + TCP OOB)",
                    "SOCKS5 Proxy",
                    "HTTP / HTTPS Proxy",
                    "Shadowsocks (AEAD)",
                    "VLESS (TCP / WS + TLS)"
            });
            mPrefProtocol.setEntryValues(new CharSequence[]{
                    UniversalProxyRelay.PROTO_BYEDPI,
                    UniversalProxyRelay.PROTO_SOCKS5,
                    UniversalProxyRelay.PROTO_HTTP,
                    UniversalProxyRelay.PROTO_SHADOWSOCKS,
                    UniversalProxyRelay.PROTO_VLESS
            });
            mPrefProtocol.setPersistent(false);
            mPrefProtocol.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefProtocol);

            mPrefImportUri = new Preference(ctx);
            mPrefImportUri.setKey("import_proxy_uri");
            mPrefImportUri.setTitle("Import Proxy Link (URI)");
            mPrefImportUri.setSummary("Paste vless://, ss://, socks5:// or http:// link");
            mPrefImportUri.setPersistent(false);
            mPrefImportUri.setOnPreferenceClickListener(this);
            mProtoCategory.addPreference(mPrefImportUri);

            mPrefServer = new EditTextPreference(ctx);
            mPrefServer.setKey("outbound_server");
            mPrefServer.setTitle("Server Address / IP");
            mPrefServer.getEditText().setSingleLine(true);
            mPrefServer.getEditText().setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            mPrefServer.setPersistent(false);
            mPrefServer.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefServer);

            mPrefPort = new EditTextPreference(ctx);
            mPrefPort.setKey("outbound_port");
            mPrefPort.setTitle("Server Port");
            mPrefPort.getEditText().setSingleLine(true);
            mPrefPort.getEditText().setInputType(InputType.TYPE_CLASS_NUMBER);
            mPrefPort.setPersistent(false);
            mPrefPort.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefPort);

            mPrefSsMethod = new ListPreference(ctx);
            mPrefSsMethod.setKey("ss_cipher_method");
            mPrefSsMethod.setTitle("Encryption Method");
            mPrefSsMethod.setEntries(new CharSequence[]{"aes-256-gcm", "aes-128-gcm", "chacha20-ietf-poly1305"});
            mPrefSsMethod.setEntryValues(new CharSequence[]{"aes-256-gcm", "aes-128-gcm", "chacha20-ietf-poly1305"});
            mPrefSsMethod.setPersistent(false);
            mPrefSsMethod.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefSsMethod);

            mPrefUsername = new EditTextPreference(ctx);
            mPrefUsername.setKey("outbound_username");
            mPrefUsername.setTitle("Username");
            mPrefUsername.getEditText().setSingleLine(true);
            mPrefUsername.setPersistent(false);
            mPrefUsername.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefUsername);

            mPrefPassword = new EditTextPreference(ctx);
            mPrefPassword.setKey("outbound_password");
            mPrefPassword.setTitle("Password / UUID");
            mPrefPassword.getEditText().setSingleLine(true);
            mPrefPassword.getEditText().setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            mPrefPassword.setPersistent(false);
            mPrefPassword.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefPassword);

            mPrefVlessTls = new CheckBoxPreference(ctx);
            mPrefVlessTls.setKey("vless_tls_enabled");
            mPrefVlessTls.setTitle("Enable TLS");
            mPrefVlessTls.setSummary("Encrypt transport with TLS");
            mPrefVlessTls.setPersistent(false);
            mPrefVlessTls.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefVlessTls);

            mPrefVlessSni = new EditTextPreference(ctx);
            mPrefVlessSni.setKey("vless_sni");
            mPrefVlessSni.setTitle("SNI (Server Name)");
            mPrefVlessSni.getEditText().setSingleLine(true);
            mPrefVlessSni.getEditText().setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            mPrefVlessSni.setPersistent(false);
            mPrefVlessSni.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefVlessSni);

            mPrefVlessWsPath = new EditTextPreference(ctx);
            mPrefVlessWsPath.setKey("vless_ws_path");
            mPrefVlessWsPath.setTitle("WebSocket Path");
            mPrefVlessWsPath.getEditText().setSingleLine(true);
            mPrefVlessWsPath.setPersistent(false);
            mPrefVlessWsPath.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefVlessWsPath);

            mPrefChainFragment = new CheckBoxPreference(ctx);
            mPrefChainFragment.setKey("chain_fragment_enabled");
            mPrefChainFragment.setTitle("Use Fragment (TLS Record + TCP OOB)");
            mPrefChainFragment.setSummary("Off = Independent protocol · On = Route through ByeDPI fragment");
            mPrefChainFragment.setPersistent(false);
            mPrefChainFragment.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefChainFragment);
        }

        mTlsCategory = (PreferenceCategory) findPreference("tls_fragment_category");
        mDnsCategory = (PreferenceCategory) findPreference("dns_override_category");
        mPrefTlsCount = (ListPreference) findPreference("tlsrec_count");
        mPrefTlsPositions = (EditTextPreference) findPreference("tlsrec_positions");
        mPrefDesyncMode = findPreference("desync_mode");
        mPrefFakeTtl = (ListPreference) findPreference("fake_ttl");
        mPrefDnsHosts = findPreference("dns_host_overrides");
        if (mPrefTlsCount != null) mPrefTlsCount.setPersistent(false);
        if (mPrefTlsPositions != null) mPrefTlsPositions.setPersistent(false);
        if (mPrefFakeTtl != null) mPrefFakeTtl.setPersistent(false);
        if (mPrefDnsHosts != null) mPrefDnsHosts.setPersistent(false);

        if (mPrefProfile != null) mPrefProfile.setOnPreferenceChangeListener(this);
        if (mPrefAppList != null) mPrefAppList.setOnPreferenceClickListener(this);
        if (mPrefTlsCount != null) mPrefTlsCount.setOnPreferenceChangeListener(this);
        if (mPrefTlsPositions != null) mPrefTlsPositions.setOnPreferenceChangeListener(this);
        if (mPrefFakeTtl != null) mPrefFakeTtl.setOnPreferenceChangeListener(this);
        if (mPrefDnsHosts != null) mPrefDnsHosts.setOnPreferenceClickListener(this);
    }

    private void reload() {
        if (mProfile == null) mProfile = mManager.getDefault();
        if (mProfile == null) return;
        mProfile.setAutoConnect(true);
        syncBypassStateWithAppList();
        if (mPrefProfile != null) {
            mPrefProfile.setEntries(mManager.getProfiles());
            mPrefProfile.setEntryValues(mManager.getProfiles());
            mPrefProfile.setValue(mProfile.getName());
            resetList(mPrefProfile);
        }

        String proto = mProfile.getProtocol();
        if (mPrefProtocol != null) {
            mPrefProtocol.setValue(proto);
            resetList(mPrefProtocol);
        }
        if (mPrefServer != null) {
            mPrefServer.setText(mProfile.getServer());
            mPrefServer.setSummary(mProfile.getServer().isEmpty() ? "Not set" : mProfile.getServer());
        }
        if (mPrefPort != null) {
            mPrefPort.setText(Integer.toString(mProfile.getPort()));
            mPrefPort.setSummary(Integer.toString(mProfile.getPort()));
        }
        if (mPrefSsMethod != null) {
            String method = mProfile.getUsername().isEmpty() ? "aes-256-gcm" : mProfile.getUsername();
            mPrefSsMethod.setValue(method);
            mPrefSsMethod.setSummary(method);
        }
        if (mPrefUsername != null) {
            mPrefUsername.setText(mProfile.getUsername());
            mPrefUsername.setSummary(mProfile.getUsername().isEmpty() ? "Optional" : mProfile.getUsername());
        }
        if (mPrefPassword != null) {
            mPrefPassword.setText(mProfile.getPassword());
            updatePasswordSummary();
        }
        if (mPrefVlessTls != null) mPrefVlessTls.setChecked(mProfile.isVlessTls());
        if (mPrefVlessSni != null) {
            mPrefVlessSni.setText(mProfile.getVlessSni());
            mPrefVlessSni.setSummary(mProfile.getVlessSni().isEmpty() ? "Same as server host" : mProfile.getVlessSni());
        }
        if (mPrefVlessWsPath != null) {
            mPrefVlessWsPath.setText(mProfile.getVlessWsPath());
            mPrefVless