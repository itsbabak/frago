package net.typeblog.socks;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.VpnService;
import android.os.Bundle;
import android.os.IBinder;
import android.os.SystemClock;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.Toast;


import net.typeblog.socks.util.Profile;
import net.typeblog.socks.util.ProfileManager;
import net.typeblog.socks.util.Utility;
import net.typeblog.socks.util.XrayConfig;
import net.typeblog.socks.util.ShadowsocksUri;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static net.typeblog.socks.util.Constants.*;

/** One-page Frago settings: SOCKS5, Shadowsocks, Fragment JSON, Private DNS and app selection. */
public class ProfileFragment extends PreferenceFragment implements
        Preference.OnPreferenceClickListener,
        Preference.OnPreferenceChangeListener,
        CompoundButton.OnCheckedChangeListener {

    private static final int REQUEST_VPN_PERMISSION = 0;

    private ProfileManager mManager;
    private Profile mProfile;
    private Switch mSwitch;
    private boolean mRunning;
    private boolean mStarting;
    private boolean mStopping;
    private boolean mBound;
    private String mPendingXrayConfig;
    private boolean mServiceStartDispatched;
    private boolean mPendingPermission;
    private boolean mHasBroadcastState;
    private boolean mBroadcastRunning;
    private boolean mBroadcastStarting;
    private boolean mBroadcastStopping;
    private String mBroadcastError = "";
    private IVpnService mBinder;

    private CheckBoxPreference mPrefPerApp;
    private CheckBoxPreference mPrefAppBypass;
    private CheckBoxPreference mPrefPrivateDnsEnabled;
    private Preference mPrefPrivateDnsAddress;
    private Preference mPrefOutputMode;
    private Preference mPrefOutputConfig;
    private Preference mPrefOutputStatus;
    private Preference mPrefAppPicker;
    private Preference mPrefPing;

    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            mBinder = IVpnService.Stub.asInterface(binder);
            updateState(false);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mBinder = null;
            // The VPN service lives in its own process. A binder disconnect means
            // that process was lost, so do not leave a stale CONNECTED switch on screen.
            mHasBroadcastState = false;
            mBroadcastRunning = false;
            mBroadcastStarting = false;
            mBroadcastStopping = false;
            mBroadcastError = "";
            mRunning = false;
            mStarting = false;
            mStopping = false;
            mServiceStartDispatched = false;
            updateState(false);
        }
    };

    private final BroadcastReceiver mStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!ACTION_VPN_STATE.equals(intent.getAction())) return;
            mHasBroadcastState = true;
            mBroadcastRunning = intent.getBooleanExtra(EXTRA_VPN_RUNNING, false);
            mBroadcastStarting = intent.getBooleanExtra(EXTRA_VPN_STARTING, false);
            mBroadcastStopping = intent.getBooleanExtra(EXTRA_VPN_STOPPING, false);
            mBroadcastError = intent.getStringExtra(EXTRA_VPN_ERROR);
            if (mBroadcastError == null) mBroadcastError = "";
            updateState(true);
        }
    };
    private boolean mReceiverRegistered;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings_single);
        mManager = new ProfileManager(getActivity().getApplicationContext());
        initPreferences();
        reload();
    }

    private void initPreferences() {
        mPrefPerApp = (CheckBoxPreference) findPreference(PREF_ADV_PER_APP);
        mPrefAppBypass = (CheckBoxPreference) findPreference(PREF_ADV_APP_BYPASS);
        mPrefPrivateDnsEnabled = (CheckBoxPreference) findPreference("private_dns_enabled");
        mPrefPrivateDnsAddress = findPreference("private_dns_address");
        mPrefOutputMode = findPreference("output_mode");
        mPrefOutputConfig = findPreference("output_config");
        mPrefOutputStatus = findPreference("output_status");
        mPrefAppPicker = findPreference("adv_app_picker");
        mPrefPing = findPreference("ping_test");

        setChangeListener(mPrefPerApp);
        setChangeListener(mPrefAppBypass);
        setChangeListener(mPrefPrivateDnsEnabled);

        setClickListener(mPrefOutputMode);
        setClickListener(mPrefOutputConfig);
        setClickListener(mPrefPrivateDnsAddress);
        setClickListener(mPrefAppPicker);
        setClickListener(mPrefPing);
    }

    private void setChangeListener(Preference preference) {
        if (preference != null) preference.setOnPreferenceChangeListener(this);
    }

    private void setClickListener(Preference preference) {
        if (preference != null) preference.setOnPreferenceClickListener(this);
    }

    @Override
    public boolean onPreferenceClick(Preference preference) {
        if (preference == mPrefOutputMode) {
            chooseOutputMode();
            return true;
        }
        if (preference == mPrefOutputConfig) {
            editSelectedOutput();
            return true;
        }
        if (preference == mPrefPrivateDnsAddress) {
            editPrivateDnsAddress();
            return true;
        }
        if (preference == mPrefAppPicker) {
            showAppPicker();
            return true;
        }
        if (preference == mPrefPing) {
            runPingTest();
            return true;
        }
        return false;
    }

    @Override
    public boolean onPreferenceChange(Preference preference, Object newValue) {
        if (preference == mPrefPerApp) {
            boolean enabled = Boolean.parseBoolean(String.valueOf(newValue));
            mProfile.setIsPerApp(enabled);
            return true;
        }
        if (preference == mPrefAppBypass) {
            mProfile.setIsBypassApp(Boolean.parseBoolean(String.valueOf(newValue)));
            return true;
        }
        if (preference == mPrefPrivateDnsEnabled) {
            boolean enabled = Boolean.parseBoolean(String.valueOf(newValue));
            if (enabled && TextUtils.isEmpty(mProfile.getPrivateDnsAddress())) {
                Toast.makeText(getActivity(),
                        "Enter and save a DNS-over-HTTPS address first.",
                        Toast.LENGTH_LONG).show();
                return false;
            }
            mProfile.setPrivateDnsEnabled(enabled);
            updatePrivateDnsSummary();
            return true;
        }
        return false;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() instanceof MainActivity) {
            mSwitch = ((MainActivity) getActivity()).getVpnSwitch();
            if (mSwitch != null) mSwitch.setOnCheckedChangeListener(this);
        }
        if (!mReceiverRegistered && getActivity() != null) {
            IntentFilter filter = new IntentFilter(ACTION_VPN_STATE);
            getActivity().registerReceiver(mStateReceiver, filter);
            mReceiverRegistered = true;
        }
        checkState();
    }

    @Override
    public void onPause() {
        if (mSwitch != null) mSwitch.setOnCheckedChangeListener(null);
        if (mReceiverRegistered && getActivity() != null) {
            try { getActivity().unregisterReceiver(mStateReceiver); }
            catch (Exception ignored) { }
            mReceiverRegistered = false;
        }
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        if (mReceiverRegistered && getActivity() != null) {
            try { getActivity().unregisterReceiver(mStateReceiver); }
            catch (Exception ignored) { }
            mReceiverRegistered = false;
        }
        if (mSwitch != null) {
            mSwitch.setOnCheckedChangeListener(null);
            mSwitch = null;
        }
        if (mBound) {
            try { getActivity().unbindService(mConnection); }
            catch (Exception ignored) { }
            mBound = false;
            mBinder = null;
        }
        super.onDestroyView();
    }

    @Override
    public void onCheckedChanged(CompoundButton button, boolean checked) {
        if (checked) startVpn();
        else stopVpn();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_VPN_PERMISSION) return;
        if (resultCode == Activity.RESULT_OK && mProfile != null
                && !TextUtils.isEmpty(mPendingXrayConfig)) {
            mPendingPermission = false;
            mServiceStartDispatched = true;
            updateState(false);
            dispatchVpnStart(mPendingXrayConfig);
        } else {
            mPendingXrayConfig = null;
            mPendingPermission = false;
            mServiceStartDispatched = false;
            mStarting = false;
            updateState(false);
        }
    }

    private void chooseOutputMode() {
        final String[] labels = {"SOCKS5", "Shadowsocks", "Fragment · JSON"};
        final String[] values = {Profile.OUTPUT_SOCKS, Profile.OUTPUT_SHADOWSOCKS,
                Profile.OUTPUT_FRAGMENT};
        int selected = 2;
        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(mProfile.getOutputType())) selected = i;
        }
        new AlertDialog.Builder(getActivity())
                .setTitle("Select proxy output")
                .setSingleChoiceItems(labels, selected, (dialog, which) -> {
                    mProfile.setOutputType(values[which]);
                    dialog.dismiss();
                    reload();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void editSelectedOutput() {
        String type = mProfile.getOutputType();
        if (Profile.OUTPUT_SOCKS.equals(type)) editSocksSettings();
        else if (Profile.OUTPUT_SHADOWSOCKS.equals(type)) editShadowsocksSettings();
        else editJsonManually();
    }

    private void editSocksSettings() {
        LinearLayout form = new LinearLayout(getActivity());
        form.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        form.setPadding(pad, pad / 2, pad, 0);

        EditText host = singleLineField(mProfile.getSocksHost(), "SOCKS5 server address");
        host.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        EditText port = singleLineField(String.valueOf(mProfile.getSocksPort()), "Port (default 1080)");
        port.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText user = singleLineField(mProfile.getSocksUsername(), "Username (optional)");
        EditText password = singleLineField(mProfile.getSocksPassword(), "Password (optional)");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        form.addView(host);
        form.addView(port);
        form.addView(user);
        form.addView(password);

        new AlertDialog.Builder(getActivity())
                .setTitle("SOCKS5 server")
                .setView(form)
                .setPositiveButton("Save", (dialog, which) -> {
                    String server = host.getText().toString().trim();
                    int serverPort;
                    try { serverPort = Integer.parseInt(port.getText().toString().trim()); }
                    catch (Exception e) { showError("SOCKS5 port must be a number."); return; }
                    if (server.isEmpty() || serverPort < 1 || serverPort > 65535) {
                        showError("Enter a valid SOCKS5 address and port.");
                        return;
                    }
                    mProfile.setSocksHost(server);
                    mProfile.setSocksPort(serverPort);
                    mProfile.setSocksUsername(user.getText().toString());
                    mProfile.setSocksPassword(password.getText().toString());
                    try {
                        Utility.buildActiveXrayConfig(mProfile);
                        updateOutputSummary();
                        Toast.makeText(getActivity(), "SOCKS5 settings saved.", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) { showError(e.getMessage()); }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void editShadowsocksSettings() {
        final EditText editor = createEditor(mProfile.getShadowsocksUri(),
                "ss://method:password@server:port or SIP002 Base64 link");
        editor.setSingleLine(true);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        new AlertDialog.Builder(getActivity())
                .setTitle("Shadowsocks link")
                .setMessage("Paste a standard ss:// link. Plugin-based links are not supported.")
                .setView(editor)
                .setPositiveButton("Save", (dialog, which) -> {
                    try {
                        ShadowsocksUri.parse(editor.getText().toString());
                        mProfile.setShadowsocksUri(editor.getText().toString());
                        updateOutputSummary();
                        Toast.makeText(getActivity(), "Shadowsocks link saved.", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) { showError(e.getMessage()); }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private EditText singleLineField(String value, String hint) {
        EditText field = new EditText(getActivity());
        field.setSingleLine(true);
        field.setText(value);
        field.setHint(hint);
        return field;
    }

    private void editJsonManually() {
        String current = mProfile.getXrayConfig();
        if (current == null) current = "";
        final EditText editor = createEditor(current,
                "Paste or type the complete Fragment Xray JSON here");
        editor.setMinLines(16);
        editor.setMaxLines(28);
        new AlertDialog.Builder(getActivity())
                .setTitle("Fragment · JSON configuration")
                .setView(editor)
                .setPositiveButton("Save", (dialog, which) -> saveJson(editor.getText().toString()))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void editPrivateDnsAddress() {
        final EditText editor = createEditor(mProfile.getPrivateDnsAddress(),
                "https://dns.google/dns-query or dns.example/dns-query");
        editor.setSingleLine(true);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        new AlertDialog.Builder(getActivity())
                .setTitle("Private DNS · DoH")
                .setMessage("Use an HTTPS DNS-over-HTTPS endpoint. When enabled, Frago applies it to the active SOCKS5, Shadowsocks or Fragment output.")
                .setView(editor)
                .setPositiveButton("Save", (dialog, which) -> {
                    try {
                        String normalized = XrayConfig.normalizePrivateDnsAddress(
                                editor.getText().toString());
                        mProfile.setPrivateDnsAddress(normalized);
                        updatePrivateDnsSummary();
                        Toast.makeText(getActivity(), "Private DNS address saved.",
                                Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        showError(e.getMessage());
                    }
                })
                .setNeutralButton("Clear", (dialog, which) -> {
                    mProfile.setPrivateDnsAddress("");
                    mProfile.setPrivateDnsEnabled(false);
                    if (mPrefPrivateDnsEnabled != null) mPrefPrivateDnsEnabled.setChecked(false);
                    updatePrivateDnsSummary();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private EditText createEditor(String value, String hint) {
        EditText editor = new EditText(getActivity());
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editor.setTypeface(android.graphics.Typeface.MONOSPACE);
        editor.setText(value);
        editor.setHint(hint);
        editor.setSelection(editor.length());
        int padding = (int) (16 * getResources().getDisplayMetrics().density);
        editor.setPadding(padding, padding, padding, padding);
        return editor;
    }

    private void saveJson(String raw) {
        try {
            // Validate with a runtime copy; persist the user's exact JSON text unchanged.
            XrayConfig.prepare(raw);
            mProfile.setXrayConfig(raw);
            reload();
            Toast.makeText(getActivity(), "Fragment JSON saved without changing its formatting.",
                    Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            showError(e.getMessage());
        }
    }

    private void showError(String message) {
        Toast.makeText(getActivity(), "Invalid configuration: "
                + (TextUtils.isEmpty(message) ? "unknown error" : message), Toast.LENGTH_LONG).show();
    }

    private void showAppPicker() {
        final PackageManager packageManager = getActivity().getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN, null);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> resolved = packageManager.queryIntentActivities(launcher, 0);
        Collections.sort(resolved, new ResolveInfo.DisplayNameComparator(packageManager));

        final List<String> packages = new ArrayList<>();
        final List<CharSequence> labels = new ArrayList<>();
        Set<String> selected = new HashSet<>();
        String saved = mProfile.getAppList();
        if (!TextUtils.isEmpty(saved)) {
            for (String item : saved.split("\\n")) {
                if (!TextUtils.isEmpty(item.trim())) selected.add(item.trim());
            }
        }

        for (ResolveInfo info : resolved) {
            if (info.activityInfo == null) continue;
            String packageName = info.activityInfo.packageName;
            if (packageName.equals(getActivity().getPackageName()) || packages.contains(packageName)) continue;
            packages.add(packageName);
            labels.add(info.loadLabel(packageManager));
        }
        if (packages.isEmpty()) {
            Toast.makeText(getActivity(), "No launchable apps were found.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean[] checked = new boolean[packages.size()];
        for (int i = 0; i < packages.size(); i++) checked[i] = selected.contains(packages.get(i));
        new AlertDialog.Builder(getActivity())
                .setTitle("Choose apps")
                .setMultiChoiceItems(labels.toArray(new CharSequence[0]), checked,
                        (dialog, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton("Save", (dialog, which) -> {
                    StringBuilder list = new StringBuilder();
                    for (int i = 0; i < packages.size(); i++) {
                        if (checked[i]) {
                            if (list.length() > 0) list.append('\n');
                            list.append(packages.get(i));
                        }
                    }
                    mProfile.setAppList(list.toString());
                    mProfile.setIsPerApp(true);
                    if (mPrefPerApp != null) mPrefPerApp.setChecked(true);
                    updateAppPickerSummary();
                    Toast.makeText(getActivity(), "App selection saved.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void reload() {
        if (mProfile == null) mProfile = mManager.getDefault();
        if (mProfile == null) return;

        if (mPrefPerApp != null) mPrefPerApp.setChecked(mProfile.isPerApp());
        if (mPrefAppBypass != null) mPrefAppBypass.setChecked(mProfile.isBypassApp());
        if (mProfile.isPrivateDnsEnabled() && TextUtils.isEmpty(mProfile.getPrivateDnsAddress())) {
            mProfile.setPrivateDnsEnabled(false);
        }
        if (mPrefPrivateDnsEnabled != null) {
            mPrefPrivateDnsEnabled.setChecked(mProfile.isPrivateDnsEnabled());
        }
        updatePrivateDnsSummary();
        updateOutputSummary();
        updateAppPickerSummary();
        updatePingSummary();
    }

    private void updateOutputSummary() {
        if (mProfile == null) return;
        String type = mProfile.getOutputType();
        if (mPrefOutputMode != null) {
            if (Profile.OUTPUT_SOCKS.equals(type)) mPrefOutputMode.setSummary("SOCKS5");
            else if (Profile.OUTPUT_SHADOWSOCKS.equals(type)) mPrefOutputMode.setSummary("Shadowsocks");
            else mPrefOutputMode.setSummary("Fragment · JSON");
        }
        if (mPrefOutputConfig == null || mPrefOutputStatus == null) return;
        try {
            String summary;
            if (Profile.OUTPUT_SOCKS.equals(type)) {
                Utility.buildActiveXrayConfig(mProfile);
                summary = mProfile.getSocksHost() + ":" + mProfile.getSocksPort();
                mPrefOutputConfig.setTitle("SOCKS5 server settings");
                mPrefOutputConfig.setSummary(summary);
                mPrefOutputStatus.setSummary("SOCKS5 configured · ready to connect");
            } else if (Profile.OUTPUT_SHADOWSOCKS.equals(type)) {
                ShadowsocksUri.Config ss = ShadowsocksUri.parse(mProfile.getShadowsocksUri());
                mPrefOutputConfig.setTitle("Shadowsocks link");
                mPrefOutputConfig.setSummary(ss.host + ":" + ss.port + " · tap to edit link");
                mPrefOutputStatus.setSummary("Shadowsocks configured · ready to connect");
            } else {
                String json = mProfile.getXrayConfig();
                if (TextUtils.isEmpty(json)) throw new IllegalArgumentException("No Fragment JSON saved.");
                XrayConfig.prepare(json);
                mPrefOutputConfig.setTitle("Fragment · JSON configuration");
                mPrefOutputConfig.setSummary("JSON saved · tap to edit manually");
                mPrefOutputStatus.setSummary("Fragment JSON saved · ready to connect");
            }
        } catch (Exception e) {
            if (Profile.OUTPUT_SOCKS.equals(type)) {
                mPrefOutputConfig.setTitle("SOCKS5 server settings");
                mPrefOutputConfig.setSummary("Tap to enter server address, port and optional credentials");
            } else if (Profile.OUTPUT_SHADOWSOCKS.equals(type)) {
                mPrefOutputConfig.setTitle("Shadowsocks link");
                mPrefOutputConfig.setSummary("Tap to paste an ss:// link manually");
            } else {
                mPrefOutputConfig.setTitle("Fragment · JSON configuration");
                mPrefOutputConfig.setSummary("Tap to paste or edit the full JSON manually · no import");
            }
            mPrefOutputStatus.setSummary("Not configured · " + (TextUtils.isEmpty(e.getMessage()) ? "check settings" : e.getMessage()));
        }
        updatePingSummary();
    }

    private void updatePingSummary() {
        if (mPrefPing == null || mProfile == null) return;
        String type = mProfile.getOutputType();
        String name = Profile.OUTPUT_SOCKS.equals(type) ? "SOCKS5"
                : Profile.OUTPUT_SHADOWSOCKS.equals(type) ? "Shadowsocks" : "Fragment";
        mPrefPing.setSummary("Measure TCP latency through " + name + " (VPN must be ON)");
    }

    /** TCP reachability/latency test through the selected proxy via Frago's local SOCKS5 bridge. */
    private void runPingTest() {
        if (mProfile == null || !mRunning) {
            Toast.makeText(getActivity(), "Connect Frago before running Ping.",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        if (mPrefPing != null) {
            mPrefPing.setEnabled(false);
            mPrefPing.setSummary("Testing TCP connection through the selected proxy…");
        }
        final Profile profile = mProfile;
        final Activity host = getActivity();
        new Thread(() -> {
            String result;
            try {
                long elapsed;
                if (Profile.OUTPUT_SOCKS.equals(profile.getOutputType())
                        && !profile.isPrivateDnsEnabled()) {
                    elapsed = socksTcpPing(profile.getSocksHost(), profile.getSocksPort(),
                            profile.getSocksUsername(), profile.getSocksPassword(), 443);
                } else {
                    String activeConfig = Utility.buildActiveXrayConfig(profile);
                    XrayConfig.Prepared prepared = XrayConfig.prepare(activeConfig,
                            profile.isPrivateDnsEnabled(), profile.getPrivateDnsAddress());
                    elapsed = socksTcpPing("127.0.0.1", prepared.socksPort,
                            "", "", 443);
                }
                result = "Connected · " + elapsed + " ms (TCP)";
            } catch (Exception e) {
                String message = e.getMessage();
                result = "Ping failed · " + (TextUtils.isEmpty(message) ? "connection error" : message);
            }
            final String finalResult = result;
            if (host != null) {
                host.runOnUiThread(() -> {
                    if (isAdded() && mPrefPing != null) {
                        mPrefPing.setEnabled(true);
                        mPrefPing.setSummary(finalResult);
                    }
                });
            }
        }, "Frago-Ping").start();
    }

    private long socksTcpPing(String proxyHost, int proxyPort, String username,
                              String password, int targetPort) throws Exception {
        java.net.Socket socket = new java.net.Socket();
        try {
            socket.connect(new java.net.InetSocketAddress(proxyHost, proxyPort), 3500);
            socket.setSoTimeout(7000);
            java.io.DataInputStream input = new java.io.DataInputStream(socket.getInputStream());
            java.io.DataOutputStream output = new java.io.DataOutputStream(socket.getOutputStream());
            long started = SystemClock.elapsedRealtime();

            // SOCKS5 method negotiation. Auth is optional for external SOCKS5;
            // Frago's local Xray bridge uses no-auth.
            boolean hasAuth = !TextUtils.isEmpty(username) || !TextUtils.isEmpty(password);
            output.write(hasAuth
                    ? new byte[] {0x05, 0x01, 0x02}
                    : new byte[] {0x05, 0x01, 0x00});
            output.flush();
            int version = input.readUnsignedByte();
            int method = input.readUnsignedByte();
            if (version != 0x05 || method == 0xff) {
                throw new java.io.IOException("SOCKS5 handshake was rejected");
            }
            if (method == 0x02) {
                byte[] userBytes = (username == null ? "" : username).getBytes("UTF-8");
                byte[] passBytes = (password == null ? "" : password).getBytes("UTF-8");
                if (userBytes.length > 255 || passBytes.length > 255) {
                    throw new java.io.IOException("SOCKS5 username/password is too long");
                }
                output.writeByte(0x01);
                output.writeByte(userBytes.length);
                output.write(userBytes);
                output.writeByte(passBytes.length);
                output.write(passBytes);
                output.flush();
                if (input.readUnsignedByte() != 0x01 || input.readUnsignedByte() != 0x00) {
                    throw new java.io.IOException("SOCKS5 authentication failed");
                }
            } else if (method != 0x00) {
                throw new java.io.IOException("SOCKS5 server selected an unsupported authentication method");
            }

            // CONNECT to 1.1.1.1 using a literal IPv4 address (no local DNS lookup).
            output.write(new byte[] {0x05, 0x01, 0x00, 0x01,
                    1, 1, 1, 1,
                    (byte) ((targetPort >> 8) & 0xff), (byte) (targetPort & 0xff)});
            output.flush();

            int responseVersion = input.readUnsignedByte();
            int reply = input.readUnsignedByte();
            input.readUnsignedByte(); // reserved
            int addressType = input.readUnsignedByte();
            if (responseVersion != 0x05) throw new java.io.IOException("Invalid SOCKS5 response");
            if (reply != 0x00) throw new java.io.IOException(socksReplyMessage(reply));

            if (addressType == 0x01) {
                byte[] boundAddress = new byte[4];
                input.readFully(boundAddress);
            } else if (addressType == 0x04) {
                byte[] boundAddress = new byte[16];
                input.readFully(boundAddress);
            } else if (addressType == 0x03) {
                int length = input.readUnsignedByte();
                byte[] boundAddress = new byte[length];
                input.readFully(boundAddress);
            } else {
                throw new java.io.IOException("Unknown SOCKS5 address type");
            }
            input.readUnsignedShort(); // bound port
            return SystemClock.elapsedRealtime() - started;
        } finally {
            try { socket.close(); } catch (Exception ignored) { }
        }
    }

    private String socksReplyMessage(int code) {
        switch (code) {
            case 0x01: return "SOCKS5 general failure";
            case 0x02: return "Connection not allowed by SOCKS5 server";
            case 0x03: return "Network unreachable";
            case 0x04: return "Host unreachable";
            case 0x05: return "Connection refused";
            case 0x06: return "Connection timed out";
            case 0x07: return "SOCKS5 command not supported";
            case 0x08: return "SOCKS5 address type not supported";
            default: return "SOCKS5 connection failed (" + code + ")";
        }
    }

    private void updatePrivateDnsSummary() {
        if (mPrefPrivateDnsAddress == null || mProfile == null) return;
        String address = mProfile.getPrivateDnsAddress();
        boolean enabled = mProfile.isPrivateDnsEnabled();
        mPrefPrivateDnsAddress.setEnabled(true);
        if (TextUtils.isEmpty(address)) {
            mPrefPrivateDnsAddress.setSummary(enabled
                    ? "Enabled · address required · tap to enter a DoH URL"
                    : "Disabled · tap to enter an address");
        } else {
            mPrefPrivateDnsAddress.setSummary((enabled ? "Enabled · " : "Saved · ") + address);
        }
    }

    private void updateAppPickerSummary() {
        if (mPrefAppPicker == null || mProfile == null) return;
        String apps = mProfile.getAppList();
        int count = 0;
        if (!TextUtils.isEmpty(apps)) {
            for (String item : apps.split("\\n")) if (!TextUtils.isEmpty(item.trim())) count++;
        }
        mPrefAppPicker.setSummary(count + " app(s) selected · app names only");
    }

    private void checkState() {
        if (getActivity() == null) return;
        if (!mBound) {
            mBound = getActivity().bindService(new Intent(getActivity(), SocksVpnService.class),
                    mConnection, Context.BIND_AUTO_CREATE);
            if (!mBound) updateState(false);
        } else {
            updateState(false);
        }
    }

    private void updateState(boolean fromServiceEvent) {
        if (getActivity() == null) return;
        boolean serviceRunning = false;
        boolean serviceStarting = false;
        boolean serviceStopping = false;
        String serviceError = "";
        if (mBinder != null) {
            try {
                serviceRunning = mBinder.isRunning();
                serviceStarting = mBinder.isStarting();
                serviceStopping = mBinder.isStopping();
                if (mServiceStartDispatched) serviceError = mBinder.getLastError();
            } catch (Exception ignored) {
                if (mHasBroadcastState) {
                    serviceRunning = mBroadcastRunning;
                    serviceStarting = mBroadcastStarting;
                    serviceStopping = mBroadcastStopping;
                    if (mServiceStartDispatched) serviceError = mBroadcastError;
                }
            }
        } else if (mHasBroadcastState) {
            serviceRunning = mBroadcastRunning;
            serviceStarting = mBroadcastStarting;
            serviceStopping = mBroadcastStopping;
            if (mServiceStartDispatched) serviceError = mBroadcastError;
        }

        if (mServiceStartDispatched && !TextUtils.isEmpty(serviceError)) {
            showError(serviceError);
            try { mBinder.clearLastError(); } catch (Exception ignored) { }
            mServiceStartDispatched = false;
        }

        mRunning = serviceRunning;
        if (mServiceStartDispatched) {
            // Before the service broadcasts its first state, keep the control in
            // CONNECTING instead of briefly reverting it to OFF.
            if (serviceStarting || serviceRunning) {
                mStarting = serviceStarting;
                if (serviceRunning) mServiceStartDispatched = false;
            } else if (fromServiceEvent && mBinder != null) {
                mStarting = false;
                mServiceStartDispatched = false;
            } else {
                mStarting = true;
            }
        } else if (mPendingPermission) {
            mStarting = true;
        } else {
            mStarting = serviceStarting;
        }

        // Keep DISCONNECTING visible until the service confirms the stop has
        // completed. No timer or periodic polling is used.
        mStopping = serviceStopping || (mStopping && !fromServiceEvent);
        if (fromServiceEvent && !serviceStopping && !serviceRunning && !serviceStarting) {
            mStopping = false;
        }

        if (mSwitch != null) {
            mSwitch.setOnCheckedChangeListener(null);
            mSwitch.setChecked(mRunning || mStarting || mStopping);
            mSwitch.setEnabled(!mStopping);
            mSwitch.setOnCheckedChangeListener(this);
        }
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).setVpnUiState(mRunning, mStarting, mStopping);
        }
    }

    private void startVpn() {
        if (mStarting || mRunning || mStopping) return;
        if (mProfile == null) {
            updateState(false);
            return;
        }
        if (mProfile.isPerApp() && !mProfile.isBypassApp()
                && TextUtils.isEmpty(mProfile.getAppList().trim())) {
            Toast.makeText(getActivity(), "Choose at least one app, or turn off app selection.",
                    Toast.LENGTH_LONG).show();
            updateState(false);
            return;
        }
        if (mProfile.isPrivateDnsEnabled()
                && TextUtils.isEmpty(mProfile.getPrivateDnsAddress())) {
            Toast.makeText(getActivity(), "Enter a Private DNS address first.",
                    Toast.LENGTH_LONG).show();
            updateState(false);
            return;
        }

        final String activeConfig;
        try {
            // Build the selected backend without changing the separately saved Fragment JSON.
            activeConfig = Utility.buildActiveXrayConfig(mProfile);
        } catch (Exception e) {
            showError(e.getMessage());
            updateState(false);
            return;
        }

        if (mBinder != null) {
            try { mBinder.clearLastError(); } catch (Exception ignored) { }
        }
        mPendingXrayConfig = activeConfig;
        final Intent permissionIntent = VpnService.prepare(getActivity());
        // Set the transition flags before refreshing the widget. Otherwise the old
        // service state (OFF) can immediately undo the user's ON switch.
        mPendingPermission = permissionIntent != null;
        mServiceStartDispatched = permissionIntent == null;
        mStarting = true;
        updateState(false);

        if (permissionIntent != null) {
            startActivityForResult(permissionIntent, REQUEST_VPN_PERMISSION);
            return;
        }
        dispatchVpnStart(activeConfig);
    }

    private void dispatchVpnStart(String activeConfig) {
        try {
            Utility.startVpn(getActivity(), mProfile, activeConfig);
            mPendingXrayConfig = null;
            // The service reports the actual transition; no periodic UI polling is used.
        } catch (Exception e) {
            mPendingXrayConfig = null;
            mPendingPermission = false;
            mServiceStartDispatched = false;
            mStarting = false;
            showError("Could not start VPN: " + e.getMessage());
            updateState(false);
        }
    }

    private void stopVpn() {
        mPendingPermission = false;
        mPendingXrayConfig = null;
        mStopping = true;
        mStarting = false;
        mServiceStartDispatched = false;
        updateState(false);
        try {
            if (mBinder != null) mBinder.stop();
            else Utility.stopVpn(getActivity());
        } catch (Exception e) {
            mStopping = false;
            showError("Could not send the VPN stop request: " + e.getMessage());
            updateState(false);
        }
    }


}
