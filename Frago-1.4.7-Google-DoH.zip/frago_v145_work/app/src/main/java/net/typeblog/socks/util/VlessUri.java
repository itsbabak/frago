package net.typeblog.socks.util;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/** Parses common VLESS share links into the Xray outbound parameters used by Frago. */
public final class VlessUri {
    private VlessUri() { }
    public static final class Config {
        public String uuid, host, security, network, sni, fingerprint, publicKey, shortId, spiderX;
        public String encryption, flow, path, hostHeader, serviceName, alpn;
        public boolean grpcMode;
        public int port;
    }
    public static Config parse(String raw) throws Exception {
        if (raw == null || raw.trim().isEmpty()) throw new IllegalArgumentException("Paste a VLESS link first.");
        URI uri = new URI(raw.trim());
        if (!"vless".equalsIgnoreCase(uri.getScheme())) throw new IllegalArgumentException("The link must start with vless://.");
        String uuid = uri.getUserInfo();
        String host = uri.getHost();
        int port = uri.getPort();
        if (uuid == null || uuid.isEmpty() || host == null || port < 1 || port > 65535)
            throw new IllegalArgumentException("VLESS link must contain a valid UUID, server and port.");
        Map<String,String> q = parseQuery(uri.getRawQuery());
        Config c = new Config();
        c.uuid = decode(uuid); c.host = host; c.port = port;
        c.security = value(q,"security","none").toLowerCase();
        c.network = value(q,"type","tcp").toLowerCase();
        c.sni = value(q,"sni", value(q,"servername",""));
        c.fingerprint = value(q,"fp",""); c.publicKey = value(q,"pbk", value(q,"publickey",""));
        c.shortId = value(q,"sid", value(q,"shortid","")); c.spiderX = value(q,"spx","");
        c.encryption = value(q,"encryption","none"); c.flow = value(q,"flow","");
        c.path = value(q,"path",""); c.hostHeader = value(q,"host","");
        c.serviceName = value(q,"serviceName", value(q,"servicename", ""));
        c.alpn = value(q,"alpn",""); c.grpcMode = "multi".equalsIgnoreCase(value(q,"mode",""));
        if (!c.security.equals("none") && !c.security.equals("tls") && !c.security.equals("reality"))
            throw new IllegalArgumentException("Unsupported VLESS security: " + c.security);
        if (!c.network.equals("tcp") && !c.network.equals("ws") && !c.network.equals("grpc")
                && !c.network.equals("httpupgrade"))
            throw new IllegalArgumentException("Unsupported VLESS transport: " + c.network);
        if ("reality".equals(c.security) && (c.publicKey.isEmpty() || c.sni.isEmpty()))
            throw new IllegalArgumentException("VLESS Reality link must include sni and pbk parameters.");
        return c;
    }
    private static Map<String,String> parseQuery(String raw) throws Exception {
        Map<String,String> map = new LinkedHashMap<>();
        if (raw == null || raw.isEmpty()) return map;
        for (String pair : raw.split("&")) {
            int i = pair.indexOf('=');
            String k = i < 0 ? pair : pair.substring(0,i);
            String v = i < 0 ? "" : pair.substring(i+1);
            map.put(decode(k).toLowerCase(), decode(v));
        }
        return map;
    }
    private static String value(Map<String,String> q, String k, String d) { String v=q.get(k.toLowerCase()); return v==null?d:v; }
    private static String decode(String s) throws Exception { return URLDecoder.decode(s.replace("+", "%2B"), "UTF-8"); }
}
