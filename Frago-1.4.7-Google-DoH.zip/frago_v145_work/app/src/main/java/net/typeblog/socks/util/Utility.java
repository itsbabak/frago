package net.typeblog.socks.util;

import android.content.Context;
import android.content.Intent;
import android.util.Log;


import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.util.List;

import net.typeblog.socks.R;
import net.typeblog.socks.SocksVpnService;
import static net.typeblog.socks.util.Constants.*;

public class Utility {
    private static final String TAG = Utility.class.getSimpleName();

    public static int exec(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(cmd);
            return p.waitFor();
        } catch (Exception e) {
            return -1;
        }
    }

    /** Execute exact arguments without whitespace splitting (proxy passwords may contain spaces). */
    public static int exec(String[] command) {
        try {
            Process p = Runtime.getRuntime().exec(command);
            return p.waitFor();
        } catch (Exception e) {
            return -1;
        }
    }

    /**
     * Stops one of Frago's own native daemons using its pid file.
     * The /proc command-line check prevents a stale pid file from killing an
     * unrelated process after Android has reused the old PID.
     */
    public static void killPidFile(String path, String expectedBinary) {
        File pidFile = new File(path);
        if (!pidFile.isFile()) {
            if (pidFile.exists()) pidFile.delete();
            return;
        }

        String pidText = "";
        try (InputStream input = new FileInputStream(pidFile)) {
            byte[] buffer = new byte[128];
            int count;
            StringBuilder value = new StringBuilder();
            while ((count = input.read(buffer)) != -1) {
                value.append(new String(buffer, 0, count, "UTF-8"));
                if (value.length() > 128) break;
            }
            pidText = value.toString().trim();
        } catch (Exception ignored) {
            // A corrupt pid file is removed below; it must not block shutdown.
        } finally {
            // Never leave an old pid file to interfere with the next ON cycle.
            try { pidFile.delete(); } catch (Exception ignored) { }
        }

        final int pid;
        try {
            pid = Integer.parseInt(pidText);
        } catch (Exception ignored) {
            return;
        }
        if (pid <= 1 || pid == android.os.Process.myPid()) return;
        if (expectedBinary != null && !processCommandMatches(pid, expectedBinary)) return;

        try {
            Process killer = Runtime.getRuntime().exec(
                    new String[]{"kill", "-TERM", Integer.toString(pid)});
            killer.waitFor();
        } catch (Exception ignored) {
            // The process may already have exited; shutdown continues regardless.
        }
    }

    private static boolean processCommandMatches(int pid, String expectedBinary) {
        File commandLine = new File("/proc/" + pid + "/cmdline");
        try (InputStream input = new FileInputStream(commandLine)) {
            byte[] buffer = new byte[4096];
            int count = input.read(buffer);
            if (count <= 0) return false;
            String command = new String(buffer, 0, count, "UTF-8");
            return command.contains(expectedBinary);
        } catch (Exception ignored) {
            // Fail closed: never kill a PID we cannot identify as our daemon.
            return false;
        }
    }

    public static String join(List<String> list, String separator) {
        if (list.isEmpty()) return "";

        StringBuilder ret = new StringBuilder();

        for (String s : list) {
            ret.append(s).append(separator);
        }

        return ret.substring(0, ret.length() - separator.length());
    }

    public static void makePdnsdConf(Context context, String dns, int port) {
        String conf = context.getString(R.string.pdnsd_conf)
                .replace("{DIR}", context.getFilesDir().toString())
                .replace("{IP}", dns)
                .replace("{PORT}", Integer.toString(port));

        File f = new File(context.getFilesDir() + "/pdnsd.conf");

        if (f.exists()) {
            if(!f.delete())
                Log.w(TAG, "failed to delete pdnsd.conf");
        }

        try {
            OutputStream out = new FileOutputStream(f);
            out.write(conf.getBytes());
            out.flush();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        File cache = new File(context.getFilesDir() + "/pdnsd.cache");

        if (!cache.exists()) {
            try {
                if(!cache.createNewFile())
                    Log.w(TAG, "failed to create pdnsd.cache");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /** Builds the selected output config. Fragment JSON is returned unchanged. */
    public static String buildActiveXrayConfig(Profile profile) throws Exception {
        return ProxyConfigBuilder.build(profile);
    }

    public static void startVpn(Context context, Profile profile) {
        try {
            startVpn(context, profile, buildActiveXrayConfig(profile));
        } catch (Exception e) {
            Log.e(TAG, "Could not build selected Frago output", e);
        }
    }

    /** Stop command fallback for the rare case where the UI binder is not connected. */
    public static void stopVpn(Context context) {
        Intent intent = new Intent(context, SocksVpnService.class).setAction(ACTION_STOP_VPN);
        context.startService(intent);
    }

    public static void startVpn(Context context, Profile profile, String activeConfig) {
        // All supported proxy outputs are normalized to a local Xray SOCKS inbound.
        // This keeps SOCKS5, Shadowsocks, VLESS and manual Xray JSON on one engine path.
        // All selected outbound protocols share one Xray engine and one local SOCKS bridge.
        String upstream = "127.0.0.1";
        int upstreamPort = 10808;
        String upstreamUser = null;
        String upstreamPassword = null;

        Intent i = new Intent(context, SocksVpnService.class)
                .putExtra(INTENT_NAME, profile.getName())
                .putExtra(INTENT_SERVER, upstream)
                .putExtra(INTENT_PORT, upstreamPort)
                .putExtra(INTENT_USERNAME, upstreamUser)
                .putExtra(INTENT_PASSWORD, upstreamPassword)
                .putExtra(INTENT_ROUTE, profile.getRoute())
                .putExtra(INTENT_DNS, profile.getDns())
                .putExtra(INTENT_DNS_PORT, profile.getDnsPort())
                .putExtra(INTENT_PER_APP, profile.isPerApp())
                .putExtra(INTENT_IPV6_PROXY, profile.hasIPv6())
                .putExtra(INTENT_XRAY_MODE, true)
                .putExtra(INTENT_XRAY_CONFIG, activeConfig)
                .putExtra(INTENT_PRIVATE_DNS_ENABLED, profile.isPrivateDnsEnabled())
                .putExtra(INTENT_PRIVATE_DNS_ADDRESS, profile.getPrivateDnsAddress());

        if (profile.isPerApp()) {
            i.putExtra(INTENT_APP_BYPASS, profile.isBypassApp())
                    .putExtra(INTENT_APP_LIST, profile.getAppList().split("\n"));
        }
        if (android.os.Build.VERSION.SDK_INT >= 26) context.startForegroundService(i);
        else context.startService(i);
    }
}
