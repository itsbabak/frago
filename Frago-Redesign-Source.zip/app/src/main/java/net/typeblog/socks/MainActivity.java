package net.typeblog.socks;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

/** Lightweight native navigation drawer. No additional UI libraries are required. */
public class MainActivity extends Activity {
    private static final String STATE_SECTION = "frago_section";

    private FrameLayout mRoot;
    private FrameLayout mFragmentContainer;
    private View mScrim;
    private LinearLayout mDrawer;
    private TextView mTitle;
    private Switch mVpnSwitch;
    private String mCurrentSection = ProfileFragment.SECTION_HOME;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(48, 63, 159));
        getWindow().setNavigationBarColor(Color.BLACK);

        mRoot = new FrameLayout(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(Color.WHITE);

        content.addView(createToolbar(), new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(56)));

        mFragmentContainer = new FrameLayout(this);
        mFragmentContainer.setId(R.id.main_fragment_container);
        content.addView(mFragmentContainer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        mRoot.addView(content, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        mScrim = new View(this);
        mScrim.setBackgroundColor(0x66000000);
        mScrim.setVisibility(View.GONE);
        mScrim.setOnClickListener(v -> closeDrawer());
        mRoot.addView(mScrim, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        mDrawer = createDrawer();
        FrameLayout.LayoutParams drawerParams = new FrameLayout.LayoutParams(dp(288),
                FrameLayout.LayoutParams.MATCH_PARENT, Gravity.START);
        mDrawer.setVisibility(View.GONE);
        mDrawer.setElevation(dp(18));
        mRoot.addView(mDrawer, drawerParams);
        setContentView(mRoot);

        String initialSection = savedInstanceState == null
                ? ProfileFragment.SECTION_HOME
                : savedInstanceState.getString(STATE_SECTION, ProfileFragment.SECTION_HOME);
        navigateTo(initialSection, false);
    }

    private View createToolbar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(4), 0, dp(12), 0);
        bar.setBackgroundColor(Color.rgb(63, 81, 181));
        bar.setElevation(dp(3));

        TextView menu = new TextView(this);
        menu.setText("☰");
        menu.setTextSize(27);
        menu.setTextColor(Color.WHITE);
        menu.setGravity(Gravity.CENTER);
        menu.setContentDescription("Open navigation menu");
        bar.addView(menu, new LinearLayout.LayoutParams(dp(52),
                LinearLayout.LayoutParams.MATCH_PARENT));
        menu.setOnClickListener(v -> openDrawer());

        mTitle = new TextView(this);
        mTitle.setText("Frago");
        mTitle.setTextColor(Color.WHITE);
        mTitle.setTextSize(20);
        mTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bar.addView(mTitle, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1f));

        mVpnSwitch = new Switch(this);
        mVpnSwitch.setText("VPN");
        mVpnSwitch.setTextColor(Color.WHITE);
        mVpnSwitch.setShowText(true);
        bar.addView(mVpnSwitch, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return bar;
    }

    private LinearLayout createDrawer() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.rgb(250, 250, 250));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.BOTTOM);
        header.setPadding(dp(22), dp(22), dp(16), dp(20));
        header.setBackgroundColor(Color.rgb(57, 73, 171));
        TextView brand = new TextView(this);
        brand.setText("FRAGO");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(22);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(brand);
        TextView subtitle = new TextView(this);
        subtitle.setText("VPN & Proxy Settings");
        subtitle.setTextColor(0xFFDDE2FF);
        subtitle.setTextSize(13);
        header.addView(subtitle);
        panel.addView(header, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(132)));

        ScrollView scroll = new ScrollView(this);
        LinearLayout items = new LinearLayout(this);
        items.setOrientation(LinearLayout.VERTICAL);
        addDrawerItem(items, "Connection", ProfileFragment.SECTION_HOME);
        addDrawerDivider(items);
        addDrawerItem(items, "SOCKS5", ProfileFragment.SECTION_SOCKS);
        addDrawerItem(items, "Shadowsocks", ProfileFragment.SECTION_SHADOWSOCKS);
        addDrawerItem(items, "VLESS", ProfileFragment.SECTION_VLESS);
        addDrawerItem(items, "VMess", ProfileFragment.SECTION_VMESS);
        addDrawerItem(items, "Custom JSON", ProfileFragment.SECTION_JSON);
        addDrawerDivider(items);
        addDrawerItem(items, "App selection", ProfileFragment.SECTION_APPS);
        addDrawerItem(items, "Advanced", ProfileFragment.SECTION_ADVANCED);
        scroll.addView(items);
        panel.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        return panel;
    }

    private void addDrawerItem(LinearLayout list, String label, String section) {
        TextView item = new TextView(this);
        item.setText(label);
        item.setTextColor(Color.rgb(35, 35, 35));
        item.setTextSize(16);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(24), 0, dp(16), 0);
        list.addView(item, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));
        item.setOnClickListener(v -> navigateTo(section, true));
    }

    private void addDrawerDivider(LinearLayout list) {
        View line = new View(this);
        line.setBackgroundColor(0xFFE2E2E2);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        params.topMargin = dp(6);
        params.bottomMargin = dp(6);
        list.addView(line, params);
    }

    public void navigateTo(String section) {
        navigateTo(section, true);
    }

    private void navigateTo(String section, boolean close) {
        if (section == null) section = ProfileFragment.SECTION_HOME;
        mCurrentSection = section;
        if (mTitle != null) mTitle.setText(ProfileFragment.sectionTitle(section));
        if (close) closeDrawer();
        if (mFragmentContainer != null) {
            getFragmentManager().beginTransaction()
                    .replace(R.id.main_fragment_container, ProfileFragment.newInstance(section))
                    .commit();
        }
    }

    public Switch getVpnSwitch() {
        return mVpnSwitch;
    }

    private void openDrawer() {
        mScrim.setVisibility(View.VISIBLE);
        mDrawer.setVisibility(View.VISIBLE);
        mDrawer.bringToFront();
        mScrim.bringToFront();
        mDrawer.bringToFront();
    }

    private void closeDrawer() {
        if (mDrawer != null) mDrawer.setVisibility(View.GONE);
        if (mScrim != null) mScrim.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
        if (mDrawer != null && mDrawer.getVisibility() == View.VISIBLE) {
            closeDrawer();
        } else if (!ProfileFragment.SECTION_HOME.equals(mCurrentSection)) {
            navigateTo(ProfileFragment.SECTION_HOME, false);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString(STATE_SECTION, mCurrentSection);
        super.onSaveInstanceState(outState);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
