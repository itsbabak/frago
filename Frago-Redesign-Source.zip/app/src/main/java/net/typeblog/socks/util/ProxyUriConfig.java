package net.typeblog.socks.util;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Converts common share links into Xray JSON consumed by Frago's local SOCKS bridge. */
public final class ProxyUriConfig {
    private ProxyUriConfig() { }

    public static String toXrayJson(String value) throws Exception {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("لینک کانفیگ خالی است.");
        }
        String input = value.trim();
        int schemeEnd = input.indexOf("://");
        if (schemeEnd <= 0) throw new IllegalArgumentException("لینک معتبر نیست.");
        String scheme = input.substring(0, schemeEnd).toLowerCase(Locale.US);

        JSONObject root = createBaseConfig();
        JSONObject outbound = new JSONObject();
        outbound.put("tag", "proxy");
        JSONObject settings = new JSONObject();

        switch (scheme) {
            case "vless":
                buildVless(input, outbound, settings);
                break;
            case "vmess":
                buildVmess(input, outbound, settings);
                break;
            case "ss":
            case "shadowsocks":
                buildShadowsocks(input, outbound, settings);
                break;
            case "http":
            case "https":
            case "socks":
            case "socks5":
                buildBasicProxy(input, scheme, outbound, settings);
                break;
            default:
                throw new IllegalArgumentException(
                        "پروتکل پشتیبانی نمی‌شود. VLESS، VMess، Shadowsocks، HTTP(S) و SOCKS5 قابل قبول‌اند.");
        }

        outbound.put("settings", settings);
        JSONArray outbounds = root.getJSONArray("outbounds");
        outbounds.put(0, outbound);
        return root.toString(2);
    }

    private static JSONObject createBaseConfig() throws JSONException {
        JSONObject root = new JSONObject();
        root.put("log", new JSONObject().put("loglevel", "warning"));
        JSONObject inbound = new JSONObject();
        inbound.put("tag", "frago-socks-in");
        inbound.put("listen", "127.0.0.1");
        inbound.put("port", 10808);
        inbound.put("protocol", "socks");
        inbound.put("settings", new JSONObject().put("auth", "noauth").put("udp", true));
        root.put("inbounds", new JSONArray().put(inbound));
        root.put("outbounds", new JSONArray()
                .put(new JSONObject().put("protocol", "freedom").put("tag", "direct")));
        return root;
    }

    private static void buildVless(String value, JSONObject outbound, JSONObject settings) throws Exception {
        URI uri = new URI(value);
        requireAddressAndPort(uri, "VLESS");
        String uuid = uri.getUserInfo();
        if (uuid == null || uuid.trim().isEmpty()) {
            throw new IllegalArgumentException("شناسه UUID در لینک VLESS وجود ندارد.");
        }
        Map<String, String> q = query(uri.getRawQuery());
        JSONObject user = new JSONObject();
        user.put("id", decode(uuid));
        user.put("encryption", value(q, "encryption", "none"));
        String flow = value(q, "flow", "");
        if (!flow.isEmpty()) user.put("flow", flow);

        JSONObject server = new JSONObject();
        server.put("address", uri.getHost());
        server.put("port", uri.getPort());
        server.put("users", new JSONArray().put(user));
        settings.put("vnext", new JSONArray().put(server));
        outbound.put("protocol", "vless");

        JSONObject stream = new JSONObject();
        String network = value(q, "type", "tcp").toLowerCase(Locale.US);
        String security = value(q, "security", "none").toLowerCase(Locale.US);
        stream.put("network", network);
        stream.put("security", security);
        addSecuritySettings(stream, security, q, null);
        addTransportSettings(stream, network, q, null);
        outbound.put("streamSettings", stream);
    }

    private static void buildVmess(String value, JSONObject outbound, JSONObject settings) throws Exception {
        String payload = value.substring(value.indexOf("://") + 3);
        int hash = payload.indexOf('#');
        if (hash >= 0) payload = payload.substring(0, hash);
        int queryAt = payload.indexOf('?');
        if (queryAt >= 0) payload = payload.substring(0, queryAt);
        JSONObject vmess = new JSONObject(decodeBase64Text(payload));

        String address = first(vmess.optString("add", ""), vmess.optString("address", ""));
        int port = parsePort(vmess.opt("port"));
        String id = vmess.optString("id", "").trim();
        if (address.isEmpty() || port < 1 || id.isEmpty()) {
            throw new IllegalArgumentException("VMess JSON باید فیلدهای add، port و id معتبر داشته باشد.");
        }

        JSONObject user = new JSONObject();
        user.put("id", id);
        user.put("alterId", Math.max(0, parseInt(vmess.opt("aid"), 0)));
        user.put("security", first(vmess.optString("scy", ""), "auto"));
        JSONObject server = new JSONObject();
        server.put("address", address);
        server.put("port", port);
        server.put("users", new JSONArray().put(user));
        settings.put("vnext", new JSONArray().put(server));
        outbound.put("protocol", "vmess");

        Map<String, String> q = new HashMap<>();
        copyJsonString(vmess, q, "net", "type");
        copyJsonString(vmess, q, "tls", "tls");
        copyJsonString(vmess, q, "sni", "sni");
        copyJsonString(vmess, q, "host", "host");
        copyJsonString(vmess, q, "path", "path");
        copyJsonString(vmess, q, "fp", "fp");
        copyJsonString(vmess, q, "alpn", "alpn");
        copyJsonString(vmess, q, "type", "headerType");
        copyJsonString(vmess, q, "serviceName", "serviceName");
        copyJsonString(vmess, q, "authority", "authority");
        if (vmess.has("allowInsecure")) q.put("allowInsecure", String.valueOf(vmess.opt("allowInsecure")));

        String network = value(q, "type", "tcp").toLowerCase(Locale.US);
        String tlsValue = value(q, "tls", "").toLowerCase(Locale.US);
        String security = ("tls".equals(tlsValue) || "true".equals(tlsValue) || "1".equals(tlsValue))
                ? "tls" : "none";
        JSONObject stream = new JSONObject();
        stream.put("network", network);
        stream.put("security", security);
        addSecuritySettings(stream, security, q, vmess);
        addTransportSettings(stream, network, q, vmess);
        outbound.put("streamSettings", stream);
    }

    private static void buildShadowsocks(String value, JSONObject outbound, JSONObject settings) throws Exception {
        String body = value.substring(value.indexOf("://") + 3);
        int hash = body.indexOf('#');
        if (hash >= 0) body = body.substring(0, hash);
        int queryAt = body.indexOf('?');
        String queryPart = queryAt >= 0 ? body.substring(queryAt + 1) : "";
        if (queryAt >= 0) body = body.substring(0, queryAt);
        if (!queryPart.isEmpty() && query(queryPart).containsKey("plugin")) {
            throw new IllegalArgumentException("لینک Shadowsocks دارای plugin است؛ pluginهای SIP002 در این نسخه به‌صورت خودکار پشتیبانی نمی‌شوند.");
        }

        String methodPassword;
        String address;
        int port;
        int at = body.lastIndexOf('@');
        if (at >= 0) {
            methodPassword = body.substring(0, at);
            String endpoint = body.substring(at + 1);
            if (methodPassword.indexOf(':') < 0) methodPassword = decodeBase64Text(methodPassword);
            URI endpointUri = new URI("ss://" + endpoint);
            if (endpointUri.getHost() == null || endpointUri.getPort() < 1) {
                throw new IllegalArgumentException("آدرس یا پورت Shadowsocks معتبر نیست.");
            }
            address = endpointUri.getHost();
            port = endpointUri.getPort();
        } else {
            String decoded = decodeBase64Text(body);
            URI legacy = new URI("ss://" + decoded);
            String rawUser = legacy.getRawUserInfo();
            if (rawUser == null || legacy.getHost() == null || legacy.getPort() < 1) {
                throw new IllegalArgumentException("فرمت لینک Shadowsocks معتبر نیست.");
            }
            methodPassword = decode(rawUser);
            address = legacy.getHost();
            port = legacy.getPort();
        }

        int colon = methodPassword.indexOf(':');
        if (colon <= 0 || colon == methodPassword.length() - 1) {
            throw new IllegalArgumentException("روش رمزنگاری و رمز عبور Shadowsocks باید مشخص باشند.");
        }
        String method = decode(methodPassword.substring(0, colon));
        String password = decode(methodPassword.substring(colon + 1));
        JSONObject server = new JSONObject();
        server.put("address", address);
        server.put("port", port);
        server.put("method", method);
        server.put("password", password);
        settings.put("servers", new JSONArray().put(server));
        outbound.put("protocol", "shadowsocks");
    }

    private static void buildBasicProxy(String value, String scheme, JSONObject outbound,
                                        JSONObject settings) throws Exception {
        URI uri = new URI(value);
        int port = uri.getPort();
        if (port < 0) port = "https".equals(scheme) ? 443 : ("http".equals(scheme) ? 80 : 1080);
        if (uri.getHost() == null || port < 1 || port > 65535) {
            throw new IllegalArgumentException("آدرس یا پورت پروکسی معتبر نیست.");
        }
        boolean socks = scheme.startsWith("socks");
        outbound.put("protocol", socks ? "socks" : "http");
        JSONObject server = new JSONObject();
        server.put("address", uri.getHost());
        server.put("port", port);
        String info = uri.getRawUserInfo();
        if (info != null && !info.isEmpty()) {
            String[] pair = decode(info).split(":", 2);
            JSONArray users = new JSONArray();
            JSONObject credentials = new JSONObject();
            credentials.put("user", pair[0]);
            if (pair.length > 1) credentials.put("pass", pair[1]);
            users.put(credentials);
            server.put("users", users);
        }
        settings.put("servers", new JSONArray().put(server));
        if ("https".equals(scheme)) {
            outbound.put("streamSettings", new JSONObject()
                    .put("security", "tls")
                    .put("tlsSettings", new JSONObject().put("serverName", uri.getHost())));
        }
    }

    private static void addSecuritySettings(JSONObject stream, String security,
                                            Map<String, String> q, JSONObject source) throws JSONException {
        if ("tls".equals(security)) {
            JSONObject tls = new JSONObject();
            String sni = first(value(q, "sni", ""), value(q, "servername", ""), value(q, "host", ""));
            if (!sni.isEmpty()) tls.put("serverName", sni);
            String fp = value(q, "fp", "");
            if (!fp.isEmpty()) tls.put("fingerprint", fp);
            String alpn = value(q, "alpn", "");
            if (!alpn.isEmpty()) tls.put("alpn", splitCsv(alpn));
            if (isTrue(value(q, "allowInsecure", "")) || isTrue(value(q, "insecure", ""))) {
                tls.put("allowInsecure", true);
            }
            stream.put("tlsSettings", tls);
        } else if ("reality".equals(security)) {
            JSONObject reality = new JSONObject();
            putIfNotEmpty(reality, "serverName", first(value(q, "sni", ""), value(q, "servername", "")));
            putIfNotEmpty(reality, "fingerprint", value(q, "fp", ""));
            putIfNotEmpty(reality, "publicKey", value(q, "pbk", ""));
            putIfNotEmpty(reality, "shortId", value(q, "sid", ""));
            putIfNotEmpty(reality, "spiderX", value(q, "spx", ""));
            stream.put("realitySettings", reality);
        }
    }

    private static void addTransportSettings(JSONObject stream, String network,
                                             Map<String, String> q, JSONObject source) throws JSONException {
        if ("ws".equals(network)) {
            JSONObject ws = new JSONObject();
            putIfNotEmpty(ws, "path", value(q, "path", ""));
            String host = value(q, "host", "");
            if (!host.isEmpty()) ws.put("headers", new JSONObject().put("Host", host));
            putIfNotEmpty(ws, "earlyDataHeaderName", value(q, "ed", ""));
            stream.put("wsSettings", ws);
        } else if ("grpc".equals(network)) {
            JSONObject grpc = new JSONObject();
            putIfNotEmpty(grpc, "serviceName", value(q, "servicename", ""));
            putIfNotEmpty(grpc, "authority", value(q, "authority", ""));
            String mode = value(q, "mode", "");
            if (!mode.isEmpty()) grpc.put("multiMode", "multi".equalsIgnoreCase(mode));
            stream.put("grpcSettings", grpc);
        } else if ("httpupgrade".equals(network)) {
            JSONObject upgrade = new JSONObject();
            putIfNotEmpty(upgrade, "path", value(q, "path", ""));
            putIfNotEmpty(upgrade, "host", value(q, "host", ""));
            stream.put("httpupgradeSettings", upgrade);
        } else if ("xhttp".equals(network) || "splithttp".equals(network)) {
            JSONObject xhttp = new JSONObject();
            putIfNotEmpty(xhttp, "path", value(q, "path", ""));
            putIfNotEmpty(xhttp, "host", value(q, "host", ""));
            putIfNotEmpty(xhttp, "mode", value(q, "mode", ""));
            stream.put("xhttpSettings", xhttp);
        } else if ("tcp".equals(network)) {
            String headerType = value(q, "headertype", "");
            if (!headerType.isEmpty() && !"none".equalsIgnoreCase(headerType)) {
                JSONObject tcp = new JSONObject();
                tcp.put("header", new JSONObject().put("type", headerType));
                stream.put("tcpSettings", tcp);
            }
        } else if ("http".equals(network) || "h2".equals(network)) {
            JSONObject http = new JSONObject();
            String host = value(q, "host", "");
            if (!host.isEmpty()) http.put("host", splitCsv(host));
            putIfNotEmpty(http, "path", value(q, "path", ""));
            stream.put("httpSettings", http);
        }
    }

    private static void requireAddressAndPort(URI uri, String label) {
        if (uri.getHost() == null || uri.getPort() < 1 || uri.getPort() > 65535) {
            throw new IllegalArgumentException("آدرس یا پورت " + label + " معتبر نیست.");
        }
    }

    private static Map<String, String> query(String raw) throws Exception {
        Map<String, String> result = new HashMap<>();
        if (raw == null || raw.isEmpty()) return result;
        for (String part : raw.split("&")) {
            if (part.isEmpty()) continue;
            String[] kv = part.split("=", 2);
            result.put(decode(kv[0]).toLowerCase(Locale.US), kv.length > 1 ? decode(kv[1]) : "");
        }
        return result;
    }

    private static String decode(String value) throws Exception {
        return URLDecoder.decode(value.replace("+", "%2B"), "UTF-8");
    }

    private static String decodeBase64Text(String value) throws Exception {
        String clean = value.trim().replace('-', '+').replace('_', '/');
        while (clean.length() % 4 != 0) clean += "=";
        byte[] bytes;
        try {
            bytes = Base64.decode(clean, Base64.DEFAULT);
        } catch (IllegalArgumentException first) {
            bytes = Base64.decode(clean, Base64.URL_SAFE | Base64.NO_WRAP);
        }
        return new String(bytes, Charset.forName("UTF-8")).trim();
    }

    private static void copyJsonString(JSONObject source, Map<String, String> target,
                                       String sourceKey, String targetKey) {
        if (source.has(sourceKey) && !source.isNull(sourceKey)) {
            target.put(targetKey.toLowerCase(Locale.US), String.valueOf(source.opt(sourceKey)));
        }
    }

    private static int parsePort(Object raw) {
        return parseInt(raw, -1);
    }

    private static int parseInt(Object raw, int fallback) {
        if (raw == null) return fallback;
        try { return Integer.parseInt(String.valueOf(raw).trim()); }
        catch (Exception ignored) { return fallback; }
    }

    private static String value(Map<String, String> values, String key, String fallback) {
        String v = values.get(key.toLowerCase(Locale.US));
        return v == null ? fallback : v.trim();
    }

    private static String first(String... values) {
        for (String value : values) if (value != null && !value.trim().isEmpty()) return value.trim();
        return "";
    }

    private static JSONArray splitCsv(String value) throws JSONException {
        JSONArray array = new JSONArray();
        for (String item : value.split(",")) if (!item.trim().isEmpty()) array.put(item.trim());
        return array;
    }

    private static boolean isTrue(String value) {
        return "1".equals(value) || "true".equalsIgnoreCase(value) || "yes".equalsIgnoreCase(value);
    }

    private static void putIfNotEmpty(JSONObject object, String key, String value) throws JSONException {
        if (value != null && !value.trim().isEmpty()) object.put(key, value.trim());
    }
}
