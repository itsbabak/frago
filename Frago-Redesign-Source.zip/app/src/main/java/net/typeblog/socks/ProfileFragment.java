package net.typeblog.socks;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.VpnService;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import net.typeblog.socks.util.Profile;
import net.typeblog.socks.util.ProfileManager;
import net.typeblog.socks.util.ProxyUriConfig;
import net.typeblog.socks.util.Utility;
import net.typeblog.socks.util.XrayConfig;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import static net.typeblog.socks.util.Constants.*;

/** Settings pages for the lightweight native Frago navigation drawer. */
public class ProfileFragment extends PreferenceFragment implements
        Preference.OnPreferenceClickListener,
        Preference.OnPreferenceChangeListener,
        CompoundButton.OnCheckedChangeListener {

    public static final String SECTION_HOME = "home";
    public static final String SECTION_SOCKS = "socks";
    public static final String SECTION_SHADOWSOCKS = "shadowsocks";
    public static final String SECTION_VLESS = "vless";
    public static final String SECTION_VMESS = "vmess";
    public static final String SECTION_JSON = "json";
    public static final String SECTION_APPS = "apps";
    public static final String SECTION_ADVANCED = "advanced";
    private static final String ARG_SECTION = "section";
    private static final int REQUEST_VPN_PERMISSION = 0;
    private static final long STATE_REFRESH_MS = 5000L;

    private String mSection = SECTION_HOME;
    private ProfileManager mManager;
    private Profile mProfile;
    private Switch mSwitch;
    private boolean mRunning;
    private boolean mStarting;
    private boolean mStopping;
    private boolean mBound;
    private boolean mUiResumed;
    private IVpnService mBinder;

    private ListPreference mPrefProfile, mPrefRoutes;
    private EditTextPreference mPrefServer, mPrefPort, mPrefUsername, mPrefPassword,
            mPrefDns, mPrefDnsPort;
    private CheckBoxPreference mPrefUserpw, mPrefPerApp, mPrefAppBypass,
            mPrefIPv6, mPrefAuto;
    private Preference mPrefActiveConnection, mPrefSocksActivate, mPrefSocksLink,
            mPrefShadowsocksAdd, mPrefVlessAdd, mPrefVmessAdd, mPrefXrayEdit,
            mPrefXrayStatus, mPrefAppPicker, mPrefAddProfile, mPrefDeleteProfile;

    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            mBinder = IVpnService.Stub.asInterface(binder);
            updateState();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mBinder = null;
            updateState();
        }
    };

    private final Runnable mStateRunnable = new Runnable() {
        @Override
        public void run() {
            if (mSwitch == null || !mUiResumed) return;
            updateState();
            mSwitch.postDelayed(this, STATE_REFRESH_MS);
        }
    };

    public static ProfileFragment newInstance(String section) {
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_SECTION, section);
        fragment.setArguments(args);
        return fragment;
    }

    public static String sectionTitle(String section) {
        if (SECTION_SOCKS.equals(section)) return "SOCKS5";
        if (SECTION_SHADOWSOCKS.equals(section)) return "Shadowsocks";
        if (SECTION_VLESS.equals(section)) return "VLESS";
        if (SECTION_VMESS.equals(section)) return "VMess";
        if (SECTION_JSON.equals(section)) return "Custom JSON";
        if (SECTION_APPS.equals(section)) return "App selection";
        if (SECTION_ADVANCED.equals(section)) return "Advanced";
        return "Frago";
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mSection = getArguments().getString(ARG_SECTION, SECTION_HOME);
        }
        addPreferencesFromResource(layoutForSection(mSection));
        mManager = new ProfileManager(getActivity().getApplicationContext());
        initPreferences();
        reload();
    }

    private int layoutForSection(String section) {
        if (SECTION_SOCKS.equals(section)) return R.xml.settings_socks;
        if (SECTION_SHADOWSOCKS.equals(section)) return R.xml.settings_shadowsocks;
        if (SECTION_VLESS.equals(section)) return R.xml.settings_vless;
        if (SECTION_VMESS.equals(section)) return R.xml.settings_vmess;
        if (SECTION_JSON.equals(section)) return R.xml.settings_json;
        if (SECTION_APPS.equals(section)) return R.xml.settings_apps;
        if (SECTION_ADVANCED.equals(section)) return R.xml.settings_advanced;
        return R.xml.settings_home;
    }

    @Override
    public void onResume() {
        super.onResume();
        mUiResumed = true;
        if (getActivity() instanceof MainActivity) {
            mSwitch = ((MainActivity) getActivity()).getVpnSwitch();
            if (mSwitch != null) {
                mSwitch.setOnCheckedChangeListener(this);
                mSwitch.removeCallbacks(mStateRunnable);
                mSwitch.post(mStateRunnable);
            }
        }
        checkState();
    }

    @Override
    public void onPause() {
        mUiResumed = false;
        if (mSwitch != null) {
            mSwitch.removeCallbacks(mStateRunnable);
            mSwitch.setOnCheckedChangeListener(null);
        }
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        if (mSwitch != null) {
            mSwitch.removeCallbacks(mStateRunnable);
            mSwitch.setOnCheckedChangeListener(null);
            mSwitch = null;
        }
        if (mBound) {
            try { getActivity().unbindService(mConnection); }
            catch (Exception ignored) { }
            mBound = false;
            mBinder = null;
        }
        super.onDestroyView();
    }

    private void initPreferences() {
        mPrefProfile = (ListPreference) findPreference(PREF_PROFILE);
        mPrefServer = (EditTextPreference) findPreference(PREF_SERVER_IP);
        mPrefPort = (EditTextPreference) findPreference(PREF_SERVER_PORT);
        mPrefUserpw = (CheckBoxPreference) findPreference(PREF_AUTH_USERPW);
        mPrefUsername = (EditTextPreference) findPreference(PREF_AUTH_USERNAME);
        mPrefPassword = (EditTextPreference) findPreference(PREF_AUTH_PASSWORD);
        mPrefRoutes = (ListPreference) findPreference(PREF_ADV_ROUTE);
        mPrefDns = (EditTextPreference) findPreference(PREF_ADV_DNS);
        mPrefDnsPort = (EditTextPreference) findPreference(PREF_ADV_DNS_PORT);
        mPrefPerApp = (CheckBoxPreference) findPreference(PREF_ADV_PER_APP);
        mPrefAppBypass = (CheckBoxPreference) findPreference(PREF_ADV_APP_BYPASS);
        mPrefIPv6 = (CheckBoxPreference) findPreference(PREF_IPV6_PROXY);
        mPrefAuto = (CheckBoxPreference) findPreference(PREF_ADV_AUTO_CONNECT);

        mPrefActiveConnection = findPreference("active_connection");
        mPrefSocksActivate = findPreference("socks_activate");
        mPrefSocksLink = findPreference("socks_link_add");
        mPrefShadowsocksAdd = findPreference("shadowsocks_add");
        mPrefVlessAdd = findPreference("vless_add");
        mPrefVmessAdd = findPreference("vmess_add");
        mPrefXrayEdit = findPreference("xray_config_edit");
        mPrefXrayStatus = findPreference("xray_config_status");
        mPrefAppPicker = findPreference("adv_app_picker");
        mPrefAddProfile = findPreference("profile_add");
        mPrefDeleteProfile = findPreference("profile_delete");

        setChangeListener(mPrefProfile);
        setChangeListener(mPrefServer);
        setChangeListener(mPrefPort);
        setChangeListener(mPrefUserpw);
        setChangeListener(mPrefUsername);
        setChangeListener(mPrefPassword);
        setChangeListener(mPrefRoutes);
        setChangeListener(mPrefDns);
        setChangeListener(mPrefDnsPort);
        setChangeListener(mPrefPerApp);
        setChangeListener(mPrefAppBypass);
        setChangeListener(mPrefIPv6);
        setChangeListener(mPrefAuto);

        setClickListener(mPrefSocksActivate);
        setClickListener(mPrefSocksLink);
        setClickListener(mPrefShadowsocksAdd);
        setClickListener(mPrefVlessAdd);
        setClickListener(mPrefVmessAdd);
        setClickListener(mPrefXrayEdit);
        setClickListener(mPrefAppPicker);
        setClickListener(mPrefAddProfile);
        setClickListener(mPrefDeleteProfile);
    }

    private void setChangeListener(Preference preference) {
        if (preference != null) preference.setOnPreferenceChangeListener(this);
    }

    private void setClickListener(Preference preference) {
        if (preference != null) preference.setOnPreferenceClickListener(this);
    }

    @Override
    public boolean onPreferenceClick(Preference preference) {
        if (preference == mPrefXrayEdit) {
            editXrayJson();
            return true;
        }
        if (preference == mPrefSocksActivate) {
            mProfile.setXrayMode(false);
            updateSummaries();
            Toast.makeText(getActivity(), R.string.socks_active, Toast.LENGTH_SHORT).show();
            return true;
        }
        if (preference == mPrefSocksLink) {
            importProxyLinkDialog("socks");
            return true;
        }
        if (preference == mPrefShadowsocksAdd) {
            importProxyLinkDialog("shadowsocks");
            return true;
        }
        if (preference == mPrefVlessAdd) {
            importProxyLinkDialog("vless");
            return true;
        }
        if (preference == mPrefVmessAdd) {
            importProxyLinkDialog("vmess");
            return true;
        }
        if (preference == mPrefAppPicker) {
            showAppPicker();
            return true;
        }
        if (preference == mPrefAddProfile) {
            addProfile();
            return true;
        }
        if (preference == mPrefDeleteProfile) {
            removeProfile();
            return true;
        }
        return false;
    }

    @Override
    public boolean onPreferenceChange(Preference preference, Object newValue) {
        if (preference == mPrefProfile) {
            String name = newValue.toString();
            Profile selected = mManager.getProfile(name);
            if (selected == null) return false;
            mProfile = selected;
            mManager.switchDefault(name);
            reload();
            return true;
        }
        if (preference == mPrefServer) {
            mProfile.setServer(newValue.toString());
            resetText(mPrefServer, newValue);
            return true;
        }
        if (preference == mPrefPort) {
            try {
                int port = Integer.parseInt(newValue.toString().trim());
                if (port < 1 || port > 65535) return false;
                mProfile.setPort(port);
                resetText(mPrefPort, newValue);
                return true;
            } catch (NumberFormatException e) {
                return false;
            }
        }
        if (preference == mPrefUserpw) {
            mProfile.setIsUserpw(Boolean.parseBoolean(newValue.toString()));
            return true;
        }
        if (preference == mPrefUsername) {
            mProfile.setUsername(newValue.toString());
            resetText(mPrefUsername, newValue);
            return true;
        }
        if (preference == mPrefPassword) {
            mProfile.setPassword(newValue.toString());
            resetText(mPrefPassword, newValue);
            return true;
        }
        if (preference == mPrefRoutes) {
            mProfile.setRoute(newValue.toString());
            resetList(mPrefRoutes, newValue);
            return true;
        }
        if (preference == mPrefDns) {
            mProfile.setDns(newValue.toString().trim());
            resetText(mPrefDns, newValue);
            return true;
        }
        if (preference == mPrefDnsPort) {
            try {
                int port = Integer.parseInt(newValue.toString().trim());
                if (port < 1 || port > 65535) return false;
                mProfile.setDnsPort(port);
                resetText(mPrefDnsPort, newValue);
                return true;
            } catch (NumberFormatException e) {
                return false;
            }
        }
        if (preference == mPrefPerApp) {
            mProfile.setIsPerApp(Boolean.parseBoolean(newValue.toString()));
            return true;
        }
        if (preference == mPrefAppBypass) {
            mProfile.setIsBypassApp(Boolean.parseBoolean(newValue.toString()));
            return true;
        }
        if (preference == mPrefIPv6) {
            mProfile.setHasIPv6(Boolean.parseBoolean(newValue.toString()));
            return true;
        }
        if (preference == mPrefAuto) {
            mProfile.setAutoConnect(Boolean.parseBoolean(newValue.toString()));
            return true;
        }
        return false;
    }

    @Override
    public void onCheckedChanged(CompoundButton button, boolean checked) {
        if (checked) startVpn();
        else stopVpn();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_VPN_PERMISSION) {
            if (resultCode == Activity.RESULT_OK) {
                Utility.startVpn(getActivity(), mProfile);
                checkState();
            } else {
                mStarting = false;
                updateState();
            }
        }
    }

    private void editXrayJson() {
        String current = mProfile.getXrayConfig();
        if (TextUtils.isEmpty(current)) {
            current = "{\n"
                    + "  \"log\": {\n    \"loglevel\": \"warning\"\n  },\n"
                    + "  \"outbounds\": [\n"
                    + "    {\n      \"tag\": \"direct\",\n      \"protocol\": \"freedom\"\n    }\n"
                    + "  ]\n} ";
        }
        final EditText editor = new EditText(getActivity());
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editor.setTypeface(android.graphics.Typeface.MONOSPACE);
        editor.setText(current);
        editor.setSelection(0);
        editor.setMinLines(14);
        editor.setMaxLines(24);
        int padding = (int) (16 * getResources().getDisplayMetrics().density);
        editor.setPadding(padding, padding, padding, padding);
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.xray_edit)
                .setView(editor)
                .setPositiveButton(R.string.xray_save, (dialog, which) ->
                        saveXrayConfig(editor.getText().toString()))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void importProxyLinkDialog(String expected) {
        final EditText input = new EditText(getActivity());
        input.setSingleLine(false);
        input.setMinLines(2);
        if ("vless".equals(expected)) input.setHint("vless://...");
        else if ("vmess".equals(expected)) input.setHint("vmess://...");
        else if ("shadowsocks".equals(expected)) input.setHint("ss://...");
        else input.setHint("socks5://...  or  socks://...");

        new AlertDialog.Builder(getActivity())
                .setTitle("Add " + ("shadowsocks".equals(expected) ? "Shadowsocks"
                        : expected.toUpperCase(Locale.US)) + " link")
                .setView(input)
                .setPositiveButton(R.string.xray_save, (dialog, which) -> {
                    try {
                        String link = input.getText().toString().trim();
                        String lower = link.toLowerCase(Locale.US);
                        boolean valid;
                        if ("socks".equals(expected)) {
                            valid = lower.startsWith("socks5://") || lower.startsWith("socks://");
                        } else if ("shadowsocks".equals(expected)) {
                            valid = lower.startsWith("ss://") || lower.startsWith("shadowsocks://");
                        } else {
                            valid = lower.startsWith(expected + "://");
                        }
                        if (!valid) throw new IllegalArgumentException("This section accepts only "
                                + expected.toUpperCase(Locale.US) + " links.");
                        saveXrayConfig(ProxyUriConfig.toXrayJson(link));
                    } catch (Exception e) {
                        Toast.makeText(getActivity(), getString(R.string.xray_import_error,
                                e.getMessage()), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void saveXrayConfig(String raw) {
        try {
            XrayConfig.Prepared prepared = XrayConfig.prepare(raw);
            mProfile.setXrayConfig(prepared.json);
            mProfile.setXrayMode(true);
            updateSummaries();
            Toast.makeText(getActivity(), R.string.xray_import_ok, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(getActivity(), getString(R.string.xray_import_error,
                    e.getMessage()), Toast.LENGTH_LONG).show();
        }
    }

    private void showAppPicker() {
        final PackageManager packageManager = getActivity().getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN, null);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> resolved = packageManager.queryIntentActivities(launcher, 0);
        Collections.sort(resolved, new ResolveInfo.DisplayNameComparator(packageManager));

        final List<String> packages = new ArrayList<>();
        final List<CharSequence> labels = new ArrayList<>();
        Set<String> selected = new HashSet<>();
        String saved = mProfile.getAppList();
        if (!TextUtils.isEmpty(saved)) {
            for (String item : saved.split("\n")) {
                if (!TextUtils.isEmpty(item.trim())) selected.add(item.trim());
            }
        }

        for (ResolveInfo info : resolved) {
            if (info.activityInfo == null) continue;
            String packageName = info.activityInfo.packageName;
            if (packageName.equals(getActivity().getPackageName()) || packages.contains(packageName)) continue;
            packages.add(packageName);
            // Only the app's human-readable label is displayed. The package name stays internal.
            labels.add(info.loadLabel(packageManager));
        }

        if (packages.isEmpty()) {
            Toast.makeText(getActivity(), R.string.adv_app_picker_empty, Toast.LENGTH_SHORT).show();
            return;
        }

        boolean[] checked = new boolean[packages.size()];
        for (int i = 0; i < packages.size(); i++) checked[i] = selected.contains(packages.get(i));

        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.adv_app_picker)
                .setMultiChoiceItems(labels.toArray(new CharSequence[0]), checked,
                        (dialog, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton(R.string.xray_save, (dialog, which) -> {
                    StringBuilder list = new StringBuilder();
                    for (int i = 0; i < packages.size(); i++) {
                        if (checked[i]) {
                            if (list.length() > 0) list.append('\n');
                            list.append(packages.get(i));
                        }
                    }
                    mProfile.setAppList(list.toString());
                    mProfile.setIsPerApp(true);
                    if (mPrefPerApp != null) mPrefPerApp.setChecked(true);
                    updateAppPickerSummary();
                    Toast.makeText(getActivity(), R.string.adv_app_picker_saved, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void reload() {
        if (mProfile == null) mProfile = mManager.getDefault();
        if (mProfile == null) return;

        if (mPrefProfile != null) {
            mPrefProfile.setEntries(mManager.getProfiles());
            mPrefProfile.setEntryValues(mManager.getProfiles());
            mPrefProfile.setValue(mProfile.getName());
            mPrefProfile.setSummary(mProfile.getName());
        }
        if (mPrefServer != null) mPrefServer.setText(mProfile.getServer());
        if (mPrefPort != null) mPrefPort.setText(String.valueOf(mProfile.getPort()));
        if (mPrefUserpw != null) mPrefUserpw.setChecked(mProfile.isUserPw());
        if (mPrefUsername != null) mPrefUsername.setText(mProfile.getUsername());
        if (mPrefPassword != null) mPrefPassword.setText(mProfile.getPassword());
        if (mPrefRoutes != null) {
            mPrefRoutes.setValue(mProfile.getRoute());
            mPrefRoutes.setSummary(mPrefRoutes.getEntry());
        }
        if (mPrefDns != null) mPrefDns.setText(mProfile.getDns());
        if (mPrefDnsPort != null) mPrefDnsPort.setText(String.valueOf(mProfile.getDnsPort()));
        if (mPrefPerApp != null) mPrefPerApp.setChecked(mProfile.isPerApp());
        if (mPrefAppBypass != null) mPrefAppBypass.setChecked(mProfile.isBypassApp());
        if (mPrefIPv6 != null) mPrefIPv6.setChecked(mProfile.hasIPv6());
        if (mPrefAuto != null) mPrefAuto.setChecked(mProfile.autoConnect());

        resetText(mPrefServer, mPrefPort, mPrefUsername, mPrefPassword, mPrefDns, mPrefDnsPort);
        updateSummaries();
    }

    private void updateSummaries() {
        if (mPrefActiveConnection != null) {
            mPrefActiveConnection.setSummary(mProfile.isXrayMode()
                    ? getString(R.string.active_xray)
                    : getString(R.string.active_socks));
        }
        if (mPrefXrayStatus != null) {
            String config = mProfile.getXrayConfig();
            if (TextUtils.isEmpty(config)) {
                mPrefXrayStatus.setSummary(R.string.xray_not_configured);
            } else {
                try {
                    XrayConfig.Prepared prepared = XrayConfig.prepare(config);
                    mPrefXrayStatus.setSummary(getString(R.string.xray_configured,
                            prepared.socksPort, mProfile.isXrayMode() ? "Active" : "Saved"));
                } catch (Exception e) {
                    mPrefXrayStatus.setSummary(R.string.xray_config_invalid);
                }
            }
        }
        updateAppPickerSummary();
    }

    private void updateAppPickerSummary() {
        if (mPrefAppPicker == null || mProfile == null) return;
        String apps = mProfile.getAppList();
        int count = 0;
        if (!TextUtils.isEmpty(apps)) {
            for (String item : apps.split("\n")) if (!TextUtils.isEmpty(item.trim())) count++;
        }
        mPrefAppPicker.setSummary(getResources().getQuantityString(
                R.plurals.adv_selected_apps, count, count));
    }

    private void resetText(EditTextPreference preference, Object value) {
        if (preference != null) preference.setSummary(value == null ? "" : value.toString());
    }

    private void resetList(ListPreference preference, Object value) {
        if (preference != null) preference.setSummary(value == null ? "" : value.toString());
    }

    private void resetText(EditTextPreference... preferences) {
        for (EditTextPreference preference : preferences) {
            if (preference != null) preference.setSummary(preference.getText());
        }
    }

    private void addProfile() {
        final EditText edit = new EditText(getActivity());
        edit.setSingleLine(true);
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.prof_add)
                .setView(edit)
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    String name = edit.getText().toString().trim();
                    if (!TextUtils.isEmpty(name)) {
                        Profile profile = mManager.addProfile(name);
                        if (profile != null) {
                            mProfile = profile;
                            reload();
                            return;
                        }
                    }
                    Toast.makeText(getActivity(), getString(R.string.err_add_prof, name),
                            Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void removeProfile() {
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.prof_del)
                .setMessage(getString(R.string.prof_del_confirm, mProfile.getName()))
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    if (!mManager.removeProfile(mProfile.getName())) {
                        Toast.makeText(getActivity(), getString(R.string.err_del_prof,
                                mProfile.getName()), Toast.LENGTH_SHORT).show();
                    } else {
                        mProfile = mManager.getDefault();
                        reload();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void checkState() {
        if (mSwitch != null) {
            mSwitch.setEnabled(false);
            mSwitch.setOnCheckedChangeListener(null);
        }
        if (!mBound && getActivity() != null) {
            mBound = getActivity().bindService(new Intent(getActivity(), SocksVpnService.class),
                    mConnection, Context.BIND_AUTO_CREATE);
            if (!mBound) updateState();
        }
    }

    private void updateState() {
        if (mBinder == null) {
            mRunning = false;
        } else {
            try { mRunning = mBinder.isRunning(); }
            catch (Exception e) { mRunning = false; }
        }
        if (mSwitch == null) return;

        mSwitch.setOnCheckedChangeListener(null);
        mSwitch.setChecked(mRunning);
        if ((!mStarting && !mStopping) || (mStarting && mRunning) || (mStopping && !mRunning)) {
            mSwitch.setEnabled(true);
        }
        if (mStarting && mRunning) mStarting = false;
        if (mStopping && !mRunning) mStopping = false;
        mSwitch.setOnCheckedChangeListener(this);
    }

    private void startVpn() {
        if (mStarting || mRunning) return;
        mStarting = true;
        Intent permissionIntent = VpnService.prepare(getActivity());
        if (permissionIntent != null) {
            startActivityForResult(permissionIntent, REQUEST_VPN_PERMISSION);
        } else {
            Utility.startVpn(getActivity(), mProfile);
            checkState();
        }
    }

    private void stopVpn() {
        if (mBinder == null) return;
        mStopping = true;
        try { mBinder.stop(); }
        catch (Exception ignored) { }
        updateState();
    }
}
