package net.typeblog.socks;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Method;
import android.util.Base64;

/** Embedded Xray-core bridge. The native libXray AAR is produced by CI and packaged in the APK. */
final class XrayEngine {
    private static final int API_VERSION = 3;
    private static final String CLASS_NAME = "libXray.LibXray";
    private static volatile boolean running;

    private XrayEngine() { }

    private static String invoke(String method, JSONObject payload) throws Exception {
        JSONObject request = new JSONObject();
        request.put("apiVersion", API_VERSION);
        request.put("method", method);
        request.put("payload", payload == null ? new JSONObject() : payload);
        Class<?> bridge = Class.forName(CLASS_NAME);
        Method invoke = bridge.getMethod("invoke", String.class);
        Object response = invoke.invoke(null, request.toString());
        if (response == null) throw new IllegalStateException("libXray returned an empty response");
        JSONObject result = new JSONObject(response.toString());
        if (!result.optBoolean("success", false)) {
            throw new IllegalStateException(result.optString("error", "Xray engine error"));
        }
        return result.optJSONObject("data") == null ? "{}" : result.getJSONObject("data").toString();
    }

    static synchronized void start(String shareLink, String expectedProtocol) throws Exception {
        if (running) stop();
        if (shareLink == null || shareLink.trim().isEmpty()) {
            throw new IllegalArgumentException("لینک کانفیگ وارد نشده است");
        }
        JSONArray outbounds;
        String cleanLink = shareLink.trim();
        String requiredScheme = "vless".equals(expectedProtocol) ? "vless://"
                : ("vmess".equals(expectedProtocol) ? "vmess://" : "ss://");
        if (!cleanLink.toLowerCase(java.util.Locale.ROOT).startsWith(requiredScheme)) {
            throw new IllegalArgumentException("لینک واردشده با نوع پروتکل انتخاب‌شده مطابقت ندارد");
        }
        if (cleanLink.startsWith("vmess://") && !cleanLink.contains("@")) {
            outbounds = new JSONArray();
            outbounds.put(parseLegacyVmess(cleanLink));
        } else {
            JSONObject parsePayload = new JSONObject();
            parsePayload.put("text", cleanLink);
            JSONObject parsed = new JSONObject(invoke("convertShareLinksToXrayJson", parsePayload));
            outbounds = parsed.optJSONArray("outbounds");
        }
        if (outbounds == null || outbounds.length() == 0) {
            throw new IllegalArgumentException("کانفیگ VLESS / VMess AEAD / Shadowsocks معتبر نیست");
        }

        JSONObject config = new JSONObject();
        JSONObject log = new JSONObject();
        log.put("loglevel", "none");
        config.put("log", log);

        JSONArray inbounds = new JSONArray();
        JSONObject socks = new JSONObject();
        socks.put("tag", "frago-socks-in");
        socks.put("listen", "127.0.0.1");
        socks.put("port", 1081);
        socks.put("protocol", "socks");
        JSONObject socksSettings = new JSONObject();
        socksSettings.put("auth", "noauth");
        socksSettings.put("udp", true);
        socks.put("settings", socksSettings);
        inbounds.put(socks);
        config.put("inbounds", inbounds);
        config.put("outbounds", outbounds);

        JSONObject payload = new JSONObject();
        payload.put("xrayJson", config.toString());
        invoke("runXray", payload);
        running = true;
    }


    private static JSONObject parseLegacyVmess(String link) throws Exception {
        String encoded = link.substring("vmess://".length()).trim();
        byte[] raw;
        try { raw = Base64.decode(encoded, Base64.DEFAULT); }
        catch (IllegalArgumentException error) { throw new IllegalArgumentException("لینک VMess نامعتبر است"); }
        JSONObject source = new JSONObject(new String(raw, java.nio.charset.StandardCharsets.UTF_8));
        String address = source.optString("add", "").trim();
        int port = Integer.parseInt(source.optString("port", "0"));
        String id = source.optString("id", "").trim();
        if (address.isEmpty() || id.isEmpty() || port < 1 || port > 65535) {
            throw new IllegalArgumentException("اطلاعات سرور VMess ناقص است");
        }
        JSONObject user = new JSONObject();
        user.put("id", id);
        user.put("alterId", Math.max(0, source.optInt("aid", 0)));
        user.put("security", source.optString("scy", "auto"));
        JSONArray users = new JSONArray().put(user);
        JSONObject vnext = new JSONObject();
        vnext.put("address", address);
        vnext.put("port", port);
        vnext.put("users", users);
        JSONObject settings = new JSONObject();
        settings.put("vnext", new JSONArray().put(vnext));
        JSONObject outbound = new JSONObject();
        outbound.put("tag", "frago-proxy");
        outbound.put("protocol", "vmess");
        outbound.put("settings", settings);

        String network = source.optString("net", "tcp");
        String tls = source.optString("tls", "");
        JSONObject stream = new JSONObject();
        stream.put("network", network.isEmpty() ? "tcp" : network);
        if ("tls".equalsIgnoreCase(tls) || "1".equals(tls)) {
            stream.put("security", "tls");
            JSONObject tlsSettings = new JSONObject();
            String sni = source.optString("sni", source.optString("host", address));
            if (!sni.isEmpty()) tlsSettings.put("serverName", sni);
            tlsSettings.put("allowInsecure", false);
            stream.put("tlsSettings", tlsSettings);
        } else {
            stream.put("security", "none");
        }
        if ("ws".equals(network)) {
            JSONObject ws = new JSONObject();
            String path = source.optString("path", "/");
            ws.put("path", path.isEmpty() ? "/" : path);
            JSONObject headers = new JSONObject();
            String host = source.optString("host", "");
            if (!host.isEmpty()) headers.put("Host", host);
            ws.put("headers", headers);
            stream.put("wsSettings", ws);
        } else if ("grpc".equals(network)) {
            JSONObject grpc = new JSONObject();
            grpc.put("serviceName", source.optString("path", source.optString("serviceName", "")));
            stream.put("grpcSettings", grpc);
        } else if ("tcp".equals(network) && "http".equals(source.optString("type", ""))) {
            JSONObject tcp = new JSONObject();
            JSONObject header = new JSONObject();
            header.put("type", "http");
            JSONObject request = new JSONObject();
            request.put("path", new JSONArray().put(source.optString("path", "/")));
            JSONObject headers = new JSONObject();
            String host = source.optString("host", "");
            if (!host.isEmpty()) headers.put("Host", new JSONArray().put(host));
            request.put("headers", headers);
            header.put("request", request);
            tcp.put("header", header);
            stream.put("tcpSettings", tcp);
        }
        outbound.put("streamSettings", stream);
        return outbound;
    }

    static synchronized void stop() {
        if (!running) return;
        try { invoke("stopXray", new JSONObject()); } catch (Exception ignored) { }
        running = false;
    }
}
