# Frago 1.2.0

Frago is an Android VPN client with a lightweight native ByeDPI/Fragment path and an optional embedded Xray-core engine.

## Connection modes

- **Fragment / ByeDPI** — existing native ByeDPI + tun2socks path.
- **SOCKS5** — existing direct SOCKS5 path.
- **VLESS / VMess / Shadowsocks** — embedded Xray-core (`XTLS/libXray`) converts share links to Xray JSON and exposes a local SOCKS inbound consumed by the existing tun2socks bridge.

The Xray modes require `app/libs/libXray.aar`. The GitHub Actions workflow builds this AAR from upstream `XTLS/libXray` and packages it in the APK; it is not downloaded by the installed app. For a local build, first build the upstream Android AAR with `python3 build/main.py android` in the libXray repository and copy the resulting AAR to `app/libs/libXray.aar`, then run the normal Gradle build.

### Supported link formats

- VLESS share links supported by the pinned upstream libXray parser, including its supported TLS/REALITY/transport fields.
- VMess AEAD share links supported by libXray, plus legacy `vmess://Base64(JSON)` links with TCP, WebSocket and gRPC mappings.
- Shadowsocks share links supported by libXray.

Clash/Mihomo profiles are not accepted as share links. The Xray engine is bundled in the APK; no runtime engine download is performed.

## Build

The GitHub Actions workflow installs the Android SDK/NDK, builds the upstream libXray Android AAR, compiles ByeDPI, and assembles the ARM64 APK.

## Size

The Xray engine is substantially larger than the original Fragment/SOCKS-only app. The 3–4 MB APK target cannot be guaranteed with an embedded Xray-core engine. ARM64-only packaging is enabled to reduce the final APK size.
