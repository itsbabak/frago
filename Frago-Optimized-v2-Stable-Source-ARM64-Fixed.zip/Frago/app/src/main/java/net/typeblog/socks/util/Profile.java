package net.typeblog.socks.util;

import android.content.SharedPreferences;

public class Profile {
    private final SharedPreferences mPref;
    private final String mName;
    private final String mPrefix;

    Profile(SharedPreferences pref, String name) {
        mPref = pref;
        mName = name;
        mPrefix = prefPrefix(name);
        migrateLegacySettings();
    }

    public String getName() {
        return mName;
    }

    public String getProtocol() { return "fragment"; }
    public void setProtocol(String protocol) { /* Fragment-only build; legacy proxy protocols are ignored. */ }

    public String getServer() {
        return mPref.getString(key("server"), "127.0.0.1");
    }

    public void setServer(String server) {
        mPref.edit().putString(key("server"), server).apply();
    }

    public int getPort() {
        return mPref.getInt(key("port"), 1080);
    }

    public void setPort(int port) {
        mPref.edit().putInt(key("port"), port).apply();
    }

    public boolean isUserPw() {
        return mPref.getBoolean(key("userpw"), false);
    }

    public void setIsUserpw(boolean is) {
        mPref.edit().putBoolean(key("userpw"), is).apply();
    }

    public String getUsername() {
        return mPref.getString(key("username"), "");
    }

    public void setUsername(String username) {
        mPref.edit().putString(key("username"), username).apply();
    }

    public String getPassword() {
        return mPref.getString(key("password"), "");
    }

    public void setPassword(String password) {
        mPref.edit().putString(key("password"), password).apply();
    }

    public boolean isPerApp() {
        return mPref.getBoolean(key("perapp"), false);
    }

    public void setIsPerApp(boolean is) {
        mPref.edit().putBoolean(key("perapp"), is).apply();
    }

    public boolean isBypassApp() {
        return mPref.getBoolean(key("appbypass"), false);
    }

    public void setIsBypassApp(boolean is) {
        mPref.edit().putBoolean(key("appbypass"), is).apply();
    }

    public String getAppList() {
        return mPref.getString(key("applist"), "");
    }

    public void setAppList(String list) {
        mPref.edit().putString(key("applist"), list).apply();
    }

    public boolean autoConnect() {
        return mPref.getBoolean(key("auto"), false);
    }

    public void setAutoConnect(boolean auto) {
        mPref.edit().putBoolean(key("auto"), auto).apply();
    }

    public String getTlsRecordPositions() {
        return mPref.getString(key("tlsrec_positions"), ByeDpiSettings.DEFAULT_POSITION);
    }

    public void setTlsRecordPositions(String value) {
        mPref.edit().putString(key("tlsrec_positions"), value).apply();
    }

    public String getDesyncMode() {
        return ByeDpiSettings.normalizeDesyncMode(
                mPref.getString(key("desync_mode"), ByeDpiSettings.DEFAULT_DESYNC_MODE));
    }

    public void setDesyncMode(String mode) {
        mPref.edit().putString(key("desync_mode"), ByeDpiSettings.normalizeDesyncMode(mode)).apply();
    }

    public String getDnsHostOverrides() {
        String prefKey = key("dns_host_overrides");
        if (mPref.contains(prefKey)) return mPref.getString(prefKey, "");
        String defaults = ByeDpiSettings.DEFAULT_HOSTS;
        mPref.edit().putString(prefKey, defaults).apply();
        return defaults;
    }

    public void setDnsHostOverrides(String value) {
        mPref.edit().putString(key("dns_host_overrides"), value).apply();
    }

    private void migrateLegacySettings() {
        String legacyKey = key("fragment_json");
        SharedPreferences.Editor edit = mPref.edit();
        if (mPref.contains(legacyKey)) {
            String raw = mPref.getString(legacyKey, "");
            String tlsKey = key("tlsrec_positions");
            String hostsKey = key("dns_host_overrides");
            if (!mPref.contains(tlsKey)) edit.putString(tlsKey, LegacyProfileMigration.tlsPositions(raw));
            if (!mPref.contains(hostsKey)) edit.putString(hostsKey, LegacyProfileMigration.hostOverrides(raw));
            edit.remove(legacyKey);
        }
        edit.remove(key("private_dns"))
                .remove(key("dot_enabled"))
                .remove(key("doh_url"))
                .remove(key("doh_servers"))
                .remove(key("secure_dns_enabled"))
                .apply();
    }

    void delete() {
        mPref.edit()
                .remove(key("server"))
                .remove(key("port"))
                .remove(key("userpw"))
                .remove(key("username"))
                .remove(key("password"))
                .remove(key("perapp"))
                .remove(key("appbypass"))
                .remove(key("applist"))
                .remove(key("auto"))
                .remove(key("fragment_json"))
                .remove(key("tlsrec_positions"))
                .remove(key("desync_mode"))
                .remove(key("dns_host_overrides"))
                .remove(key("doh_url"))
                .remove(key("doh_servers"))
                .remove(key("secure_dns_enabled"))
                .remove(key("protocol"))
                .apply();
    }

    private String key(String k) {
        return mPrefix + k;
    }

    private static String prefPrefix(String name) {
        return name.replace("_", "__").replace(" ", "_");
    }
}
