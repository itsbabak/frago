package net.typeblog.socks;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import net.typeblog.socks.engine.FragoConfig;
import net.typeblog.socks.util.Profile;
import net.typeblog.socks.util.ProfileManager;
import net.typeblog.socks.util.Utility;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import static net.typeblog.socks.util.Constants.PREF_PROFILE;

public final class ProfileFragment extends PreferenceFragment implements
        Preference.OnPreferenceClickListener, Preference.OnPreferenceChangeListener,
        android.widget.CompoundButton.OnCheckedChangeListener {
    private static final int REQUEST_IMPORT_JSON = 1001;
    private static final int REQUEST_VPN_PERMISSION = 1002;

    private ProfileManager manager;
    private Profile profile;
    private ListPreference profilePreference;
    private Preference importPreference;
    private Preference editPreference;
    private Preference appsPreference;
    private CheckBoxPreference autoConnectPreference;
    private Switch switchView;
    private IVpnService binder;
    private boolean bound;
    private boolean running;
    private boolean starting;
    private boolean stopping;

    private final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder service) {
            binder = IVpnService.Stub.asInterface(service);
            updateState();
        }
        @Override public void onServiceDisconnected(ComponentName name) {
            binder = null;
            bound = false;
            updateState();
        }
    };

    private final Runnable statePoll = new Runnable() {
        @Override public void run() {
            updateState();
            if (switchView != null) switchView.postDelayed(this, 1500L);
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings);
        setHasOptionsMenu(true);
        manager = new ProfileManager(getActivity().getApplicationContext());
        profile = manager.getDefault();

        profilePreference = (ListPreference) findPreference(PREF_PROFILE);
        importPreference = findPreference("frago_json_import");
        editPreference = findPreference("frago_json_edit");
        appsPreference = findPreference("frago_apps_select");
        autoConnectPreference = (CheckBoxPreference) findPreference("frago_auto_connect");

        profilePreference.setOnPreferenceChangeListener(this);
        importPreference.setOnPreferenceClickListener(this);
        editPreference.setOnPreferenceClickListener(this);
        appsPreference.setOnPreferenceClickListener(this);
        autoConnectPreference.setOnPreferenceChangeListener(this);
        reload();
    }

    @Override public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.main, menu);
        MenuItem switchItem = menu.findItem(R.id.switch_main);
        switchView = switchItem.getActionView().findViewById(R.id.switch_action_button);
        switchView.setOnCheckedChangeListener(this);
        switchView.post(statePoll);
        checkService();
    }

    @Override public void onDestroyView() {
        if (switchView != null) switchView.removeCallbacks(statePoll);
        if (bound) {
            try { getActivity().unbindService(connection); } catch (Exception ignored) { }
            bound = false;
        }
        binder = null;
        super.onDestroyView();
    }

    @Override public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.prof_add) {
            addProfile();
            return true;
        }
        if (item.getItemId() == R.id.prof_del) {
            removeProfile();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override public boolean onPreferenceClick(Preference preference) {
        if (preference == importPreference) {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            startActivityForResult(intent, REQUEST_IMPORT_JSON);
            return true;
        }
        if (preference == editPreference) {
            editJson();
            return true;
        }
        if (preference == appsPreference) {
            chooseApps();
            return true;
        }
        return false;
    }

    @Override public boolean onPreferenceChange(Preference preference, Object value) {
        if (preference == profilePreference) {
            profile = manager.getProfile(value.toString());
            if (profile == null) return false;
            manager.switchDefault(profile.getName());
            reload();
            return true;
        }
        if (preference == autoConnectPreference) {
            profile.setAutoConnect(Boolean.parseBoolean(value.toString()));
            return true;
        }
        return false;
    }

    @Override public void onCheckedChanged(android.widget.CompoundButton button, boolean checked) {
        if (checked) startVpn(); else stopVpn();
    }

    @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT_JSON) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                importJson(data.getData());
            }
            return;
        }
        if (requestCode == REQUEST_VPN_PERMISSION) {
            if (resultCode == Activity.RESULT_OK) {
                Utility.startVpn(getActivity(), profile);
                starting = true;
                checkService();
            } else {
                starting = false;
                if (switchView != null) switchView.setChecked(false);
                Toast.makeText(getActivity(), R.string.frago_vpn_permission_required, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void importJson(Uri uri) {
        try (InputStream in = getActivity().getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalArgumentException("فایل قابل خواندن نیست.");
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder json = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                json.append(line).append('\n');
                if (json.length() > 1024 * 1024) throw new IllegalArgumentException("حجم JSON بیشتر از ۱ مگابایت است.");
            }
            saveJson(json.toString());
        } catch (Exception e) {
            showError(e.getMessage());
        }
    }

    private void saveJson(String raw) {
        try {
            FragoConfig parsed = FragoConfig.parse(raw);
            profile.setFragoJson(raw);
            importPreference.setSummary(getString(R.string.frago_json_imported, parsed.socksPort, parsed.dohUrl));
            editPreference.setEnabled(true);
            Toast.makeText(getActivity(), R.string.frago_json_saved, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            showError(e.getMessage());
        }
    }

    private void editJson() {
        String current = profile.getFragoJson();
        if (TextUtils.isEmpty(current)) {
            Toast.makeText(getActivity(), R.string.frago_json_empty, Toast.LENGTH_SHORT).show();
            return;
        }
        EditText editor = new EditText(getActivity());
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editor.setTypeface(android.graphics.Typeface.MONOSPACE);
        editor.setText(current);
        editor.setSelection(0);
        editor.setMinLines(14);
        editor.setMaxLines(24);
        int padding = (int) (16 * getResources().getDisplayMetrics().density);
        editor.setPadding(padding, padding, padding, padding);
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.frago_json_edit)
                .setView(editor)
                .setPositiveButton(R.string.save, (dialog, which) -> saveJson(editor.getText().toString()))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void showError(String message) {
        Toast.makeText(getActivity(), getString(R.string.frago_json_error,
                TextUtils.isEmpty(message) ? "خطای نامشخص" : message), Toast.LENGTH_LONG).show();
    }

    private void reload() {
        if (profile == null) profile = manager.getDefault();
        profilePreference.setEntries(manager.getProfiles());
        profilePreference.setEntryValues(manager.getProfiles());
        profilePreference.setValue(profile.getName());
        profilePreference.setSummary(profile.getName());
        autoConnectPreference.setChecked(profile.autoConnect());
        java.util.Set<String> selectedApps = profile.getSelectedApps();
        appsPreference.setSummary(selectedApps.isEmpty()
                ? getString(R.string.frago_apps_all)
                : getString(R.string.frago_apps_selected, selectedApps.size()));
        String json = profile.getFragoJson();
        editPreference.setEnabled(!TextUtils.isEmpty(json));
        if (TextUtils.isEmpty(json)) {
            importPreference.setSummary(R.string.frago_json_empty_summary);
        } else {
            try {
                FragoConfig config = FragoConfig.parse(json);
                importPreference.setSummary(getString(R.string.frago_json_imported, config.socksPort, config.dohUrl));
            } catch (Exception e) {
                importPreference.setSummary(R.string.frago_json_invalid_summary);
            }
        }
    }


    private void chooseApps() {
        try {
            android.content.pm.PackageManager pm = getActivity().getPackageManager();
            Intent launcher = new Intent(Intent.ACTION_MAIN, null);
            launcher.addCategory(Intent.CATEGORY_LAUNCHER);
            java.util.List<android.content.pm.ResolveInfo> apps = pm.queryIntentActivities(launcher, 0);
            java.util.Collections.sort(apps, (a, b) -> String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
            java.util.ArrayList<String> packages = new java.util.ArrayList<>();
            java.util.ArrayList<String> labels = new java.util.ArrayList<>();
            java.util.Set<String> current = profile.getSelectedApps();
            boolean[] checked = new boolean[apps.size()];
            for (int i = 0; i < apps.size(); i++) {
                android.content.pm.ResolveInfo info = apps.get(i);
                String pkg = info.activityInfo.packageName;
                if (pkg.equals(getActivity().getPackageName())) continue;
                packages.add(pkg);
                labels.add(String.valueOf(info.loadLabel(pm)));
            }
            checked = new boolean[packages.size()];
            for (int i = 0; i < packages.size(); i++) checked[i] = current.contains(packages.get(i));
            String[] names = labels.toArray(new String[0]);
            new AlertDialog.Builder(getActivity())
                    .setTitle(R.string.frago_apps_select)
                    .setMultiChoiceItems(names, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                    .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                        java.util.HashSet<String> selected = new java.util.HashSet<>();
                        for (int i = 0; i < packages.size(); i++) if (checked[i]) selected.add(packages.get(i));
                        profile.setSelectedApps(selected);
                        appsPreference.setSummary(selected.isEmpty() ? getString(R.string.frago_apps_all)
                                : getString(R.string.frago_apps_selected, selected.size()));
                    })
                    .setNegativeButton(android.R.string.cancel, null)
                    .show();
        } catch (Exception e) { showError(e.getMessage()); }
    }

    private void addProfile() {
        EditText nameInput = new EditText(getActivity());
        nameInput.setSingleLine(true);
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.prof_add)
                .setView(nameInput)
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    String name = nameInput.getText().toString().trim();
                    if (!TextUtils.isEmpty(name)) {
                        Profile created = manager.addProfile(name);
                        if (created != null) {
                            profile = created;
                            reload();
                            return;
                        }
                    }
                    Toast.makeText(getActivity(), getString(R.string.err_add_prof, name), Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void removeProfile() {
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.prof_del)
                .setMessage(getString(R.string.prof_del_confirm, profile.getName()))
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    if (manager.removeProfile(profile.getName())) {
                        profile = manager.getDefault();
                        reload();
                    } else {
                        Toast.makeText(getActivity(), getString(R.string.err_del_prof, profile.getName()), Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void startVpn() {
        if (TextUtils.isEmpty(profile.getFragoJson())) {
            if (switchView != null) switchView.setChecked(false);
            Toast.makeText(getActivity(), R.string.frago_json_empty, Toast.LENGTH_LONG).show();
            return;
        }
        try {
            FragoConfig.parse(profile.getFragoJson());
        } catch (Exception e) {
            if (switchView != null) switchView.setChecked(false);
            showError(e.getMessage());
            return;
        }
        starting = true;
        Intent permission = VpnService.prepare(getActivity());
        if (permission != null) startActivityForResult(permission, REQUEST_VPN_PERMISSION);
        else onActivityResult(REQUEST_VPN_PERMISSION, Activity.RESULT_OK, null);
    }

    private void stopVpn() {
        if (binder != null) {
            stopping = true;
            try { binder.stop(); } catch (Exception ignored) { }
        }
        if (bound) {
            try { getActivity().unbindService(connection); } catch (Exception ignored) { }
            bound = false;
        }
        binder = null;
        checkService();
    }

    private void checkService() {
        if (getActivity() == null || bound) return;
        bound = getActivity().bindService(new Intent(getActivity(), SocksVpnService.class), connection, 0);
        updateState();
    }

    private void updateState() {
        if (switchView == null) return;
        boolean nowRunning = false;
        if (binder != null) {
            try { nowRunning = binder.isRunning(); } catch (Exception ignored) { }
        }
        running = nowRunning;
        switchView.setOnCheckedChangeListener(null);
        switchView.setChecked(running);
        switchView.setEnabled((!starting && !stopping) || (starting && running) || (stopping && !running));
        if (starting && running) starting = false;
        if (stopping && !running) stopping = false;
        switchView.setOnCheckedChangeListener(this);
    }
}
