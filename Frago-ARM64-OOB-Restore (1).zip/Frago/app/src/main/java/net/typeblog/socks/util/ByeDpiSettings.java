package net.typeblog.socks.util;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Lean native ByeDPI TLS Record + TCP OOB engine configuration
 * with minimal CPU, RAM, and battery overhead.
 */
public final class ByeDpiSettings {
    private static final int MAX_TLS_SPLITS = 16;
    private static final Pattern POSITION = Pattern.compile(
            "^-?(?:0[xX][0-9a-fA-F]+|[0-9]+)(?::[0-9]+(?::[0-9]+)?)?(?:\\+[shn](?:[emrs])?)?$");

    public static final String DEFAULT_POSITION = "1+s";
    public static final String DEFAULT_HOSTS = "regexp:(google)=65.109.184.128,91.107.241.144";
    public static final boolean DEFAULT_FAKE_SNI_ENABLED = false;
    public static final String DEFAULT_FAKE_SNI = "";
    public static final int DEFAULT_FAKE_TTL = 6;
    public static final String DEFAULT_SPOOF_CONNECT_IP = "188.114.98.0";
    public static final int DEFAULT_HANDSHAKE_TIMEOUT_MS = 2000;
    public static final boolean DEFAULT_BLOCK_QUIC = true;

    public static final String MODE_TLS_RECORD_OOB = "tls_record_oob";
    public static final String MODE_OOB_SPLIT_DISORDER = MODE_TLS_RECORD_OOB;
    public static final String MODE_OOB_SPLIT_DISORDER_PRO = MODE_TLS_RECORD_OOB;
    public static final String DEFAULT_DESYNC_MODE = MODE_TLS_RECORD_OOB;

    public final List<String> tlsRecordPositions;
    public final String desyncMode;
    public final boolean fakeSniEnabled;
    public final String fakeSni;
    public final List<String> fakeSniPool;
    public final int fakeTtl;
    public final String spoofConnectIp;
    public final int handshakeTimeoutMs;
    public final boolean blockQuic;
    public final DnsHostOverrides hostOverrides;

    private ByeDpiSettings(List<String> positions, String desyncMode, int fakeTtl,
                           String spoofConnectIp, int handshakeTimeoutMs,
                           DnsHostOverrides overrides) {
        this.tlsRecordPositions = positions;
        this.desyncMode = desyncMode;
        this.fakeSniEnabled = false;
        this.fakeSni = "";
        this.fakeSniPool = new ArrayList<>();
        this.fakeTtl = fakeTtl;
        this.spoofConnectIp = spoofConnectIp;
        this.handshakeTimeoutMs = handshakeTimeoutMs;
        this.blockQuic = true;
        this.hostOverrides = overrides;
    }

    public static ByeDpiSettings fromSettings(String positions, String desyncMode, boolean fakeSniEnabled,
                                              String fakeSni, int fakeTtl, String hosts) {
        return fromSettings(positions, desyncMode, fakeSniEnabled, fakeSni, fakeTtl,
                DEFAULT_SPOOF_CONNECT_IP, DEFAULT_HANDSHAKE_TIMEOUT_MS, true, hosts);
    }

    public static ByeDpiSettings fromSettings(String positions, String desyncMode, boolean fakeSniEnabled,
                                              String fakeSni, int fakeTtl, String spoofConnectIp,
                                              int handshakeTimeoutMs, boolean blockQuic, String hosts) {
        String normalizedPositions = normalizePositions(positions);
        String normalizedMode = normalizeDesyncMode(desyncMode);
        int normalizedTtl = normalizeFakeTtl(fakeTtl);
        String normalizedIp = normalizeSpoofConnectIp(spoofConnectIp);
        int normalizedTimeout = normalizeHandshakeTimeoutMs(handshakeTimeoutMs);
        return new ByeDpiSettings(
                parsePositions(normalizedPositions),
                normalizedMode,
                normalizedTtl,
                normalizedIp,
                normalizedTimeout,
                DnsHostOverrides.fromText(DnsHostOverrides.normalizeEditorText(hosts)));
    }

    public static int normalizeFakeTtl(int raw) {
        return 6;
    }

    public static String normalizeFakeSni(String raw) {
        return "";
    }

    public String nextFakeSni() {
        return "";
    }

    public static String normalizeSpoofConnectIp(String raw) {
        if (raw == null || raw.trim().isEmpty()) return DEFAULT_SPOOF_CONNECT_IP;
        String ip = raw.trim();
        if (!ip.matches("[0-9.]+")) {
            throw new IllegalArgumentException("Invalid IPv4 address: " + ip);
        }
        String[] parts = ip.split("\\.", -1);
        if (parts.length != 4) {
            throw new IllegalArgumentException("Invalid IPv4 address: " + ip);
        }
        for (String part : parts) {
            if (part.isEmpty() || part.length() > 3) {
                throw new IllegalArgumentException("Invalid IPv4 octet: " + part);
            }
            try {
                int v = Integer.parseInt(part);
                if (v < 0 || v > 255) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                throw new IllegalArgumentException("Invalid IPv4 octet: " + part);
            }
        }
        return ip;
    }

    public static int normalizeHandshakeTimeoutMs(int raw) {
        if (raw < 200 || raw > 30000) return DEFAULT_HANDSHAKE_TIMEOUT_MS;
        return raw;
    }

    public static String normalizeDesyncMode(String raw) {
        return MODE_TLS_RECORD_OOB;
    }

    public static String defaultPositionsForRecordCount(int records) {
        int count = Math.max(1, Math.min(MAX_TLS_SPLITS, records));
        int splits = count - 1;
        if (splits <= 0) return "";
        List<String> out = new ArrayList<>(splits);
        int pos = 1;
        for (int i = 0; i < splits; i++) {
            out.add(pos + "+s");
            pos += (i < 2) ? 2 : 3;
        }
        return String.join("\n", out);
    }

    public static int recordCount(String positions) {
        try {
            return parsePositions(normalizePositions(positions)).size() + 1;
        } catch (Exception ignored) {
            return 4;
        }
    }

    public static String normalizePositions(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "";
        String[] lines = raw.replace("\r\n", "\n").replace('\r', '\n').split("\\n");
        LinkedHashSet<String> unique = new LinkedHashSet<>();
        StringBuilder out = new StringBuilder();
        for (String line : lines) {
            String value = line.trim();
            if (value.isEmpty()) continue;
            if (!POSITION.matcher(value).matches()) {
                throw new IllegalArgumentException("Invalid TLS split position: " + value);
            }
            try {
                String[] sections = value.split("\\+", 2)[0].split(":");
                long offset = decodePosition(sections[0]);
                if (offset < -65535 || offset > 65535) throw new NumberFormatException();
                if (sections.length > 1) {
                    long repeat = Long.parseLong(sections[1]);
                    if (repeat <= 0 || repeat > 1000) throw new NumberFormatException();
                }
                if (sections.length > 2) {
                    long skip = Long.parseLong(sections[2]);
                    if (skip < 0 || skip > 1000) throw new NumberFormatException();
                }
            } catch (Exception invalid) {
                throw new IllegalArgumentException("Invalid TLS split offset: " + value);
            }
            if (!unique.add(value)) throw new IllegalArgumentException("Duplicate TLS split position: " + value);
            if (unique.size() > MAX_TLS_SPLITS) {
                throw new IllegalArgumentException("Use no more than " + MAX_TLS_SPLITS + " TLS split points");
            }
            if (out.length() > 0) out.append('\n');
            out.append(value);
        }
        return out.toString();
    }

    private static long decodePosition(String value) {
        if (value.startsWith("0x") || value.startsWith("0X")) return Long.parseLong(value.substring(2), 16);
        return Long.parseLong(value);
    }

    private static List<String> parsePositions(String normalized) {
        List<String> values = new ArrayList<>();
        if (normalized != null && !normalized.trim().isEmpty()) {
            for (String line : normalized.split("\\n")) {
                String value = line.trim();
                if (!value.isEmpty()) values.add(value);
            }
        }
        return values;
    }

    public List<String> toByeDpiArgs() {
        List<String> args = new ArrayList<>();
        args.add("--timeout");
        args.add("10");
        args.add("--max-conn");
        args.add("64");

        // Keep the previously working ByeDPI strategy: TLS record split only.
        // Do not pass --oob here; the older working Frago configuration used
        // --tlsrec 1+s and did not combine it with the separate --oob option.
        String position = tlsRecordPositions.isEmpty() ? DEFAULT_POSITION : tlsRecordPositions.get(0);
        args.add("--tlsrec");
        args.add(position);
        return args;
    }

    public static String positionsSummary(String positions) {
        try {
            int splits = parsePositions(normalizePositions(positions)).size();
            if (splits == 0) return "1 TLS record (no split)";
            return (splits + 1) + " TLS records";
        } catch (Exception error) {
            return "Invalid TLS record count";
        }
    }
}