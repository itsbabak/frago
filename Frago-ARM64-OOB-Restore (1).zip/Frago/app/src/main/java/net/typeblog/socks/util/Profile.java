package net.typeblog.socks.util;

import android.content.SharedPreferences;

public class Profile {
    private final SharedPreferences mPref;
    private final String mName;
    private final String mPrefix;

    Profile(SharedPreferences pref, String name) {
        mPref = pref;
        mName = name;
        mPrefix = prefPrefix(name);
        migrateLegacySettings();
        migrateAppListToVpnAllowlist();
    }

    public String getName() {
        return mName;
    }

    public String getProtocol() {
        String p = mPref.getString(key("protocol"), UniversalProxyRelay.PROTO_BYEDPI);
        if ("fragment".equals(p)) return UniversalProxyRelay.PROTO_BYEDPI;
        if (!UniversalProxyRelay.PROTO_BYEDPI.equals(p)
                && !UniversalProxyRelay.PROTO_SOCKS5.equals(p)
                && !UniversalProxyRelay.PROTO_HTTP.equals(p)) {
            return UniversalProxyRelay.PROTO_BYEDPI;
        }
        return p;
    }

    public void setProtocol(String protocol) {
        mPref.edit().putString(key("protocol"), protocol).commit();
    }

    public String getServer() {
        return mPref.getString(key("server"), "");
    }

    public void setServer(String server) {
        mPref.edit().putString(key("server"), server).commit();
    }

    public int getPort() {
        return mPref.getInt(key("port"), 443);
    }

    public void setPort(int port) {
        mPref.edit().putInt(key("port"), port).commit();
    }

    public boolean isUserPw() {
        return !getUsername().isEmpty();
    }

    public void setIsUserpw(boolean is) {
        mPref.edit().putBoolean(key("userpw"), is).commit();
    }

    public String getUsername() {
        return mPref.getString(key("username"), "");
    }

    public void setUsername(String username) {
        mPref.edit().putString(key("username"), username).commit();
    }

    public String getPassword() {
        return mPref.getString(key("password"), "");
    }

    public void setPassword(String password) {
        mPref.edit().putString(key("password"), password).commit();
    }

    public String getVlessSni() {
        return mPref.getString(key("vless_sni"), "");
    }

    public void setVlessSni(String sni) {
        mPref.edit().putString(key("vless_sni"), sni).commit();
    }

    public String getVlessWsPath() {
        return mPref.getString(key("vless_ws_path"), "");
    }

    public void setVlessWsPath(String path) {
        mPref.edit().putString(key("vless_ws_path"), path).commit();
    }

    public boolean isVlessTls() {
        return mPref.getBoolean(key("vless_tls"), true);
    }

    public void setVlessTls(boolean enabled) {
        mPref.edit().putBoolean(key("vless_tls"), enabled).commit();
    }

    public boolean isChainFragmentEnabled() {
        return mPref.getBoolean(key("chain_fragment"), false);
    }

    public void setChainFragmentEnabled(boolean enabled) {
        mPref.edit().putBoolean(key("chain_fragment"), enabled).commit();
    }

    public boolean isPerApp() {
        return mPref.getBoolean(key("perapp"), false);
    }

    public void setIsPerApp(boolean is) {
        mPref.edit().putBoolean(key("perapp"), is).commit();
    }

    public boolean isBypassApp() {
        return mPref.getBoolean(key("appbypass"), false);
    }

    public void setIsBypassApp(boolean is) {
        mPref.edit().putBoolean(key("appbypass"), is).commit();
    }

    public String getAppList() {
        return mPref.getString(key("applist"), "");
    }

    public void setAppList(String list) {
        mPref.edit().putString(key("applist"), list).commit();
    }

    public boolean autoConnect() {
        return mPref.getBoolean(key("auto"), true);
    }

    public void setAutoConnect(boolean auto) {
        mPref.edit().putBoolean(key("auto"), auto).commit();
    }

    public String getTlsRecordPositions() {
        return mPref.getString(key("tlsrec_positions"), ByeDpiSettings.DEFAULT_POSITION);
    }

    public void setTlsRecordPositions(String value) {
        mPref.edit().putString(key("tlsrec_positions"), value).commit();
    }

    public String getDesyncMode() {
        return ByeDpiSettings.normalizeDesyncMode(
                mPref.getString(key("desync_mode"), ByeDpiSettings.DEFAULT_DESYNC_MODE));
    }

    public void setDesyncMode(String mode) {
        mPref.edit().putString(key("desync_mode"), ByeDpiSettings.normalizeDesyncMode(mode)).commit();
    }

    public String getFakeSni() {
        return "";
    }

    public void setFakeSni(String sni) {
    }

    public int getFakeTtl() {
        return ByeDpiSettings.DEFAULT_FAKE_TTL;
    }

    public void setFakeTtl(int ttl) {
    }

    public boolean isFakeSniEnabled() {
        return false;
    }

    public void setFakeSniEnabled(boolean enabled) {
    }

    public boolean isBlockQuic() {
        return mPref.getBoolean(key("block_quic"), ByeDpiSettings.DEFAULT_BLOCK_QUIC);
    }

    public void setBlockQuic(boolean block) {
        mPref.edit().putBoolean(key("block_quic"), block).commit();
    }

    public String getDnsHostOverrides() {
        String prefKey = key("dns_host_overrides");
        if (mPref.contains(prefKey)) return mPref.getString(prefKey, "");
        String defaults = ByeDpiSettings.DEFAULT_HOSTS;
        mPref.edit().putString(prefKey, defaults).commit();
        return defaults;
    }

    public void setDnsHostOverrides(String value) {
        mPref.edit().putString(key("dns_host_overrides"), value).commit();
    }

    private void migrateLegacySettings() {
        String legacyKey = key("fragment_json");
        SharedPreferences.Editor edit = mPref.edit();
        boolean changed = false;
        if (mPref.contains(legacyKey)) {
            String raw = mPref.getString(legacyKey, "");
            String tlsKey = key("tlsrec_positions");
            String hostsKey = key("dns_host_overrides");
            if (!mPref.contains(tlsKey)) edit.putString(tlsKey, LegacyProfileMigration.tlsPositions(raw));
            if (!mPref.contains(hostsKey)) edit.putString(hostsKey, LegacyProfileMigration.hostOverrides(raw));
            edit.remove(legacyKey);
            changed = true;
        }
        for (String oldKey : new String[]{
                "private_dns", "dot_enabled", "doh_enabled", "doh_url", "doh_servers",
                "secure_dns_enabled", "white_dns_enabled", "white_dns_servers"
        }) {
            if (mPref.contains(key(oldKey))) {
                edit.remove(key(oldKey));
                changed = true;
            }
        }
        if (changed) {
            edit.commit();
        }
    }

    void delete() {
        mPref.edit()
                .remove(key("server"))
                .remove(key("port"))
                .remove(key("userpw"))
                .remove(key("username"))
                .remove(key("password"))
                .remove(key("vless_sni"))
                .remove(key("vless_ws_path"))
                .remove(key("vless_tls"))
                .remove(key("chain_fragment"))
                .remove(key("perapp"))
                .remove(key("appbypass"))
                .remove(key("applist"))
                .remove(key("app_list_vpn_allowlist_v2"))
                .remove(key("auto"))
                .remove(key("fragment_json"))
                .remove(key("tlsrec_positions"))
                .remove(key("desync_mode"))
                .remove(key("fake_sni"))
                .remove(key("fake_ttl"))
                .remove(key("fake_sni_enabled"))
                .remove(key("white_dns_enabled"))
                .remove(key("white_dns_servers"))
                .remove(key("doh_enabled"))
                .remove(key("doh_url"))
                .remove(key("block_quic"))
                .remove(key("dns_host_overrides"))
                .remove(key("doh_servers"))
                .remove(key("secure_dns_enabled"))
                .remove(key("protocol"))
                .commit();
    }


    // Previous builds stored the checked apps as a Bypass exclusion list.
    // Clear it once when switching to the new VPN allow-list behavior so the
    // initial state is safely "no apps selected" instead of reversing old choices.
    private void migrateAppListToVpnAllowlist() {
        String marker = key("app_list_vpn_allowlist_v2");
        if (!mPref.getBoolean(marker, false)) {
            mPref.edit()
                    .putString(key("applist"), "")
                    .putBoolean(key("perapp"), true)
                    .putBoolean(key("appbypass"), false)
                    .putBoolean(marker, true)
                    .commit();
        }
    }

    private String key(String k) {
        return mPrefix + k;
    }

    private static String prefPrefix(String name) {
        return name.replace("_", "__").replace(" ", "_");
    }
}