package net.typeblog.socks.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

import net.typeblog.socks.R;
import static net.typeblog.socks.util.Constants.*;

public class ProfileManager {

    private final SharedPreferences mPref;
    private final Context mContext;

    public ProfileManager(Context context) {
        mContext = context;
        mPref = mContext.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    private List<String> getProfileList() {
        List<String> mProfiles = new ArrayList<>();
        mProfiles.add(getDefaultProfileName());

        String[] profiles = mPref.getString(PREF_PROFILE, "").split("\n");

        for (String p : profiles) {
            if (!TextUtils.isEmpty(p)) {
                mProfiles.add(p);
            }
        }
        return mProfiles;
    }

    public String getDefaultProfileName() {
        return mPref.getString(PREF_DEFAULT_PROFILE_NAME, mContext.getString(R.string.prof_default));
    }

    public String[] getProfiles() {
        return getProfileList().toArray(new String[0]);
    }

    public Profile getProfile(String name) {
        if (!getProfileList().contains(name)) {
            return null;
        } else {
            return new Profile(mPref, name);
        }
    }

    public Profile getDefault() {
        String selected = mPref.getString(PREF_LAST_PROFILE, getDefaultProfileName());
        if (!getProfileList().contains(selected)) selected = getDefaultProfileName();
        return new Profile(mPref, selected);
    }

    public void switchDefault(String name) {
        if (getProfileList().contains(name))
            mPref.edit().putString(PREF_LAST_PROFILE, name).apply();
    }

    public Profile addProfile(String name) {
        List<String> mProfiles = getProfileList();
        if (mProfiles.contains(name)) {
            return null;
        } else {
            mProfiles.add(name);
            mProfiles.remove(getDefaultProfileName());
            mPref.edit().putString(PREF_PROFILE, Utility.join(mProfiles, "\n"))
                    .putString(PREF_LAST_PROFILE, name).apply();
            return getDefault();
        }
    }

    public boolean renameProfile(String oldName, String newName) {
        if (TextUtils.isEmpty(oldName) || TextUtils.isEmpty(newName)) return false;
        newName = newName.trim();
        if (newName.length() > 40 || newName.contains("\n") || newName.contains("/")) return false;
        List<String> names = getProfileList();
        if (!names.contains(oldName) || (names.contains(newName) && !oldName.equals(newName))) return false;
        if (oldName.equals(newName)) return true;

        String oldPrefix = oldName.replace("_", "__").replace(" ", "_");
        String newPrefix = newName.replace("_", "__").replace(" ", "_");
        String[] suffixes = {"server", "port", "userpw", "username", "password", "perapp",
                "appbypass", "applist", "auto", "tlsrec_positions",
                "dns_host_overrides", "doh_url", "doh_servers", "protocol"};
        SharedPreferences.Editor editor = mPref.edit();
        for (String suffix : suffixes) {
            String oldKey = oldPrefix + suffix;
            if (!mPref.contains(oldKey)) continue;
            Object value = mPref.getAll().get(oldKey);
            String newKey = newPrefix + suffix;
            if (value instanceof String) editor.putString(newKey, (String) value);
            else if (value instanceof Boolean) editor.putBoolean(newKey, (Boolean) value);
            else if (value instanceof Integer) editor.putInt(newKey, (Integer) value);
            else if (value instanceof Long) editor.putLong(newKey, (Long) value);
            else if (value instanceof Float) editor.putFloat(newKey, (Float) value);
            editor.remove(oldKey);
        }

        if (oldName.equals(getDefaultProfileName())) editor.putString(PREF_DEFAULT_PROFILE_NAME, newName);
        else {
            names.remove(oldName);
            names.add(newName);
            names.remove(getDefaultProfileName());
            editor.putString(PREF_PROFILE, Utility.join(names, "\n"));
        }
        if (oldName.equals(mPref.getString(PREF_LAST_PROFILE, getDefaultProfileName())))
            editor.putString(PREF_LAST_PROFILE, newName);
        editor.commit();
        return true;
    }

    public boolean removeProfile(String name) {
        List<String> mProfiles = getProfileList();
        if (name.equals(getDefaultProfileName()) || !mProfiles.contains(name)) {
            return false;
        }

        new Profile(mPref, name).delete();

        mProfiles.remove(getDefaultProfileName());
        mProfiles.remove(name);

        mPref.edit().putString(PREF_PROFILE, Utility.join(mProfiles, "\n"))
                .remove(PREF_LAST_PROFILE).apply();

        return true;
    }
}
