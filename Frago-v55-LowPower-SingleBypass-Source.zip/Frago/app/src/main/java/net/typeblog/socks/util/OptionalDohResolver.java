package net.typeblog.socks.util;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * Lightweight DNS-over-HTTPS (RFC 8484 POST application/dns-message) resolver
 * over protected sockets for low CPU, RAM, and battery overhead.
 */
public final class OptionalDohResolver {
    public interface SocketProtector {
        boolean protect(Socket socket);
    }

    public static final String DEFAULT_DOH_URL = "https://1.1.1.1/dns-query";
    private static final int TIMEOUT_MS = 4000;
    private static final int MAX_RESP_BYTES = 8192;

    private final String dohUrl;
    private final SocketProtector protector;

    public OptionalDohResolver(String dohUrl, SocketProtector protector) {
        this.dohUrl = normalizeUrl(dohUrl);
        this.protector = protector;
    }

    public static String normalizeUrl(String raw) {
        if (raw == null || raw.trim().isEmpty()) return DEFAULT_DOH_URL;
        String u = raw.trim();
        if (!u.startsWith("https://") && !u.startsWith("http://") && !u.startsWith("tls://")) {
            return "https://" + u;
        }
        return u;
    }

    public byte[] resolveQuery(byte[] query) {
        if (query == null || query.length < 12) return null;
        ParsedHttpEndpoint ep = parseEndpoint(dohUrl);
        if (ep == null) return null;

        Socket raw = null;
        SSLSocket ssl = null;
        try {
            raw = new Socket();
            if (protector != null && !protector.protect(raw)) {
                return null;
            }
            raw.setTcpNoDelay(true);
            raw.setSoTimeout(TIMEOUT_MS);
            raw.connect(new InetSocketAddress(ep.host, ep.port), TIMEOUT_MS);

            OutputStream netOut;
            InputStream netIn;
            if (ep.https) {
                SSLSocketFactory factory = (SSLSocketFactory) SSLSocketFactory.getDefault();
                ssl = (SSLSocket) factory.createSocket(raw, ep.host, ep.port, true);
                ssl.setSoTimeout(TIMEOUT_MS);
                ssl.setTcpNoDelay(true);
                ssl.startHandshake();
                netOut = ssl.getOutputStream();
                netIn = ssl.getInputStream();
            } else {
                netOut = raw.getOutputStream();
                netIn = raw.getInputStream();
            }

            String reqHdr = "POST " + ep.path + " HTTP/1.1\r\n"
                    + "Host: " + ep.hostHeader + "\r\n"
                    + "Content-Type: application/dns-message\r\n"
                    + "Accept: application/dns-message\r\n"
                    + "Content-Length: " + query.length + "\r\n"
                    + "Connection: close\r\n\r\n";
            netOut.write(reqHdr.getBytes(StandardCharsets.US_ASCII));
            netOut.write(query);
            netOut.flush();

            ByteArrayOutputStream all = new ByteArrayOutputStream();
            byte[] buf = new byte[2048];
            int n;
            while (all.size() < MAX_RESP_BYTES && (n = netIn.read(buf)) != -1) {
                all.write(buf, 0, n);
            }
            byte[] data = all.toByteArray();
            int bodyStart = findHeaderEnd(data);
            if (bodyStart < 0 || bodyStart + 12 > data.length) return null;
            int bodyLen = data.length - bodyStart;
            byte[] dnsResp = new byte[bodyLen];
            System.arraycopy(data, bodyStart, dnsResp, 0, bodyLen);
            return dnsResp;
        } catch (Exception ignored) {
            return null;
        } finally {
            if (ssl != null) try { ssl.close(); } catch (Exception ignored) { }
            if (raw != null) try { raw.close(); } catch (Exception ignored) { }
        }
    }

    private static int findHeaderEnd(byte[] data) {
        for (int i = 0; i + 3 < data.length; i++) {
            if (data[i] == '\r' && data[i + 1] == '\n' && data[i + 2] == '\r' && data[i + 3] == '\n') {
                return i + 4;
            }
        }
        return -1;
    }

    private static final class ParsedHttpEndpoint {
        final boolean https;
        final String host;
        final String hostHeader;
        final int port;
        final String path;

        ParsedHttpEndpoint(boolean https, String host, String hostHeader, int port, String path) {
            this.https = https;
            this.host = host;
            this.hostHeader = hostHeader;
            this.port = port;
            this.path = path;
        }
    }

    private static ParsedHttpEndpoint parseEndpoint(String rawUrl) {
        String u = normalizeUrl(rawUrl);
        boolean https = !u.startsWith("http://");
        String rest = u.startsWith("https://") ? u.substring(8)
                : (u.startsWith("http://") ? u.substring(7) : u);
        int slash = rest.indexOf('/');
        String authority = slash >= 0 ? rest.substring(0, slash) : rest;
        String path = slash >= 0 ? rest.substring(slash) : "/dns-query";
        if (path.isEmpty()) path = "/dns-query";

        String host = authority;
        int port = https ? 443 : 80;
        int colon = authority.indexOf(':');
        if (colon >= 0) {
            host = authority.substring(0, colon).trim();
            try {
                port = Integer.parseInt(authority.substring(colon + 1).trim());
            } catch (Exception ignored) {
            }
        }
        if (host.isEmpty()) return null;
        return new ParsedHttpEndpoint(https, host, authority, port, path);
    }
}
