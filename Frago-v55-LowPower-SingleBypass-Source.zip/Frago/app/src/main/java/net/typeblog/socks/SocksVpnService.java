package net.typeblog.socks;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.net.VpnService;
import android.os.Build;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;

import net.typeblog.socks.util.ByeDpiSettings;
import net.typeblog.socks.util.QuicUdp443Blocker;
import net.typeblog.socks.util.LocalDnsRelay;
import net.typeblog.socks.util.Profile;
import net.typeblog.socks.util.ProfileManager;
import net.typeblog.socks.util.Utility;

import java.io.File;
import java.net.DatagramSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;

import static net.typeblog.socks.util.Constants.*;

public class SocksVpnService extends VpnService {
    class VpnBinder extends IVpnService.Stub {
        @Override
        public boolean isRunning() {
            return mRunning;
        }

        @Override
        public void stop() {
            stopMe();
        }
    }

    private ParcelFileDescriptor mInterface;
    public static final String ACTION_STATE = "net.typeblog.socks.ACTION_STATE";
    public static final String ACTION_STOP = "net.typeblog.socks.ACTION_STOP";
    private volatile boolean mRunning = false;
    private volatile boolean mStopping = false;
    private boolean mCleaned = true;
    private volatile Process mByeDpiProcess;
    private volatile ByeDpiSettings mActiveSettings;
    private LocalDnsRelay mDnsRelay;
    private QuicUdp443Blocker mQuicBlocker;
    private ConnectivityManager.NetworkCallback mNetworkCallback;
    private final IBinder mBinder = new VpnBinder();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            boolean alreadyCleaned;
            synchronized (this) { alreadyCleaned = mCleaned; }
            stopMe();
            if (alreadyCleaned) sendState(false, null);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        if (mRunning) {
            return START_STICKY;
        }
        synchronized (this) {
            mCleaned = false;
            mStopping = false;
        }

        String name;
        String server;
        int port;
        String username;
        String passwd;
        boolean perApp;
        boolean appBypass;
        String[] appList;
        String tlsPositions;
        String desyncMode;
        boolean fakeSniEnabled;
        String fakeSni;
        int fakeTtl;
        boolean dohEnabled;
        String dohUrl;
        boolean blockQuic;
        String dnsHostOverrides;

        // Support Android START_STICKY restarts (intent == null) and system Always-On VPN.
        if (intent == null || SERVICE_INTERFACE.equals(intent.getAction())
                || intent.getStringExtra(INTENT_NAME) == null) {
            Profile fallbackProfile;
            try {
                fallbackProfile = new ProfileManager(getApplicationContext()).getDefault();
            } catch (Exception error) {
                fail(getString(R.string.connection_start_failed));
                return START_NOT_STICKY;
            }
            if (fallbackProfile == null) {
                fail(getString(R.string.connection_start_failed));
                return START_NOT_STICKY;
            }
            name = fallbackProfile.getName();
            server = "127.0.0.1";
            port = 1081;
            username = null;
            passwd = null;
            perApp = fallbackProfile.isPerApp();
            appBypass = fallbackProfile.isBypassApp();
            appList = perApp ? fallbackProfile.getAppList().split("\n") : null;
            tlsPositions = fallbackProfile.getTlsRecordPositions();
            desyncMode = fallbackProfile.getDesyncMode();
            fakeSniEnabled = fallbackProfile.isFakeSniEnabled();
            fakeSni = fallbackProfile.getFakeSni();
            fakeTtl = fallbackProfile.getFakeTtl();
            dohEnabled = fallbackProfile.isDohEnabled();
            dohUrl = fallbackProfile.getDohUrl();
            blockQuic = fallbackProfile.isBlockQuic();
            dnsHostOverrides = fallbackProfile.getDnsHostOverrides();
        } else {
            name = intent.getStringExtra(INTENT_NAME);
            server = intent.getStringExtra(INTENT_SERVER);
            port = intent.getIntExtra(INTENT_PORT, 1080);
            username = intent.getStringExtra(INTENT_USERNAME);
            passwd = intent.getStringExtra(INTENT_PASSWORD);
            perApp = intent.getBooleanExtra(INTENT_PER_APP, false);
            appBypass = intent.getBooleanExtra(INTENT_APP_BYPASS, false);
            appList = intent.getStringArrayExtra(INTENT_APP_LIST);
            tlsPositions = intent.getStringExtra(INTENT_TLSREC_POSITIONS);
            desyncMode = intent.getStringExtra(INTENT_DESYNC_MODE);
            fakeSniEnabled = intent.getBooleanExtra(INTENT_FAKE_SNI_ENABLED, false);
            fakeSni = intent.getStringExtra(INTENT_FAKE_SNI);
            fakeTtl = intent.getIntExtra(INTENT_FAKE_TTL, ByeDpiSettings.DEFAULT_FAKE_TTL);
            dohEnabled = intent.getBooleanExtra(INTENT_DOH_ENABLED, ByeDpiSettings.DEFAULT_DOH_ENABLED);
            dohUrl = intent.getStringExtra(INTENT_DOH_URL);
            blockQuic = intent.getBooleanExtra(INTENT_BLOCK_QUIC, ByeDpiSettings.DEFAULT_BLOCK_QUIC);
            dnsHostOverrides = intent.getStringExtra(INTENT_DNS_HOST_OVERRIDES);
        }

        final ByeDpiSettings byedpiSettings;
        try {
            byedpiSettings = ByeDpiSettings.fromSettings(tlsPositions, desyncMode, fakeSniEnabled, fakeSni, fakeTtl, dohEnabled, dohUrl, dnsHostOverrides);
        } catch (IllegalArgumentException invalidSettings) {
            fail(getString(R.string.fragment_config_invalid));
            return START_NOT_STICKY;
        }
        mActiveSettings = byedpiSettings;

        final UnderlyingNetworkInfo underlyingDns = getUnderlyingNetworkInfo();

        try {
            configure(name, perApp, appBypass, appList);
        } catch (Exception error) {
            fail(getString(R.string.connection_start_failed));
            return START_NOT_STICKY;
        }
        if (mInterface == null) {
            fail(getString(R.string.connection_start_failed));
            return START_NOT_STICKY;
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            String NOTIFICATION_CHANNEL_ID = "net.typeblog.socks";
            NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL_ID,
                    getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW);
            channel.setShowBadge(false);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            Objects.requireNonNull(notificationManager).createNotificationChannel(channel);
            builder = new Notification.Builder(this, NOTIFICATION_CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        int NOTIFICATION_ID = 1;
        int intentFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            intentFlags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), intentFlags);
        Notification notification = builder
                .setContentTitle(getString(R.string.notify_title))
                .setContentText(String.format(getString(R.string.notify_msg), name))
                .setPriority(Notification.PRIORITY_MIN)
                .setSmallIcon(R.drawable.ic_vpn)
                .setContentIntent(contentIntent)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }

        start(mInterface.getFd(), server, port, username, passwd, byedpiSettings,
                underlyingDns.network, underlyingDns.dnsServers);

        return mRunning ? START_STICKY : START_NOT_STICKY;
    }

    @Override
    public void onRevoke() {
        super.onRevoke();
        stopMe();
    }

    @Override
    public IBinder onBind(Intent intent) {
        if (intent != null && SERVICE_INTERFACE.equals(intent.getAction())) {
            return super.onBind(intent);
        }
        return mBinder;
    }

    @Override
    public void onDestroy() {
        stopMe();
        super.onDestroy();
    }

    private String mPendingError;

    private void fail(String message) {
        mPendingError = message;
        stopMe();
    }

    private void stopMe() {
        synchronized (this) {
            if (mCleaned) return;
            mCleaned = true;
            mRunning = false;
            mStopping = true;
        }

        unregisterNetworkCallback();

        try { stopForeground(true); } catch (Exception ignored) { }

        Utility.killPidFile(getFilesDir() + "/tun2socks.pid");
        Utility.killPidFile(getFilesDir() + "/pdnsd.pid");
        Process proc = mByeDpiProcess;
        mByeDpiProcess = null;
        if (proc != null) {
            try {
                proc.destroy();
                if (Build.VERSION.SDK_INT >= 26) {
                    if (!proc.waitFor(250L, java.util.concurrent.TimeUnit.MILLISECONDS)) {
                        proc.destroyForcibly();
                    }
                }
            } catch (Exception ignored) { }
        }
        if (mQuicBlocker != null) {
            mQuicBlocker.stop();
            mQuicBlocker = null;
        }
        if (mDnsRelay != null) {
            mDnsRelay.stop();
            mDnsRelay = null;
        }

        try {
            if (mInterface != null) {
                // Do NOT call System.jniclose() on a ParcelFileDescriptor fd:
                // Android fdsan aborts the process with SIGABRT on double-close.
                mInterface.close();
                mInterface = null;
            }
        } catch (Exception ignored) { }

        sendState(false, mPendingError);
        mPendingError = null;
        stopSelf();
    }

    private static final class UnderlyingNetworkInfo {
        final Network network;
        final List<String> dnsServers;
        UnderlyingNetworkInfo(Network network, List<String> dnsServers) {
            this.network = network;
            this.dnsServers = dnsServers;
        }
    }

    private UnderlyingNetworkInfo getUnderlyingNetworkInfo() {
        Set<String> result = new LinkedHashSet<>();
        Network selected = null;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm == null) return new UnderlyingNetworkInfo(null, new ArrayList<String>());
            if (Build.VERSION.SDK_INT >= 23) {
                selected = cm.getActiveNetwork();
                if (selected != null) addDnsFromLinkProperties(cm.getLinkProperties(selected), result);
            }
            if (selected == null) {
                Network[] networks = cm.getAllNetworks();
                if (networks != null) {
                    for (Network network : networks) {
                        NetworkInfo info = cm.getNetworkInfo(network);
                        if (info != null && info.isConnected()) {
                            LinkProperties properties = cm.getLinkProperties(network);
                            if (properties != null) {
                                selected = network;
                                addDnsFromLinkProperties(properties, result);
                                if (!result.isEmpty()) break;
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return new UnderlyingNetworkInfo(selected, new ArrayList<>(result));
    }

    private void addDnsFromLinkProperties(LinkProperties properties, Set<String> output) {
        if (properties == null) return;
        for (java.net.InetAddress address : properties.getDnsServers()) {
            if (address != null && !address.isAnyLocalAddress()) output.add(address.getHostAddress());
        }
    }

    private void registerNetworkCallback() {
        if (Build.VERSION.SDK_INT < 21) return;
        try {
            final ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm == null) return;
            unregisterNetworkCallback();
            NetworkRequest request = new NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                    .build();
            mNetworkCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    handleNetworkUpdate(cm, network);
                }

                @Override
                public void onLinkPropertiesChanged(Network network, LinkProperties linkProperties) {
                    if (!mRunning || mStopping) return;
                    Set<String> dns = new LinkedHashSet<>();
                    addDnsFromLinkProperties(linkProperties, dns);
                    LocalDnsRelay relay = mDnsRelay;
                    if (relay != null && !dns.isEmpty()) {
                        relay.updateUpstreamDns(new ArrayList<>(dns));
                    }
                }
            };
            cm.registerNetworkCallback(request, mNetworkCallback);
        } catch (Exception ignored) {
        }
    }

    private void handleNetworkUpdate(ConnectivityManager cm, Network network) {
        if (!mRunning || mStopping || network == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 22) {
                setUnderlyingNetworks(new Network[]{network});
            }
            LinkProperties props = cm.getLinkProperties(network);
            Set<String> dns = new LinkedHashSet<>();
            addDnsFromLinkProperties(props, dns);
            LocalDnsRelay relay = mDnsRelay;
            if (relay != null && !dns.isEmpty()) {
                relay.updateUpstreamDns(new ArrayList<>(dns));
            }
        } catch (Exception ignored) {
        }
    }

    private void unregisterNetworkCallback() {
        if (Build.VERSION.SDK_INT < 21 || mNetworkCallback == null) return;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm != null) {
                cm.unregisterNetworkCallback(mNetworkCallback);
            }
        } catch (Exception ignored) {
        }
        mNetworkCallback = null;
    }

    private void configure(String name, boolean perApp, boolean bypass, String[] apps) {
        Builder b = new Builder();
        b.setMtu(1500)
                .setSession(name)
                .addAddress("26.26.26.1", 24)
                .addDnsServer("26.26.26.3");

        b.addRoute("0.0.0.0", 0);
        b.addRoute("26.26.26.3", 32);

        if (!perApp) {
            try {
                b.addDisallowedApplication("net.typeblog.socks");
            } catch (Exception ignored) { }
        } else {
            if (bypass) {
                try {
                    b.addDisallowedApplication("net.typeblog.socks");
                } catch (Exception ignored) { }

                for (String p : (apps == null ? new String[0] : apps)) {
                    if (TextUtils.isEmpty(p)) continue;
                    try { b.addDisallowedApplication(p.trim()); } catch (Exception ignored) { }
                }
            } else {
                for (String p : (apps == null ? new String[0] : apps)) {
                    if (TextUtils.isEmpty(p) || p.trim().equals("net.typeblog.socks")) continue;
                    try { b.addAllowedApplication(p.trim()); } catch (Exception ignored) { }
                }
            }
        }

        mInterface = b.establish();
        if (mInterface == null) throw new IllegalStateException("VPN interface could not be established");
    }

    private void start(int fd, String server, int port, String user, String passwd,
                       ByeDpiSettings byedpiSettings, Network underlyingNetwork,
                       List<String> systemDnsServers) {
        Utility.killPidFile(getFilesDir() + "/tun2socks.pid");
        Utility.killPidFile(getFilesDir() + "/pdnsd.pid");
        if (byedpiSettings != null) {
            server = "127.0.0.1";
            port = 1081;
            user = null;
            passwd = null;
            if (!startByeDpi(byedpiSettings, 0)) {
                fail(getString(R.string.fragment_engine_start_failed));
                return;
            }
            try {
                mQuicBlocker = new QuicUdp443Blocker();
                mQuicBlocker.start();
            } catch (Exception ignored) {
            }
        }

        try {
            mDnsRelay = new LocalDnsRelay(
                    byedpiSettings != null ? byedpiSettings.hostOverrides : null,
                    systemDnsServers,
                    new LocalDnsRelay.SocketProtector() {
                        @Override
                        public boolean protect(DatagramSocket socket) {
                            return SocksVpnService.this.protect(socket);
                        }

                        @Override
                        public boolean protectSocket(Socket socket) {
                            return SocksVpnService.this.protect(socket);
                        }
                    },
                    port,
                    byedpiSettings != null && byedpiSettings.dohEnabled,
                    byedpiSettings != null ? byedpiSettings.dohUrl : null);
            mDnsRelay.start();
        } catch (Exception dnsError) {
            fail(getString(R.string.dns_start_failed));
            return;
        }

        Utility.makePdnsdConf(this, "127.0.0.1", 5354, true);
        if (Utility.exec(String.format(Locale.US, "%s/libpdnsd.so -c %s/pdnsd.conf",
                getApplicationInfo().nativeLibraryDir, getFilesDir())) != 0) {
            fail(getString(R.string.dns_start_failed));
            return;
        }

        String command = String.format(Locale.US,
                "%s/libtun2socks.so --netif-ipaddr 26.26.26.2"
                        + " --netif-netmask 255.255.255.0"
                        + " --socks-server-addr %s:%d"
                        + " --tunfd %d"
                        + " --tunmtu 1500"
                        + " --loglevel 0"
                        + " --pid %s/tun2socks.pid"
                        + " --sock %s/sock_path"
                , getApplicationInfo().nativeLibraryDir, server, port, fd, getFilesDir(), getApplicationInfo().dataDir);

        if (user != null) {
            command += " --username " + user;
            command += " --password " + passwd;
        }

        command += " --dnsgw 26.26.26.1:8091";

        if (Utility.exec(command) != 0) {
            fail(getString(R.string.tunnel_start_failed));
            return;
        }

        int i = 0;
        while (i < 5) {
            if (System.sendfd(fd, getApplicationInfo().dataDir + "/sock_path") != -1) {
                mRunning = true;
                if (Build.VERSION.SDK_INT >= 22 && underlyingNetwork != null) {
                    try { setUnderlyingNetworks(new Network[]{underlyingNetwork}); } catch (Exception ignored) { }
                }
                registerNetworkCallback();
                sendState(true, null);
                return;
            }
            i++;
            try { Thread.sleep(500L); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); return; }
        }

        fail(getString(R.string.tunnel_start_failed));
    }

    private void sendState(boolean running, String error) {
        Intent state = new Intent(ACTION_STATE).setPackage(getPackageName());
        state.putExtra("running", running);
        if (!TextUtils.isEmpty(error)) state.putExtra("error", error);
        sendBroadcast(state);
    }

    private boolean startByeDpi(final ByeDpiSettings settings, final int restartCount) {
        try {
            String binary = getApplicationInfo().nativeLibraryDir + "/libbyedpi.so";
            File executable = new File(binary);
            if (!executable.exists()) {
                return false;
            }
            executable.setExecutable(true, true);
            ArrayList<String> command = new ArrayList<>();
            command.add(binary);
            command.add("--ip");
            command.add("127.0.0.1");
            command.add("--port");
            command.add("1081");
            command.add("--no-ipv6");
            command.addAll(settings.toByeDpiArgs());

            ProcessBuilder builder = new ProcessBuilder(command);
            builder.redirectErrorStream(true);
            final Process proc = builder.start();
            mByeDpiProcess = proc;

            final java.io.InputStream output = proc.getInputStream();
            Thread watchdog = new Thread(new Runnable() {
                @Override
                public void run() {
                    byte[] buffer = new byte[1024];
                    try {
                        while (output.read(buffer) != -1) { /* drain native output */ }
                    } catch (Exception ignored) {
                    }
                    try { proc.waitFor(); } catch (InterruptedException ignored) { return; }
                    if (mRunning && !mStopping && mByeDpiProcess == proc && restartCount < 5) {
                        try { Thread.sleep(1000L * (restartCount + 1)); }
                        catch (InterruptedException ignored) { return; }
                        if (mRunning && !mStopping && mActiveSettings != null) {
                            startByeDpi(mActiveSettings, restartCount + 1);
                        }
                    }
                }
            }, "ByeDPI-watchdog");
            watchdog.setDaemon(true);
            watchdog.start();

            Thread.sleep(300L);
            try {
                proc.exitValue();
                return false;
            } catch (IllegalThreadStateException stillRunning) {
                return true;
            }
        } catch (Exception ignored) {
            return false;
        }
    }
}
