package net.typeblog.socks.util;

import android.content.SharedPreferences;

public class Profile {
    private final SharedPreferences mPref;
    private final String mName;
    private final String mPrefix;

    Profile(SharedPreferences pref, String name) {
        mPref = pref;
        mName = name;
        mPrefix = prefPrefix(name);
        migrateLegacySettings();
    }

    public String getName() {
        return mName;
    }

    public String getProtocol() { return "fragment"; }
    public void setProtocol(String protocol) { /* Fragment-only build */ }

    public String getServer() {
        return mPref.getString(key("server"), "127.0.0.1");
    }

    public void setServer(String server) {
        mPref.edit().putString(key("server"), server).commit();
    }

    public int getPort() {
        return mPref.getInt(key("port"), 1080);
    }

    public void setPort(int port) {
        mPref.edit().putInt(key("port"), port).commit();
    }

    public boolean isUserPw() {
        return mPref.getBoolean(key("userpw"), false);
    }

    public void setIsUserpw(boolean is) {
        mPref.edit().putBoolean(key("userpw"), is).commit();
    }

    public String getUsername() {
        return mPref.getString(key("username"), "");
    }

    public void setUsername(String username) {
        mPref.edit().putString(key("username"), username).commit();
    }

    public String getPassword() {
        return mPref.getString(key("password"), "");
    }

    public void setPassword(String password) {
        mPref.edit().putString(key("password"), password).commit();
    }

    public boolean isPerApp() {
        return mPref.getBoolean(key("perapp"), false);
    }

    public void setIsPerApp(boolean is) {
        mPref.edit().putBoolean(key("perapp"), is).commit();
    }

    public boolean isBypassApp() {
        return mPref.getBoolean(key("appbypass"), false);
    }

    public void setIsBypassApp(boolean is) {
        mPref.edit().putBoolean(key("appbypass"), is).commit();
    }

    public String getAppList() {
        return mPref.getString(key("applist"), "");
    }

    public void setAppList(String list) {
        mPref.edit().putString(key("applist"), list).commit();
    }

    public boolean autoConnect() {
        return mPref.getBoolean(key("auto"), false);
    }

    public void setAutoConnect(boolean auto) {
        mPref.edit().putBoolean(key("auto"), auto).commit();
    }

    public String getTlsRecordPositions() {
        return mPref.getString(key("tlsrec_positions"), ByeDpiSettings.DEFAULT_POSITION);
    }

    public void setTlsRecordPositions(String value) {
        mPref.edit().putString(key("tlsrec_positions"), value).commit();
    }

    public String getDesyncMode() {
        return ByeDpiSettings.normalizeDesyncMode(
                mPref.getString(key("desync_mode"), ByeDpiSettings.DEFAULT_DESYNC_MODE));
    }

    public void setDesyncMode(String mode) {
        mPref.edit().putString(key("desync_mode"), ByeDpiSettings.normalizeDesyncMode(mode)).commit();
    }

    public String getFakeSni() {
        return "";
    }

    public void setFakeSni(String sni) {
    }

    public int getFakeTtl() {
        return ByeDpiSettings.DEFAULT_FAKE_TTL;
    }

    public void setFakeTtl(int ttl) {
    }

    public boolean isFakeSniEnabled() {
        return false;
    }

    public void setFakeSniEnabled(boolean enabled) {
    }

    public boolean isDohEnabled() {
        return mPref.getBoolean(key("doh_enabled"), ByeDpiSettings.DEFAULT_DOH_ENABLED);
    }

    public void setDohEnabled(boolean enabled) {
        mPref.edit().putBoolean(key("doh_enabled"), enabled).commit();
    }

    public String getDohUrl() {
        String raw = mPref.getString(key("doh_url"), ByeDpiSettings.DEFAULT_DOH_URL);
        if (raw == null || raw.trim().isEmpty()) {
            return ByeDpiSettings.DEFAULT_DOH_URL;
        }
        return raw.trim();
    }

    public void setDohUrl(String url) {
        String clean = (url == null || url.trim().isEmpty()) ? ByeDpiSettings.DEFAULT_DOH_URL : url.trim();
        mPref.edit().putString(key("doh_url"), clean).commit();
    }

    public boolean isBlockQuic() {
        return mPref.getBoolean(key("block_quic"), ByeDpiSettings.DEFAULT_BLOCK_QUIC);
    }

    public void setBlockQuic(boolean block) {
        mPref.edit().putBoolean(key("block_quic"), block).commit();
    }

    public String getDnsHostOverrides() {
        String prefKey = key("dns_host_overrides");
        if (mPref.contains(prefKey)) return mPref.getString(prefKey, "");
        String defaults = ByeDpiSettings.DEFAULT_HOSTS;
        mPref.edit().putString(prefKey, defaults).commit();
        return defaults;
    }

    public void setDnsHostOverrides(String value) {
        mPref.edit().putString(key("dns_host_overrides"), value).commit();
    }

    private void migrateLegacySettings() {
        String legacyKey = key("fragment_json");
        SharedPreferences.Editor edit = mPref.edit();
        boolean changed = false;
        if (mPref.contains(legacyKey)) {
            String raw = mPref.getString(legacyKey, "");
            String tlsKey = key("tlsrec_positions");
            String hostsKey = key("dns_host_overrides");
            if (!mPref.contains(tlsKey)) edit.putString(tlsKey, LegacyProfileMigration.tlsPositions(raw));
            if (!mPref.contains(hostsKey)) edit.putString(hostsKey, LegacyProfileMigration.hostOverrides(raw));
            edit.remove(legacyKey);
            changed = true;
        }
        for (String oldKey : new String[]{"private_dns", "dot_enabled", "doh_servers", "secure_dns_enabled"}) {
            if (mPref.contains(key(oldKey))) {
                edit.remove(key(oldKey));
                changed = true;
            }
        }
        if (changed) {
            edit.commit();
        }
    }

    void delete() {
        mPref.edit()
                .remove(key("server"))
                .remove(key("port"))
                .remove(key("userpw"))
                .remove(key("username"))
                .remove(key("password"))
                .remove(key("perapp"))
                .remove(key("appbypass"))
                .remove(key("applist"))
                .remove(key("auto"))
                .remove(key("fragment_json"))
                .remove(key("tlsrec_positions"))
                .remove(key("desync_mode"))
                .remove(key("fake_sni"))
                .remove(key("fake_ttl"))
                .remove(key("fake_sni_enabled"))
                .remove(key("doh_enabled"))
                .remove(key("doh_url"))
                .remove(key("block_quic"))
                .remove(key("dns_host_overrides"))
                .remove(key("doh_servers"))
                .remove(key("secure_dns_enabled"))
                .remove(key("protocol"))
                .commit();
    }

    private String key(String k) {
        return mPrefix + k;
    }

    private static String prefPrefix(String name) {
        return name.replace("_", "__").replace(" ", "_");
    }
}
