package net.typeblog.socks.util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * Lightweight DNS-over-TLS (port 853) resolver using Android VPN protected sockets.
 */
public final class DotDnsResolver {
    public interface SocketProtector {
        boolean protect(Socket socket);
    }

    private static final int TIMEOUT_MS = 3500;
    private static final int MAX_DNS_PACKET = 4096;

    private final SocketProtector protector;

    public DotDnsResolver(SocketProtector protector) {
        this.protector = protector;
    }

    public byte[] resolveQuery(byte[] query, String dotEndpoint) {
        if (query == null || query.length < 12) return null;
        String host = extractHost(dotEndpoint);
        if (host == null || host.isEmpty()) host = "1.1.1.1";

        SSLSocket sslSocket = null;
        try {
            Socket plain = new Socket();
            if (protector != null && !protector.protect(plain)) {
                try { plain.close(); } catch (Exception ignored) { }
                return null;
            }
            plain.setTcpNoDelay(true);
            plain.setSoTimeout(TIMEOUT_MS);
            plain.connect(new InetSocketAddress(host, 853), TIMEOUT_MS);

            SSLSocketFactory factory = (SSLSocketFactory) SSLSocketFactory.getDefault();
            sslSocket = (SSLSocket) factory.createSocket(plain, host, 853, true);
            sslSocket.setSoTimeout(TIMEOUT_MS);
            sslSocket.setTcpNoDelay(true);
            sslSocket.startHandshake();

            DataOutputStream out = new DataOutputStream(sslSocket.getOutputStream());
            DataInputStream in = new DataInputStream(sslSocket.getInputStream());
            out.writeShort(query.length);
            out.write(query);
            out.flush();

            int respLen = in.readUnsignedShort();
            if (respLen < 12 || respLen > MAX_DNS_PACKET) return null;
            byte[] resp = new byte[respLen];
            in.readFully(resp);
            return resp;
        } catch (Exception ignored) {
            return null;
        } finally {
            if (sslSocket != null) {
                try { sslSocket.close(); } catch (Exception ignored) { }
            }
        }
    }

    public static String extractHost(String endpoint) {
        if (endpoint == null) return "1.1.1.1";
        String s = endpoint.trim();
        if (s.isEmpty()) return "1.1.1.1";
        if (s.startsWith("tls://")) s = s.substring(6);
        else if (s.startsWith("https://")) s = s.substring(8);
        int slash = s.indexOf('/');
        if (slash >= 0) s = s.substring(0, slash);
        int colon = s.indexOf(':');
        if (colon >= 0) s = s.substring(0, colon);
        s = s.trim();
        return s.isEmpty() ? "1.1.1.1" : s;
    }
}
