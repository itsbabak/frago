package net.typeblog.socks.util;

import android.net.VpnService;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Collections;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.SNIHostName;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public final class UniversalProxyRelay {
    public static final String PROTO_BYEDPI = "byedpi";
    public static final String PROTO_SOCKS5 = "socks5";
    public static final String PROTO_HTTP = "http";
    public static final String PROTO_SHADOWSOCKS = "shadowsocks";
    public static final String PROTO_VLESS = "vless";

    public static final class Config {
        public String protocol = PROTO_BYEDPI;
        public String serverHost = "";
        public int serverPort = 443;
        public String username = "";      // SOCKS5/HTTP user OR SS cipher method
        public String password = "";      // SOCKS5/HTTP pass OR SS password OR VLESS UUID
        public String sni = "";           // VLESS SNI
        public String wsPath = "";        // VLESS WebSocket path (empty = raw TCP)
        public boolean tlsEnabled = true; // VLESS TLS
        public boolean chainByeDpi = false; // Optional: route upstream through local ByeDPI
        public int byeDpiLocalPort = 0;
    }

    private final VpnService vpnService;
    private final Config config;
    private ServerSocket serverSocket;
    private ExecutorService pool;
    private volatile boolean running = false;

    public UniversalProxyRelay(VpnService vpnService, Config config) {
        this.vpnService = vpnService;
        this.config = config;
    }

    public synchronized int start() throws IOException {
        if (running && serverSocket != null) return serverSocket.getLocalPort();
        serverSocket = new ServerSocket();
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress("127.0.0.1", 0), 64);
        running = true;
        pool = Executors.newCachedThreadPool();
        pool.execute(this::acceptLoop);
        return serverSocket.getLocalPort();
    }

    public synchronized void stop() {
        running = false;
        if (serverSocket != null) {
            try { serverSocket.close(); } catch (Exception ignored) { }
            serverSocket = null;
        }
        if (pool != null) {
            pool.shutdownNow();
            pool = null;
        }
    }

    private void acceptLoop() {
        while (running && serverSocket != null && !serverSocket.isClosed()) {
            try {
                final Socket client = serverSocket.accept();
                client.setTcpNoDelay(true);
                pool.execute(() -> handleSocksClient(client));
            } catch (IOException ignored) {
                if (!running) break;
            }
        }
    }

    private void handleSocksClient(Socket client) {
        Socket upstream = null;
        try {
            DataInputStream in = new DataInputStream(client.getInputStream());
            OutputStream out = client.getOutputStream();

            int ver = in.readUnsignedByte();
            if (ver != 0x05) return;
            int nMethods = in.readUnsignedByte();
            in.readFully(new byte[nMethods]);
            out.write(new byte[]{0x05, 0x00});
            out.flush();

            int reqVer = in.readUnsignedByte();
            int cmd = in.readUnsignedByte();
            in.readUnsignedByte();
            int atyp = in.readUnsignedByte();
            if (reqVer != 0x05 || cmd != 0x01) {
                out.write(new byte[]{0x05, 0x07, 0x00, 0x01, 0, 0, 0, 0, 0, 0});
                return;
            }

            String destHost;
            byte[] rawAddr;
            if (atyp == 0x01) {
                byte[] ip = new byte[4];
                in.readFully(ip);
                destHost = InetAddress.getByAddress(ip).getHostAddress();
                rawAddr = new byte[7];
                rawAddr[0] = 0x01;
                System.arraycopy(ip, 0, rawAddr, 1, 4);
            } else if (atyp == 0x03) {
                int len = in.readUnsignedByte();
                byte[] domain = new byte[len];
                in.readFully(domain);
                destHost = new String(domain, StandardCharsets.UTF_8);
                rawAddr = new byte[4 + len];
                rawAddr[0] = 0x03;
                rawAddr[1] = (byte) len;
                System.arraycopy(domain, 0, rawAddr, 2, len);
            } else if (atyp == 0x04) {
                byte[] ip6 = new byte[16];
                in.readFully(ip6);
                destHost = InetAddress.getByAddress(ip6).getHostAddress();
                rawAddr = new byte[19];
                rawAddr[0] = 0x04;
                System.arraycopy(ip6, 0, rawAddr, 1, 16);
            } else {
                return;
            }
            int destPort = in.readUnsignedShort();
            rawAddr[rawAddr.length - 2] = (byte) ((destPort >> 8) & 0xFF);
            rawAddr[rawAddr.length - 1] = (byte) (destPort & 0xFF);

            upstream = openUpstreamSocket();

            if (PROTO_SOCKS5.equals(config.protocol)) {
                tunnelViaSocks5(in, out, upstream, rawAddr);
            } else if (PROTO_HTTP.equals(config.protocol)) {
                tunnelViaHttp(in, out, upstream, destHost, destPort);
            } else if (PROTO_SHADOWSOCKS.equals(config.protocol)) {
                tunnelViaShadowsocks(in, out, upstream, rawAddr);
            } else if (PROTO_VLESS.equals(config.protocol)) {
                tunnelViaVless(in, out, upstream, atyp, destHost, destPort);
            }
        } catch (Exception ignored) {
        } finally {
            closeQuietly(upstream);
            closeQuietly(client);
        }
    }

    /**
     * Opens direct protected socket to remote server, OR chains through local ByeDPI
     * only if user explicitly checked "Use Fragment / OOB".
     */
    private Socket openUpstreamSocket() throws Exception {
        if (config.chainByeDpi && config.byeDpiLocalPort > 0) {
            Socket local = new Socket();
            local.setTcpNoDelay(true);
            local.connect(new InetSocketAddress("127.0.0.1", config.byeDpiLocalPort), 5000);
            DataInputStream bIn = new DataInputStream(local.getInputStream());
            OutputStream bOut = local.getOutputStream();
            bOut.write(new byte[]{0x05, 0x01, 0x00});
            bOut.flush();
            if (bIn.readUnsignedByte() != 0x05 || bIn.readUnsignedByte() != 0x00) {
                throw new IOException("ByeDPI local handshake failed");
            }
            byte[] hostBytes = config.serverHost.getBytes(StandardCharsets.UTF_8);
            ByteArrayOutputStream req = new ByteArrayOutputStream();
            req.write(new byte[]{0x05, 0x01, 0x00, 0x03, (byte) hostBytes.length});
            req.write(hostBytes);
            req.write((config.serverPort >> 8) & 0xFF);
            req.write(config.serverPort & 0xFF);
            bOut.write(req.toByteArray());
            bOut.flush();
            if (bIn.readUnsignedByte() != 0x05 || bIn.readUnsignedByte() != 0x00) {
                throw new IOException("ByeDPI upstream connect failed");
            }
            bIn.readUnsignedByte();
            int rAtyp = bIn.readUnsignedByte();
            if (rAtyp == 0x01) bIn.readFully(new byte[6]);
            else if (rAtyp == 0x03) bIn.readFully(new byte[bIn.readUnsignedByte() + 2]);
            else if (rAtyp == 0x04) bIn.readFully(new byte[18]);
            return local;
        }

        Socket socket = new Socket();
        if (vpnService != null) vpnService.protect(socket);
        socket.setTcpNoDelay(true);
        socket.connect(new InetSocketAddress(config.serverHost, config.serverPort), 8000);
        return socket;
    }

    private void sendSocksSuccess(OutputStream out) throws IOException {
        out.write(new byte[]{0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0});
        out.flush();
    }

    // 1. Upstream SOCKS5
    private void tunnelViaSocks5(InputStream cIn, OutputStream cOut,
                                 Socket upstream, byte[] rawAddr) throws Exception {
        DataInputStream uIn = new DataInputStream(upstream.getInputStream());
        OutputStream uOut = upstream.getOutputStream();
        boolean hasAuth = config.username != null && !config.username.isEmpty();
        uOut.write(hasAuth ? new byte[]{0x05, 0x02, 0x00, 0x02} : new byte[]{0x05, 0x01, 0x00});
        uOut.flush();

        int ver = uIn.readUnsignedByte();
        int method = uIn.readUnsignedByte();
        if (ver != 0x05 || method == 0xFF) throw new IOException("SOCKS5 auth rejected");
        if (method == 0x02) {
            byte[] u = config.username.getBytes(StandardCharsets.UTF_8);
            byte[] p = (config.password == null ? "" : config.password).getBytes(StandardCharsets.UTF_8);
            uOut.write(0x01);
            uOut.write(u.length);
            uOut.write(u);
            uOut.write(p.length);
            uOut.write(p);
            uOut.flush();
            if (uIn.readUnsignedByte() != 0x01 || uIn.readUnsignedByte() != 0x00) {
                throw new IOException("SOCKS5 credentials invalid");
            }
        }
        uOut.write(new byte[]{0x05, 0x01, 0x00});
        uOut.write(rawAddr);
        uOut.flush();

        if (uIn.readUnsignedByte() != 0x05 || uIn.readUnsignedByte() != 0x00) {
            throw new IOException("SOCKS5 connect failed");
        }
        uIn.readUnsignedByte();
        int rAtyp = uIn.readUnsignedByte();
        if (rAtyp == 0x01) uIn.readFully(new byte[6]);
        else if (rAtyp == 0x03) uIn.readFully(new byte[uIn.readUnsignedByte() + 2]);
        else if (rAtyp == 0x04) uIn.readFully(new byte[18]);

        sendSocksSuccess(cOut);
        pipeBidirectional(cIn, cOut, uIn, uOut);
    }

    // 2. Upstream HTTP CONNECT
    private void tunnelViaHttp(InputStream cIn, OutputStream cOut,
                               Socket upstream, String host, int port) throws Exception {
        OutputStream uOut = upstream.getOutputStream();
        InputStream uIn = upstream.getInputStream();
        String target = (host.contains(":") ? "[" + host + "]" : host) + ":" + port;
        StringBuilder req = new StringBuilder();
        req.append("CONNECT ").append(target).append(" HTTP/1.1\r\n");
        req.append("Host: ").append(target).append("\r\n");
        if (config.username != null && !config.username.isEmpty()) {
            String token = Base64.encodeToString(
                    (config.username + ":" + (config.password == null ? "" : config.password)).getBytes(StandardCharsets.UTF_8),
                    Base64.NO_WRAP);
            req.append("Proxy-Authorization: Basic ").append(token).append("\r\n");
        }
        req.append("\r\n");
        uOut.write(req.toString().getBytes(StandardCharsets.ISO_8859_1));
        uOut.flush();

        String statusLine = readAsciiLine(uIn);
        if (statusLine == null || !statusLine.contains(" 200")) {
            throw new IOException("HTTP CONNECT failed: " + statusLine);
        }
        while (true) {
            String line = readAsciiLine(uIn);
            if (line == null || line.isEmpty()) break;
        }
        sendSocksSuccess(cOut);
        pipeBidirectional(cIn, cOut, uIn, uOut);
    }

    // 3. Upstream Shadowsocks AEAD (aes-256-gcm & chacha20-ietf-poly1305)
    private void tunnelViaShadowsocks(InputStream cIn, OutputStream cOut,
                                      Socket upstream, byte[] rawAddr) throws Exception {
        String method = config.username == null ? "aes-256-gcm" : config.username.trim().toLowerCase();
        boolean isChaCha = method.contains("chacha20");
        int keyLen = method.contains("128") ? 16 : 32;
        byte[] masterKey = evpBytesToKey((config.password == null ? "" : config.password).getBytes(StandardCharsets.UTF_8), keyLen);

        byte[] txSalt = new byte[keyLen];
        new SecureRandom().nextBytes(txSalt);
        byte[] txSubkey = hkdfSha1(masterKey, txSalt, "ss-subkey".getBytes(StandardCharsets.UTF_8), keyLen);

        OutputStream uOut = upstream.getOutputStream();
        DataInputStream uIn = new DataInputStream(upstream.getInputStream());
        uOut.write(txSalt);
        final long[] txNonce = {0L};
        writeSsChunk(uOut, txSubkey, isChaCha, txNonce, rawAddr, 0, rawAddr.length);
        uOut.flush();

        sendSocksSuccess(cOut);

        Thread up = new Thread(() -> {
            byte[] buf = new byte[16384];
            try {
                int n;
                while ((n = cIn.read(buf)) != -1) {
                    writeSsChunk(uOut, txSubkey, isChaCha, txNonce, buf, 0, n);
                    uOut.flush();
                }
            } catch (Exception ignored) {
            } finally {
                closeQuietly(upstream);
            }
        });
        up.start();

        byte[] rxSalt = new byte[keyLen];
        uIn.readFully(rxSalt);
        byte[] rxSubkey = hkdfSha1(masterKey, rxSalt, "ss-subkey".getBytes(StandardCharsets.UTF_8), keyLen);
        long rxNonce = 0L;
        while (true) {
            byte[] encLen = new byte[2 + 16];
            uIn.readFully(encLen);
            byte[] lenBytes = ssCrypt(false, rxSubkey, isChaCha, rxNonce++, encLen, 0, encLen.length);
            int payloadLen = ((lenBytes[0] & 0xFF) << 8) | (lenBytes[1] & 0xFF);
            if (payloadLen <= 0 || payloadLen > 0x3FFF) break;
            byte[] encPayload = new byte[payloadLen + 16];
            uIn.readFully(encPayload);
            byte[] plain = ssCrypt(false, rxSubkey, isChaCha, rxNonce++, encPayload, 0, encPayload.length);
            cOut.write(plain);
            cOut.flush();
        }
        up.join(200);
    }

    private static void writeSsChunk(OutputStream out, byte[] subkey, boolean isChaCha, long[] nonce,
                                     byte[] data, int off, int len) throws Exception {
        int pos = off;
        int rem = len;
        while (rem > 0) {
            int chunk = Math.min(rem, 0x3FFF);
            byte[] lenBuf = new byte[]{(byte) ((chunk >> 8) & 0xFF), (byte) (chunk & 0xFF)};
            out.write(ssCrypt(true, subkey, isChaCha, nonce[0]++, lenBuf, 0, 2));
            out.write(ssCrypt(true, subkey, isChaCha, nonce[0]++, data, pos, chunk));
            pos += chunk;
            rem -= chunk;
        }
    }

    private static byte[] ssCrypt(boolean encrypt, byte[] subkey, boolean isChaCha, long counter,
                                  byte[] input, int off, int len) throws Exception {
        byte[] iv = new byte[12];
        for (int i = 0; i < 8; i++) iv[i] = (byte) ((counter >>> (8 * i)) & 0xFF);
        Cipher cipher = Cipher.getInstance(isChaCha ? "ChaCha20-Poly1305" : "AES/GCM/NoPadding");
        if (isChaCha) {
            cipher.init(encrypt ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE,
                    new SecretKeySpec(subkey, "ChaCha20"), new IvParameterSpec(iv));
        } else {
            cipher.init(encrypt ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE,
                    new SecretKeySpec(subkey, "AES"), new GCMParameterSpec(128, iv));
        }
        return cipher.doFinal(input, off, len);
    }

    private static byte[] evpBytesToKey(byte[] password, int keyLen) throws Exception {
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        byte[] key = new byte[keyLen];
        byte[] prev = new byte[0];
        int offset = 0;
        while (offset < keyLen) {
            md5.reset();
            md5.update(prev);
            md5.update(password);
            prev = md5.digest();
            int copy = Math.min(prev.length, keyLen - offset);
            System.arraycopy(prev, 0, key, offset, copy);
            offset += copy;
        }
        return key;
    }

    private static byte[] hkdfSha1(byte[] ikm, byte[] salt, byte[] info, int len) throws Exception {
        Mac hmac = Mac.getInstance("HmacSHA1");
        hmac.init(new SecretKeySpec(salt, "HmacSHA1"));
        byte[] prk = hmac.doFinal(ikm);
        hmac.init(new SecretKeySpec(prk, "HmacSHA1"));
        hmac.update(info);
        hmac.update((byte) 1);
        return Arrays.copyOf(hmac.doFinal(), len);
    }

    // 4. Upstream VLESS (Raw TCP or WebSocket + optional TLS)
    private void tunnelViaVless(InputStream cIn, OutputStream cOut,
                                Socket rawUpstream, int atyp, String destHost, int destPort) throws Exception {
        Socket transport = rawUpstream;
        String sniHost = (config.sni != null && !config.sni.trim().isEmpty()) ? config.sni.trim() : config.serverHost;

        if (config.tlsEnabled) {
            SSLSocketFactory factory = (SSLSocketFactory) SSLSocketFactory.getDefault();
            SSLSocket ssl = (SSLSocket) factory.createSocket(rawUpstream, sniHost, config.serverPort, true);
            SSLParameters params = ssl.getSSLParameters();
            params.setServerNames(Collections.singletonList(new SNIHostName(sniHost)));
            ssl.setSSLParameters(params);
            ssl.startHandshake();
            transport = ssl;
        }

        InputStream uIn = transport.getInputStream();
        OutputStream uOut = transport.getOutputStream();
        byte[] vlessHeader = buildVlessHeader(config.password, atyp, destHost, destPort);

        if (config.wsPath != null && !config.wsPath.trim().isEmpty()) {
            String path = config.wsPath.startsWith("/") ? config.wsPath : "/" + config.wsPath;
            byte[] keyBytes = new byte[16];
            new SecureRandom().nextBytes(keyBytes);
            String wsKey = Base64.encodeToString(keyBytes, Base64.NO_WRAP);
            String hs = "GET " + path + " HTTP/1.1\r\n" +
                    "Host: " + sniHost + "\r\n" +
                    "Upgrade: websocket\r\n" +
                    "Connection: Upgrade\r\n" +
                    "Sec-WebSocket-Key: " + wsKey + "\r\n" +
                    "Sec-WebSocket-Version: 13\r\n\r\n";
            uOut.write(hs.getBytes(StandardCharsets.ISO_8859_1));
            uOut.flush();
            String resp = readAsciiLine(uIn);
            if (resp == null || !resp.contains("101")) {
                throw new IOException("WebSocket upgrade failed: " + resp);
            }
            while (true) {
                String line = readAsciiLine(uIn);
                if (line == null || line.isEmpty()) break;
            }
            writeWsBinaryFrame(uOut, vlessHeader, 0, vlessHeader.length);
            uOut.flush();
            sendSocksSuccess(cOut);
            pipeWebSocketBidirectional(cIn, cOut, new DataInputStream(uIn), uOut);
        } else {
            uOut.write(vlessHeader);
            uOut.flush();
            sendSocksSuccess(cOut);
            // Strip 2-byte VLESS response header (version + addon len)
            DataInputStream dIn = new DataInputStream(uIn);
            dIn.readUnsignedByte();
            int addonLen = dIn.readUnsignedByte();
            if (addonLen > 0) dIn.readFully(new byte[addonLen]);
            pipeBidirectional(cIn, cOut, dIn, uOut);
        }
    }

    private static byte[] buildVlessHeader(String uuidStr, int atyp, String host, int port) throws Exception {
        UUID uuid = UUID.fromString(uuidStr.trim());
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(0x00); // Version 0
        ByteBuffer bb = ByteBuffer.allocate(16);
        bb.putLong(uuid.getMostSignificantBits());
        bb.putLong(uuid.getLeastSignificantBits());
        out.write(bb.array());
        out.write(0x00); // Addons length = 0
        out.write(0x01); // Command = TCP
        out.write((port >> 8) & 0xFF);
        out.write(port & 0xFF);

        if (atyp == 0x01) {
            out.write(0x01);
            out.write(InetAddress.getByName(host).getAddress());
        } else if (atyp == 0x04) {
            out.write(0x03);
            out.write(InetAddress.getByName(host).getAddress());
        } else {
            byte[] dom = host.getBytes(StandardCharsets.UTF_8);
            out.write(0x02);
            out.write(dom.length);
            out.write(dom);
        }
        return out.toByteArray();
    }

    private static void writeWsBinaryFrame(OutputStream out, byte[] data, int off, int len) throws IOException {
        byte[] mask = new byte[4];
        new SecureRandom().nextBytes(mask);
        out.write(0x82); // FIN + Binary
        if (len <= 125) {
            out.write(0x80 | len);
        } else if (len <= 65535) {
            out.write(0x80 | 126);
            out.write((len >> 8) & 0xFF);
            out.write(len & 0xFF);
        } else {
            out.write(0x80 | 127);
            for (int i = 7; i >= 0; i--) out.write((int) (((long) len >>> (8 * i)) & 0xFF));
        }
        out.write(mask);
        byte[] masked = new byte[len];
        for (int i = 0; i < len; i++) masked[i] = (byte) (data[off + i] ^ mask[i & 3]);
        out.write(masked);
    }

    private void pipeWebSocketBidirectional(InputStream cIn, OutputStream cOut,
                                            DataInputStream uIn, OutputStream uOut) throws Exception {
        Thread up = new Thread(() -> {
            byte[] buf = new byte[16384];
            try {
                int n;
                while ((n = cIn.read(buf)) != -1) {
                    writeWsBinaryFrame(uOut, buf, 0, n);
                    uOut.flush();
                }
            } catch (Exception ignored) {
            } finally {
                closeQuietly(uOut);
            }
        });
        up.start();

        boolean firstPacket = true;
        while (true) {
            int b0 = uIn.readUnsignedByte();
            int b1 = uIn.readUnsignedByte();
            int opcode = b0 & 0x0F;
            if (opcode == 0x08) break;
            long len = b1 & 0x7F;
            if (len == 126) len = uIn.readUnsignedShort();
            else if (len == 127) len = uIn.readLong();
            byte[] payload = new byte[(int) len];
            uIn.readFully(payload);
            if (opcode == 0x02 || opcode == 0x01) {
                int start = 0;
                if (firstPacket && payload.length >= 2) {
                    firstPacket = false;
                    int addonLen = payload[1] & 0xFF;
                    start = Math.min(payload.length, 2 + addonLen);
                }
                if (payload.length > start) {
                    cOut.write(payload, start, payload.length - start);
                    cOut.flush();
                }
            }
        }
        up.join(200);
    }

    private void pipeBidirectional(InputStream cIn, OutputStream cOut,
                                   InputStream uIn, OutputStream uOut) throws Exception {
        Thread up = new Thread(() -> {
            byte[] buf = new byte[16384];
            try {
                int n;
                while ((n = cIn.read(buf)) != -1) {
                    uOut.write(buf, 0, n);
                    uOut.flush();
                }
            } catch (Exception ignored) {
            } finally {
                closeQuietly(uOut);
            }
        });
        up.start();

        byte[] buf = new byte[16384];
        int n;
        while ((n = uIn.read(buf)) != -1) {
            cOut.write(buf, 0, n);
            cOut.flush();
        }
        up.join(200);
    }

    private static String readAsciiLine(InputStream in) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        int prev = -1, cur;
        while ((cur = in.read()) != -1) {
            if (prev == '\r' && cur == '\n') {
                byte[] b = buf.toByteArray();
                return new String(b, 0, b.length - 1, StandardCharsets.ISO_8859_1);
            }
            buf.write(cur);
            prev = cur;
        }
        return buf.size() == 0 ? null : buf.toString(StandardCharsets.ISO_8859_1.name());
    }

    private static void closeQuietly(AutoCloseable c) {
        if (c != null) {
            try { c.close(); } catch (Exception ignored) { }
        }
    }
}