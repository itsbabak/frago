package net.typeblog.socks;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.ServiceConnection;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.IBinder;
import android.os.SystemClock;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.ListPreference;
import android.preference.PreferenceCategory;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.widget.CompoundButton;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import net.typeblog.socks.util.Profile;
import net.typeblog.socks.util.ProfileManager;
import net.typeblog.socks.util.UniversalProxyRelay;
import net.typeblog.socks.util.Utility;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

import static net.typeblog.socks.util.Constants.*;

public class ProfileFragment extends PreferenceFragment implements Preference.OnPreferenceClickListener, Preference.OnPreferenceChangeListener,
        CompoundButton.OnCheckedChangeListener {
    private ProfileManager mManager;
    private Profile mProfile;

    private Switch mSwitch;
    private boolean mRunning = false;
    private boolean mStarting = false, mStopping = false;
    private final Handler mStopHandler = new Handler(Looper.getMainLooper());
    private final Runnable mStopTimeout = new Runnable() {
        @Override public void run() {
            if (!mStopping) return;
            mRunning = false;
            updateState();
        }
    };
    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName p1, IBinder binder) {
            mBinder = IVpnService.Stub.asInterface(binder);
            try {
                mRunning = mBinder.isRunning();
            } catch (Exception ignored) { mRunning = false; }
            if (mStarting && !mRunning) {
                keepSwitchOnWhileStarting();
                return;
            }
            updateState();
        }

        @Override
        public void onServiceDisconnected(ComponentName p1) {
            mBinder = null;
            mRunning = false;
            if (mStarting) {
                keepSwitchOnWhileStarting();
            } else {
                updateState();
            }
        }
    };
    private IVpnService mBinder;

    private ListPreference mPrefProfile;
    private EditTextPreference mPrefTlsPositions;
    private Preference mPrefDesyncMode;
    private ListPreference mPrefFakeTtl;
    private ListPreference mPrefTlsCount;
    private Preference mPrefDnsHosts;
    private Preference mPrefAppList;
    private Preference mPrefPingTest;
    private volatile boolean mPinging = false;

    private PreferenceCategory mProtoCategory;
    private ListPreference mPrefProtocol;
    private Preference mPrefImportUri;
    private EditTextPreference mPrefServer;
    private EditTextPreference mPrefPort;
    private EditTextPreference mPrefUsername;
    private ListPreference mPrefSsMethod;
    private EditTextPreference mPrefPassword;
    private EditTextPreference mPrefVlessSni;
    private EditTextPreference mPrefVlessWsPath;
    private CheckBoxPreference mPrefVlessTls;
    private CheckBoxPreference mPrefChainFragment;

    private PreferenceCategory mTlsCategory, mDnsCategory, mAdvancedCategory;
    private android.preference.PreferenceScreen mScreen;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings);
        mScreen = getPreferenceScreen();
        mScreen.setOrderingAsAdded(false);
        setHasOptionsMenu(true);
        mManager = new ProfileManager(getActivity().getApplicationContext());
        initPreferences();
        reload();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.main, menu);

        MenuItem s = menu.findItem(R.id.switch_main);
        mSwitch = s.getActionView().findViewById(R.id.switch_action_button);
        mSwitch.setOnCheckedChangeListener(this);
        checkState();
    }

    @Override public void onResume() {
        super.onResume();
        if (!mReceiverRegistered && getActivity() != null) {
            IntentFilter filter = new IntentFilter(SocksVpnService.ACTION_STATE);
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                getActivity().registerReceiver(mStateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                getActivity().registerReceiver(mStateReceiver, filter);
            }
            mReceiverRegistered = true;
        }
        if (mSwitch != null) checkState();
    }

    @Override public void onPause() {
        if (mReceiverRegistered && getActivity() != null) {
            try { getActivity().unregisterReceiver(mStateReceiver); } catch (Exception ignored) { }
            mReceiverRegistered = false;
        }
        if (mBound && getActivity() != null) {
            try { getActivity().unbindService(mConnection); } catch (Exception ignored) { }
            mBound = false; mBinder = null;
        }
        super.onPause();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.prof_add) {
            addProfile();
            return true;
        } else if (id == R.id.prof_del) {
            removeProfile();
            return true;
        } else if (id == R.id.prof_rename) {
            renameProfile();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onPreferenceClick(Preference p) {
        if (p == mPrefAppList) { showAppPicker(); return true; }
        if (p == mPrefDnsHosts) { showDnsHostEditor(); return true; }
        if (p == mPrefPingTest) { runPingTest(); return true; }
        if (p == mPrefImportUri) { showUriImportDialog(); return true; }
        return false;
    }

    @Override
    public boolean onPreferenceChange(Preference p, Object newValue) {
        if (p == mPrefProfile) {
            String name = newValue.toString();
            mProfile = mManager.getProfile(name);
            mManager.switchDefault(name);
            reload();
            return true;
        } else if (p == mPrefProtocol) {
            String proto = newValue.toString();
            mProfile.setProtocol(proto);
            if (!UniversalProxyRelay.PROTO_BYEDPI.equals(proto)) {
                mProfile.setChainFragmentEnabled(false);
            }
            if (UniversalProxyRelay.PROTO_SHADOWSOCKS.equals(proto) && mProfile.getUsername().isEmpty()) {
                mProfile.setUsername("aes-256-gcm");
            }
            reload();
            return true;
        } else if (p == mPrefServer) {
            String host = newValue.toString().trim();
            mProfile.setServer(host);
            mPrefServer.setSummary(host.isEmpty() ? "Not set" : host);
            return true;
        } else if (p == mPrefPort) {
            try {
                int port = Integer.parseInt(newValue.toString().trim());
                if (port < 1 || port > 65535) throw new NumberFormatException();
                mProfile.setPort(port);
                mPrefPort.setSummary(Integer.toString(port));
                return true;
            } catch (Exception e) {
                Toast.makeText(getActivity(), "Invalid port (1-65535)", Toast.LENGTH_SHORT).show();
                return false;
            }
        } else if (p == mPrefUsername) {
            String u = newValue.toString().trim();
            mProfile.setUsername(u);
            mPrefUsername.setSummary(u.isEmpty() ? "Optional" : u);
            return true;
        } else if (p == mPrefSsMethod) {
            String m = newValue.toString();
            mProfile.setUsername(m);
            mPrefSsMethod.setSummary(m);
            return true;
        } else if (p == mPrefPassword) {
            String pass = newValue.toString().trim();
            mProfile.setPassword(pass);
            updatePasswordSummary();
            return true;
        } else if (p == mPrefVlessSni) {
            String sni = newValue.toString().trim();
            mProfile.setVlessSni(sni);
            mPrefVlessSni.setSummary(sni.isEmpty() ? "Same as server host" : sni);
            return true;
        } else if (p == mPrefVlessWsPath) {
            String path = newValue.toString().trim();
            mProfile.setVlessWsPath(path);
            mPrefVlessWsPath.setSummary(path.isEmpty() ? "Empty (Raw TCP mode)" : path);
            return true;
        } else if (p == mPrefVlessTls) {
            boolean tls = Boolean.parseBoolean(newValue.toString());
            mProfile.setVlessTls(tls);
            updateProtocolVisibility();
            return true;
        } else if (p == mPrefChainFragment) {
            boolean chain = Boolean.parseBoolean(newValue.toString());
            mProfile.setChainFragmentEnabled(chain);
            updateProtocolVisibility();
            return true;
        } else if (p == mPrefTlsCount) {
            try {
                int records = Integer.parseInt(newValue.toString());
                if (records < 1 || records > 16) throw new IllegalArgumentException("Choose between 1 and 16 TLS records");
                String positions = net.typeblog.socks.util.ByeDpiSettings.defaultPositionsForRecordCount(records);
                mProfile.setTlsRecordPositions(positions);
                if (mPrefTlsPositions != null) mPrefTlsPositions.setText(positions);
                if (mPrefTlsCount != null) {
                    mPrefTlsCount.setValue(Integer.toString(records));
                    resetList(mPrefTlsCount);
                }
                updateTlsSummary();
                updateDesyncSummary();
                return true;
            } catch (Exception error) {
                Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_LONG).show();
                return false;
            }
        } else if (p == mPrefTlsPositions) {
            try {
                String normalized = net.typeblog.socks.util.ByeDpiSettings.normalizePositions(newValue.toString());
                mProfile.setTlsRecordPositions(normalized);
                if (mPrefTlsCount != null) mPrefTlsCount.setValue(Integer.toString(net.typeblog.socks.util.ByeDpiSettings.recordCount(normalized)));
                updateTlsSummary();
                return true;
            } catch (IllegalArgumentException error) {
                Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_LONG).show();
                return false;
            }
        } else if (p == mPrefDesyncMode) {
            String mode = net.typeblog.socks.util.ByeDpiSettings.normalizeDesyncMode(newValue.toString());
            mProfile.setDesyncMode(mode);
            updateDesyncSummary();
            return true;
        } else if (p == mPrefFakeTtl) {
            try {
                int ttl = net.typeblog.socks.util.ByeDpiSettings.normalizeFakeTtl(Integer.parseInt(newValue.toString()));
                mProfile.setFakeTtl(ttl);
                mPrefFakeTtl.setValue(Integer.toString(ttl));
                mPrefFakeTtl.setSummary("TTL = " + ttl);
                return true;
            } catch (Exception error) {
                Toast.makeText(getActivity(), "Invalid TTL", Toast.LENGTH_SHORT).show();
                return false;
            }
        } else {
            return false;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton p1, boolean checked) {
        if (mStarting || mStopping) {
            if (mSwitch != null) {
                mSwitch.setOnCheckedChangeListener(null);
                mSwitch.setChecked(mRunning || mStarting);
                mSwitch.setOnCheckedChangeListener(this);
            }
            return;
        }
        if (checked) {
            startVpn();
        } else {
            stopVpn();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 0) return;
        if (resultCode == Activity.RESULT_OK) {
            try {
                Utility.startVpn(getActivity(), mProfile);
                checkState();
            } catch (Exception error) {
                Toast.makeText(getActivity(), R.string.connection_start_failed, Toast.LENGTH_LONG).show();
                resetMainSwitch();
            }
        } else {
            mRunning = false;
            updateState();
        }
    }

    private void initPreferences() {
        Activity ctx = getActivity();
        mPrefProfile = (ListPreference) findPreference(PREF_PROFILE);
        mAdvancedCategory = (PreferenceCategory) findPreference("advanced");
        mPrefAppList = findPreference(PREF_ADV_APP_LIST);

        String[] keysToRemove = {
                PREF_ADV_PER_APP,
                PREF_ADV_APP_BYPASS,
                PREF_ADV_AUTO_CONNECT,
                "bypass_mode",
                "app_bypass"
        };
        for (String key : keysToRemove) {
            Preference p = findPreference(key);
            if (p != null) {
                if (mAdvancedCategory != null) mAdvancedCategory.removePreference(p);
                if (mScreen != null) mScreen.removePreference(p);
            }
        }

        if (mAdvancedCategory != null && ctx != null) {
            mPrefPingTest = new Preference(ctx);
            mPrefPingTest.setKey("ping_delay_test");
            mPrefPingTest.setTitle("Test Connection (Ping Delay)");
            mPrefPingTest.setSummary("Tap to measure real HTTPS delay");
            mPrefPingTest.setPersistent(false);
            mPrefPingTest.setOnPreferenceClickListener(this);
            mAdvancedCategory.addPreference(mPrefPingTest);
        }

        if (mPrefAppList != null) {
            mPrefAppList.setTitle("App list (Bypass VPN)");
        }

        if (ctx != null && mScreen != null) {
            mProtoCategory = new PreferenceCategory(ctx);
            mProtoCategory.setKey("outbound_protocol_category");
            mProtoCategory.setTitle("Connection Protocol");
            mScreen.addPreference(mProtoCategory);

            mPrefProtocol = new ListPreference(ctx);
            mPrefProtocol.setKey("outbound_protocol");
            mPrefProtocol.setTitle("Protocol Mode");
            mPrefProtocol.setEntries(new CharSequence[]{
                    "ByeDPI (TLS Record + TCP OOB)",
                    "SOCKS5 Proxy",
                    "HTTP / HTTPS Proxy",
                    "Shadowsocks (AEAD)",
                    "VLESS (TCP / WS + TLS)"
            });
            mPrefProtocol.setEntryValues(new CharSequence[]{
                    UniversalProxyRelay.PROTO_BYEDPI,
                    UniversalProxyRelay.PROTO_SOCKS5,
                    UniversalProxyRelay.PROTO_HTTP,
                    UniversalProxyRelay.PROTO_SHADOWSOCKS,
                    UniversalProxyRelay.PROTO_VLESS
            });
            mPrefProtocol.setPersistent(false);
            mPrefProtocol.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefProtocol);

            mPrefImportUri = new Preference(ctx);
            mPrefImportUri.setKey("import_proxy_uri");
            mPrefImportUri.setTitle("Import Proxy Link (URI)");
            mPrefImportUri.setSummary("Paste vless://, ss://, socks5:// or http:// link");
            mPrefImportUri.setPersistent(false);
            mPrefImportUri.setOnPreferenceClickListener(this);
            mProtoCategory.addPreference(mPrefImportUri);

            mPrefServer = new EditTextPreference(ctx);
            mPrefServer.setKey("outbound_server");
            mPrefServer.setTitle("Server Address / IP");
            mPrefServer.getEditText().setSingleLine(true);
            mPrefServer.getEditText().setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            mPrefServer.setPersistent(false);
            mPrefServer.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefServer);

            mPrefPort = new EditTextPreference(ctx);
            mPrefPort.setKey("outbound_port");
            mPrefPort.setTitle("Server Port");
            mPrefPort.getEditText().setSingleLine(true);
            mPrefPort.getEditText().setInputType(InputType.TYPE_CLASS_NUMBER);
            mPrefPort.setPersistent(false);
            mPrefPort.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefPort);

            mPrefSsMethod = new ListPreference(ctx);
            mPrefSsMethod.setKey("ss_cipher_method");
            mPrefSsMethod.setTitle("Encryption Method");
            mPrefSsMethod.setEntries(new CharSequence[]{"aes-256-gcm", "aes-128-gcm", "chacha20-ietf-poly1305"});
            mPrefSsMethod.setEntryValues(new CharSequence[]{"aes-256-gcm", "aes-128-gcm", "chacha20-ietf-poly1305"});
            mPrefSsMethod.setPersistent(false);
            mPrefSsMethod.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefSsMethod);

            mPrefUsername = new EditTextPreference(ctx);
            mPrefUsername.setKey("outbound_username");
            mPrefUsername.setTitle("Username");
            mPrefUsername.getEditText().setSingleLine(true);
            mPrefUsername.setPersistent(false);
            mPrefUsername.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefUsername);

            mPrefPassword = new EditTextPreference(ctx);
            mPrefPassword.setKey("outbound_password");
            mPrefPassword.setTitle("Password / UUID");
            mPrefPassword.getEditText().setSingleLine(true);
            mPrefPassword.getEditText().setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            mPrefPassword.setPersistent(false);
            mPrefPassword.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefPassword);

            mPrefVlessTls = new CheckBoxPreference(ctx);
            mPrefVlessTls.setKey("vless_tls_enabled");
            mPrefVlessTls.setTitle("Enable TLS");
            mPrefVlessTls.setSummary("Encrypt transport with TLS");
            mPrefVlessTls.setPersistent(false);
            mPrefVlessTls.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefVlessTls);

            mPrefVlessSni = new EditTextPreference(ctx);
            mPrefVlessSni.setKey("vless_sni");
            mPrefVlessSni.setTitle("SNI (Server Name)");
            mPrefVlessSni.getEditText().setSingleLine(true);
            mPrefVlessSni.getEditText().setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            mPrefVlessSni.setPersistent(false);
            mPrefVlessSni.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefVlessSni);

            mPrefVlessWsPath = new EditTextPreference(ctx);
            mPrefVlessWsPath.setKey("vless_ws_path");
            mPrefVlessWsPath.setTitle("WebSocket Path");
            mPrefVlessWsPath.getEditText().setSingleLine(true);
            mPrefVlessWsPath.setPersistent(false);
            mPrefVlessWsPath.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefVlessWsPath);

            mPrefChainFragment = new CheckBoxPreference(ctx);
            mPrefChainFragment.setKey("chain_fragment_enabled");
            mPrefChainFragment.setTitle("Use Fragment (TLS Record + TCP OOB)");
            mPrefChainFragment.setSummary("Off = Independent protocol · On = Route through ByeDPI fragment");
            mPrefChainFragment.setPersistent(false);
            mPrefChainFragment.setOnPreferenceChangeListener(this);
            mProtoCategory.addPreference(mPrefChainFragment);
        }

        mTlsCategory = (PreferenceCategory) findPreference("tls_fragment_category");
        mDnsCategory = (PreferenceCategory) findPreference("dns_override_category");
        mPrefTlsCount = (ListPreference) findPreference("tlsrec_count");
        mPrefTlsPositions = (EditTextPreference) findPreference("tlsrec_positions");
        mPrefDesyncMode = findPreference("desync_mode");
        mPrefFakeTtl = (ListPreference) findPreference("fake_ttl");
        mPrefDnsHosts = findPreference("dns_host_overrides");
        if (mPrefTlsCount != null) mPrefTlsCount.setPersistent(false);
        if (mPrefTlsPositions != null) mPrefTlsPositions.setPersistent(false);
        if (mPrefFakeTtl != null) mPrefFakeTtl.setPersistent(false);
        if (mPrefDnsHosts != null) mPrefDnsHosts.setPersistent(false);

        if (mPrefProfile != null) mPrefProfile.setOnPreferenceChangeListener(this);
        if (mPrefAppList != null) mPrefAppList.setOnPreferenceClickListener(this);
        if (mPrefTlsCount != null) mPrefTlsCount.setOnPreferenceChangeListener(this);
        if (mPrefTlsPositions != null) mPrefTlsPositions.setOnPreferenceChangeListener(this);
        if (mPrefFakeTtl != null) mPrefFakeTtl.setOnPreferenceChangeListener(this);
        if (mPrefDnsHosts != null) mPrefDnsHosts.setOnPreferenceClickListener(this);
    }

    private void reload() {
        if (mProfile == null) mProfile = mManager.getDefault();
        if (mProfile == null) return;
        mProfile.setAutoConnect(true);
        syncBypassStateWithAppList();
        if (mPrefProfile != null) {
            mPrefProfile.setEntries(mManager.getProfiles());
            mPrefProfile.setEntryValues(mManager.getProfiles());
            mPrefProfile.setValue(mProfile.getName());
            resetList(mPrefProfile);
        }

        String proto = mProfile.getProtocol();
        if (mPrefProtocol != null) {
            mPrefProtocol.setValue(proto);
            resetList(mPrefProtocol);
        }
        if (mPrefServer != null) {
            mPrefServer.setText(mProfile.getServer());
            mPrefServer.setSummary(mProfile.getServer().isEmpty() ? "Not set" : mProfile.getServer());
        }
        if (mPrefPort != null) {
            mPrefPort.setText(Integer.toString(mProfile.getPort()));
            mPrefPort.setSummary(Integer.toString(mProfile.getPort()));
        }
        if (mPrefSsMethod != null) {
            String method = mProfile.getUsername().isEmpty() ? "aes-256-gcm" : mProfile.getUsername();
            mPrefSsMethod.setValue(method);
            mPrefSsMethod.setSummary(method);
        }
        if (mPrefUsername != null) {
            mPrefUsername.setText(mProfile.getUsername());
            mPrefUsername.setSummary(mProfile.getUsername().isEmpty() ? "Optional" : mProfile.getUsername());
        }
        if (mPrefPassword != null) {
            mPrefPassword.setText(mProfile.getPassword());
            updatePasswordSummary();
        }
        if (mPrefVlessTls != null) mPrefVlessTls.setChecked(mProfile.isVlessTls());
        if (mPrefVlessSni != null) {
            mPrefVlessSni.setText(mProfile.getVlessSni());
            mPrefVlessSni.setSummary(mProfile.getVlessSni().isEmpty() ? "Same as server host" : mProfile.getVlessSni());
        }
        if (mPrefVlessWsPath != null) {
            mPrefVlessWsPath.setText(mProfile.getVlessWsPath());
            mPrefVlessWsPath.setSummary(mProfile.getVlessWsPath().isEmpty() ? "Empty (Raw TCP mode)" : mProfile.getVlessWsPath());
        }
        if (mPrefChainFragment != null) {
            mPrefChainFragment.setChecked(mProfile.isChainFragmentEnabled());
        }

        if (mPrefAppList != null) mPrefAppList.setSummary(selectedAppsSummary());
        if (mPrefTlsPositions != null) mPrefTlsPositions.setText(mProfile.getTlsRecordPositions());
        int recordCount = net.typeblog.socks.util.ByeDpiSettings.recordCount(mProfile.getTlsRecordPositions());
        if (mPrefTlsCount != null) {
            mPrefTlsCount.setValue(Integer.toString(Math.min(16, Math.max(1, recordCount))));
            resetList(mPrefTlsCount);
        }
        if (mPrefDesyncMode != null) {
            mPrefDesyncMode.setSelectable(false);
        }
        if (mPrefFakeTtl != null) {
            mPrefFakeTtl.setEnabled(false);
            int fakeTtl = mProfile.getFakeTtl();
            mPrefFakeTtl.setValue(Integer.toString(fakeTtl));
            mPrefFakeTtl.setSummary("TTL = " + fakeTtl);
        }
        updateTlsSummary();
        updateDesyncSummary();
        updateDnsHostsSummary();
        updateProtocolVisibility();
    }

    private void updatePasswordSummary() {
        if (mPrefPassword == null || mProfile == null) return;
        String proto = mProfile.getProtocol();
        String pass = mProfile.getPassword();
        if (UniversalProxyRelay.PROTO_VLESS.equals(proto)) {
            mPrefPassword.setTitle("VLESS UUID");
            mPrefPassword.setSummary(pass.isEmpty() ? "Required (e.g. xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)" : pass);
        } else if (UniversalProxyRelay.PROTO_SHADOWSOCKS.equals(proto)) {
            mPrefPassword.setTitle("Password");
            mPrefPassword.setSummary(pass.isEmpty() ? "Required" : "********");
        } else {
            mPrefPassword.setTitle("Password");
            mPrefPassword.setSummary(pass.isEmpty() ? "Optional" : "********");
        }
    }

    private void updateProtocolVisibility() {
        if (mProfile == null || mProtoCategory == null) return;
        String proto = mProfile.getProtocol();
        boolean isByeDpi = UniversalProxyRelay.PROTO_BYEDPI.equals(proto);
        boolean isSs = UniversalProxyRelay.PROTO_SHADOWSOCKS.equals(proto);
        boolean isVless = UniversalProxyRelay.PROTO_VLESS.equals(proto);
        boolean isUserPass = UniversalProxyRelay.PROTO_SOCKS5.equals(proto) || UniversalProxyRelay.PROTO_HTTP.equals(proto);

        togglePref(mProtoCategory, mPrefImportUri, !isByeDpi);
        togglePref(mProtoCategory, mPrefServer, !isByeDpi);
        togglePref(mProtoCategory, mPrefPort, !isByeDpi);
        togglePref(mProtoCategory, mPrefSsMethod, isSs);
        togglePref(mProtoCategory, mPrefUsername, isUserPass);
        togglePref(mProtoCategory, mPrefPassword, !isByeDpi);
        togglePref(mProtoCategory, mPrefVlessTls, isVless);
        togglePref(mProtoCategory, mPrefVlessSni, isVless && mProfile.isVlessTls());
        togglePref(mProtoCategory, mPrefVlessWsPath, isVless);
        togglePref(mProtoCategory, mPrefChainFragment, !isByeDpi);

        boolean fragmentActive = isByeDpi || mProfile.isChainFragmentEnabled();
        if (mTlsCategory != null) {
            mTlsCategory.setEnabled(fragmentActive);
            mTlsCategory.setTitle(fragmentActive
                    ? "TLS Record + TCP OOB (Active)"
                    : "TLS Record + TCP OOB (Disabled for this protocol)");
        }

        if (mScreen != null && mTlsCategory != null && mTlsCategory.getParent() == null) mScreen.addPreference(mTlsCategory);
        if (mScreen != null && mDnsCategory != null && mDnsCategory.getParent() == null) mScreen.addPreference(mDnsCategory);
        if (mProtoCategory != null) mProtoCategory.setOrder(1);
        if (mTlsCategory != null) mTlsCategory.setOrder(2);
        if (mDnsCategory != null) mDnsCategory.setOrder(3);
        if (mAdvancedCategory != null) mAdvancedCategory.setOrder(4);
    }

    private void togglePref(PreferenceCategory cat, Preference pref, boolean show) {
        if (cat == null || pref == null) return;
        if (show) {
            if (pref.getParent() == null) cat.addPreference(pref);
        } else {
            if (pref.getParent() != null) cat.removePreference(pref);
        }
    }

    private void showUriImportDialog() {
        if (getActivity() == null) return;
        final EditText input = new EditText(getActivity());
        input.setHint("vless://... | ss://... | socks5://... | http://...");
        new AlertDialog.Builder(getActivity())
                .setTitle("Import Proxy URI")
                .setView(input)
                .setPositiveButton("Import", (d, w) -> {
                    String raw = input.getText().toString().trim();
                    if (importProxyUri(raw)) {
                        reload();
                        Toast.makeText(getActivity(), "Imported successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getActivity(), "Invalid or unsupported URI", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private boolean importProxyUri(String raw) {
        if (TextUtils.isEmpty(raw)) return false;
        try {
            if (raw.startsWith("vless://")) {
                Uri uri = Uri.parse(raw);
                String uuid = uri.getUserInfo();
                String host = uri.getHost();
                int port = uri.getPort() > 0 ? uri.getPort() : 443;
                if (TextUtils.isEmpty(uuid) || TextUtils.isEmpty(host)) return false;
                String sec = uri.getQueryParameter("security");
                String sni = uri.getQueryParameter("sni");
                String type = uri.getQueryParameter("type");
                String path = uri.getQueryParameter("path");
                mProfile.setProtocol(UniversalProxyRelay.PROTO_VLESS);
                mProfile.setServer(host);
                mProfile.setPort(port);
                mProfile.setPassword(uuid);
                mProfile.setVlessTls("tls".equalsIgnoreCase(sec));
                mProfile.setVlessSni(sni != null ? sni : "");
                mProfile.setVlessWsPath("ws".equalsIgnoreCase(type) ? (path != null ? URLDecoder.decode(path, "UTF-8") : "/") : "");
                mProfile.setChainFragmentEnabled(false);
                return true;
            } else if (raw.startsWith("ss://")) {
                String body = raw.substring(5);
                int hash = body.indexOf('#');
                if (hash >= 0) body = body.substring(0, hash);
                int at = body.indexOf('@');
                String methodPass;
                String hostPort;
                if (at >= 0) {
                    String b64 = body.substring(0, at);
                    methodPass = new String(Base64.decode(b64, Base64.URL_SAFE | Base64.NO_WRAP), StandardCharsets.UTF_8);
                    hostPort = body.substring(at + 1);
                } else {
                    String decoded = new String(Base64.decode(body, Base64.URL_SAFE | Base64.NO_WRAP), StandardCharsets.UTF_8);
                    int at2 = decoded.indexOf('@');
                    if (at2 < 0) return false;
                    methodPass = decoded.substring(0, at2);
                    hostPort = decoded.substring(at2 + 1);
                }
                int colon1 = methodPass.indexOf(':');
                int colon2 = hostPort.lastIndexOf(':');
                if (colon1 <= 0 || colon2 <= 0) return false;
                mProfile.setProtocol(UniversalProxyRelay.PROTO_SHADOWSOCKS);
                mProfile.setUsername(methodPass.substring(0, colon1));
                mProfile.setPassword(methodPass.substring(colon1 + 1));
                mProfile.setServer(hostPort.substring(0, colon2));
                mProfile.setPort(Integer.parseInt(hostPort.substring(colon2 + 1)));
                mProfile.setChainFragmentEnabled(false);
                return true;
            } else if (raw.startsWith("socks5://") || raw.startsWith("socks://") || raw.startsWith("http://")) {
                boolean isHttp = raw.startsWith("http://");
                Uri uri = Uri.parse(raw);
                String host = uri.getHost();
                int port = uri.getPort() > 0 ? uri.getPort() : (isHttp ? 8080 : 1080);
                if (TextUtils.isEmpty(host)) return false;
                mProfile.setProtocol(isHttp ? UniversalProxyRelay.PROTO_HTTP : UniversalProxyRelay.PROTO_SOCKS5);
                mProfile.setServer(host);
                mProfile.setPort(port);
                String userInfo = uri.getUserInfo();
                if (!TextUtils.isEmpty(userInfo)) {
                    int idx = userInfo.indexOf(':');
                    if (idx >= 0) {
                        mProfile.setUsername(userInfo.substring(0, idx));
                        mProfile.setPassword(userInfo.substring(idx + 1));
                    } else {
                        mProfile.setUsername(userInfo);
                        mProfile.setPassword("");
                    }
                } else {
                    mProfile.setUsername("");
                    mProfile.setPassword("");
                }
                mProfile.setChainFragmentEnabled(false);
                return true;
            }
        } catch (Exception ignored) { }
        return false;
    }

    private void runPingTest() {
        if (mPinging || mPrefPingTest == null || getActivity() == null) return;
        if (!mRunning) {
            mPrefPingTest.setSummary("VPN is off — turn on connection first");
            Toast.makeText(getActivity(), "Turn on VPN first", Toast.LENGTH_SHORT).show();
            return;
        }
        mPinging = true;
        mPrefPingTest.setSummary("Testing HTTPS delay (Google & X)...");
        new Thread(() -> {
            String googleResult = probeHttpsDelay("https://www.google.com/generate_204");
            String xResult = probeHttpsDelay("https://x.com");
            final String summary = "Google: " + googleResult + "  ·  X: " + xResult;
            mStopHandler.post(() -> {
                mPinging = false;
                if (mPrefPingTest != null && getActivity() != null) {
                    mPrefPingTest.setSummary(summary);
                }
            });
        }, "FragoPingTest").start();
    }

    private String probeHttpsDelay(String targetUrl) {
        HttpURLConnection conn = null;
        long start = SystemClock.elapsedRealtime();
        try {
            URL url = new URL(targetUrl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("HEAD");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.setInstanceFollowRedirects(false);
            conn.setUseCaches(false);
            conn.setRequestProperty("Connection", "close");
            int code = conn.getResponseCode();
            long elapsed = SystemClock.elapsedRealtime() - start;
            if (code >= 200 && code < 400) {
                return elapsed + " ms";
            }
            return "HTTP " + code + " (" + elapsed + " ms)";
        } catch (Exception e) {
            return "Timeout / Failed";
        } finally {
            if (conn != null) {
                try { conn.disconnect(); } catch (Exception ignored) { }
            }
        }
    }

    private void syncBypassStateWithAppList() {
        if (mProfile == null) return;
        boolean hasApps = !mProfile.getAppList().trim().isEmpty();
        mProfile.setIsPerApp(hasApps);
        mProfile.setIsBypassApp(hasApps);
    }

    private void updateDesyncSummary() {
        if (mProfile == null || mPrefDesyncMode == null) return;
        int records = net.typeblog.socks.util.ByeDpiSettings.recordCount(mProfile.getTlsRecordPositions());
        mPrefDesyncMode.setSummary("TLS Record + TCP OOB · TLS Split: " + records);
    }

    private void updateTlsSummary() {
        if (mProfile == null || mPrefTlsCount == null || mPrefTlsPositions == null) return;
        String positions = mProfile.getTlsRecordPositions();
        int records = net.typeblog.socks.util.ByeDpiSettings.recordCount(positions);
        mPrefTlsCount.setSummary(records <= 1
                ? "TLS record fragmentation is disabled"
                : records + " TLS records will be used");
        mPrefTlsPositions.setSummary(net.typeblog.socks.util.ByeDpiSettings.positionsSummary(positions));
    }

    private void updateDnsHostsSummary() {
        if (mProfile == null || mPrefDnsHosts == null) return;
        String rules = mProfile.getDnsHostOverrides();
        int count = 0;
        for (String line : rules.split("\n")) {
            if (!line.trim().isEmpty() && !line.trim().startsWith("#")) count++;
        }
        mPrefDnsHosts.setSummary(count == 0 ? getString(R.string.dns_host_empty)
                : count + " service mapping(s) · Tap to manage");
    }

    private void showDnsHostEditor() {
        if (getActivity() == null || mProfile == null) return;
        final Activity activity = getActivity();
        final int pad = (int) (16 * activity.getResources().getDisplayMetrics().density + 0.5f);
        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad / 2, pad, 0);

        TextView help = new TextView(activity);
        help.setText(R.string.dns_host_editor_help);
        root.addView(help, new LinearLayout.LayoutParams(-1, -2));

        TextView domainLabel = new TextView(activity);
        domainLabel.setText(R.string.dns_host_domain_label);
        domainLabel.setPadding(0, pad, 0, pad / 3);
        root.addView(domainLabel);
        final EditText domain = new EditText(activity);
        domain.setSingleLine(true);
        domain.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        domain.setHint(R.string.dns_host_domain_hint);
        root.addView(domain, new LinearLayout.LayoutParams(-1, -2));

        TextView ip1Label = new TextView(activity);
        ip1Label.setText(R.string.dns_host_ip1_label);
        ip1Label.setPadding(0, pad / 2, 0, pad / 3);
        root.addView(ip1Label);
        final EditText ip1 = new EditText(activity);
        ip1.setSingleLine(true);
        ip1.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        ip1.setHint("104.244.42.1,151.101.1.195");
        root.addView(ip1, new LinearLayout.LayoutParams(-1, -2));

        TextView ip2Label = new TextView(activity);
        ip2Label.setText(R.string.dns_host_ip2_label);
        ip2Label.setPadding(0, pad / 2, 0, pad / 3);
        root.addView(ip2Label);
        final EditText ip2 = new EditText(activity);
        ip2.setSingleLine(true);
        ip2.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        ip2.setHint("104.244.42.65,151.101.65.195");
        root.addView(ip2, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout presetRow = new LinearLayout(activity);
        presetRow.setOrientation(LinearLayout.HORIZONTAL);
        Button presetX = new Button(activity);
        presetX.setText("X / Twitter");
        presetX.setAllCaps(false);
        presetX.setOnClickListener(v -> {
            domain.setText("regexp:(x\\.com|twitter\\.com|twimg\\.com|t\\.co)");
            ip1.setText("104.244.42.1,104.244.42.65");
            ip2.setText("151.101.1.195,151.101.65.195");
        });
        Button presetGemini = new Button(activity);
        presetGemini.setText("Gemini");
        presetGemini.setAllCaps(false);
        presetGemini.setOnClickListener(v -> {
            domain.setText("regexp:(google)");
            ip1.setText("65.109.184.128");
            ip2.setText("91.107.241.144");
        });
        presetRow.addView(presetX, new LinearLayout.LayoutParams(0, -2, 1f));
        presetRow.addView(presetGemini, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(presetRow, new LinearLayout.LayoutParams(-1, -2));

        Button addUpdate = new Button(activity);
        addUpdate.setText(R.string.dns_host_add_update);
        root.addView(addUpdate, new LinearLayout.LayoutParams(-1, -2));

        TextView savedLabel = new TextView(activity);
        savedLabel.setText(R.string.dns_host_existing);
        savedLabel.setPadding(0, pad, 0, pad / 3);
        root.addView(savedLabel);

        LinearLayout rulesContainer = new LinearLayout(activity);
        rulesContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(rulesContainer, new LinearLayout.LayoutParams(-1, -2));

        ScrollView dialogScroll = new ScrollView(activity);
        dialogScroll.setFillViewport(true);
        dialogScroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        final AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(R.string.dns_host_editor_title)
                .setView(dialogScroll)
                .setPositiveButton(android.R.string.ok, null)
                .create();

        final Runnable[] refreshRules = new Runnable[1];
        refreshRules[0] = new Runnable() {
            @Override public void run() {
                rulesContainer.removeAllViews();
                String raw = mProfile.getDnsHostOverrides();
                String[] lines = raw.split("\n");
                boolean hasRules = false;
                for (final String line : lines) {
                    final String value = line.trim();
                    if (value.isEmpty() || value.startsWith("#")) continue;
                    int eq = value.indexOf('=');
                    if (eq <= 0) continue;
                    hasRules = true;
                    final String host = value.substring(0, eq).trim();
                    final String[] ips = value.substring(eq + 1).split(",");
                    LinearLayout row = new LinearLayout(activity);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setPadding(0, pad / 4, 0, pad / 4);
                    TextView select = new TextView(activity);
                    select.setText(host + "  →  " + value.substring(eq + 1).trim());
                    select.setTextIsSelectable(false);
                    select.setPadding(pad / 2, pad / 2, pad / 2, pad / 2);
                    select.setOnClickListener(v -> {
                        domain.setText(host);
                        if (ips.length <= 2) {
                            ip1.setText(ips.length > 0 ? ips[0].trim() : "");
                            ip2.setText(ips.length > 1 ? ips[1].trim() : "");
                        } else {
                            int mid = (ips.length + 1) / 2;
                            StringBuilder p1 = new StringBuilder();
                            StringBuilder p2 = new StringBuilder();
                            for (int idx = 0; idx < ips.length; idx++) {
                                String cleanIp = ips[idx].trim();
                                if (idx < mid) {
                                    if (p1.length() > 0) p1.append(',');
                                    p1.append(cleanIp);
                                } else {
                                    if (p2.length() > 0) p2.append(',');
                                    p2.append(cleanIp);
                                }
                            }
                            ip1.setText(p1.toString());
                            ip2.setText(p2.toString());
                        }
                    });
                    row.addView(select, new LinearLayout.LayoutParams(0, -2, 1f));
                    Button remove = new Button(activity);
                    remove.setText(R.string.dns_host_remove);
                    remove.setAllCaps(false);
                    remove.setOnClickListener(v -> {
                        StringBuilder updated = new StringBuilder();
                        for (String candidate : mProfile.getDnsHostOverrides().split("\n")) {
                            if (candidate.trim().isEmpty()) continue;
                            int split = candidate.indexOf('=');
                            String candidateHost = split > 0 ? candidate.substring(0, split).trim() : "";
                            if (!candidateHost.equalsIgnoreCase(host)) {
                                if (updated.length() > 0) updated.append('\n');
                                updated.append(candidate.trim());
                            }
                        }
                        try {
                            mProfile.setDnsHostOverrides(net.typeblog.socks.util.DnsHostOverrides.normalizeEditorText(updated.toString()));
                            updateDnsHostsSummary();
                            refreshRules[0].run();
                        } catch (IllegalArgumentException error) {
                            Toast.makeText(activity, error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                    row.addView(remove, new LinearLayout.LayoutParams(-2, -2));
                    rulesContainer.addView(row, new LinearLayout.LayoutParams(-1, -2));
                }
                if (!hasRules) {
                    TextView empty = new TextView(activity);
                    empty.setText(R.string.dns_host_empty);
                    rulesContainer.addView(empty);
                }
            }
        };

        addUpdate.setOnClickListener(v -> {
            String host = domain.getText().toString().trim();
            String first = ip1.getText().toString().trim();
            String second = ip2.getText().toString().trim();
            if (host.isEmpty() || first.isEmpty()) {
                Toast.makeText(activity, R.string.dns_host_invalid, Toast.LENGTH_LONG).show();
                return;
            }
            String mapping = host + "=" + first + (second.isEmpty() ? "" : "," + second);
            StringBuilder updated = new StringBuilder();
            boolean replaced = false;
            for (String candidate : mProfile.getDnsHostOverrides().split("\n")) {
                String value = candidate.trim();
                if (value.isEmpty()) continue;
                int eq = value.indexOf('=');
                String candidateHost = eq > 0 ? value.substring(0, eq).trim() : "";
                if (candidateHost.equalsIgnoreCase(host)) {
                    if (!replaced) {
                        if (updated.length() > 0) updated.append('\n');
                        updated.append(mapping);
                        replaced = true;
                    }
                } else {
                    if (updated.length() > 0) updated.append('\n');
                    updated.append(value);
                }
            }
            if (!replaced) {
                if (updated.length() > 0) updated.append('\n');
                updated.append(mapping);
            }
            try {
                String normalized = net.typeblog.socks.util.DnsHostOverrides.normalizeEditorText(updated.toString());
                mProfile.setDnsHostOverrides(normalized);
                updateDnsHostsSummary();
                domain.setText("");
                ip1.setText("");
                ip2.setText("");
                refreshRules[0].run();
                Toast.makeText(activity, R.string.dns_host_saved, Toast.LENGTH_SHORT).show();
            } catch (IllegalArgumentException error) {
                Toast.makeText(activity, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        dialog.setOnShowListener(ignored -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> dialog.dismiss());
            refreshRules[0].run();
        });
        dialog.show();
    }

    private String selectedAppsSummary() {
        String raw = mProfile == null ? "" : mProfile.getAppList();
        if (raw.trim().isEmpty()) return "All apps go through VPN (Tap to exclude apps)";
        String[] packages = raw.split("\\n");
        PackageManager pm = getActivity().getPackageManager();
        java.util.ArrayList<String> names = new java.util.ArrayList<>();
        for (String pkg : packages) try { names.add(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()); } catch (Exception ignored) { }
        return names.isEmpty() ? "All apps go through VPN (Tap to exclude apps)" : "Bypassed: " + android.text.TextUtils.join(", ", names);
    }

    private void showAppPicker() {
        final PackageManager pm = getActivity().getPackageManager();
        final java.util.LinkedHashMap<String, ApplicationInfo> userApps = new java.util.LinkedHashMap<>();
        Intent launchIntent = new Intent(Intent.ACTION_MAIN);
        launchIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        java.util.List<ResolveInfo> launchables = pm.queryIntentActivities(launchIntent, 0);
        for (ResolveInfo resolve : launchables) {
            ActivityInfo activity = resolve.activityInfo;
            if (activity == null || activity.applicationInfo == null) continue;
            ApplicationInfo app = activity.applicationInfo;
            if (app.packageName.equals(getActivity().getPackageName())) continue;
            userApps.put(app.packageName, app);
        }

        final java.util.ArrayList<ApplicationInfo> apps = new java.util.ArrayList<>(userApps.values());
        java.util.Collections.sort(apps, (a,b) -> pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString()));
        final java.util.ArrayList<String> labels = new java.util.ArrayList<>();
        final java.util.ArrayList<String> packages = new java.util.ArrayList<>();
        for (ApplicationInfo app : apps) {
            labels.add(pm.getApplicationLabel(app).toString());
            packages.add(app.packageName);
        }
        if (packages.isEmpty()) {
            Toast.makeText(getActivity(), "No launcher apps found", Toast.LENGTH_SHORT).show();
            return;
        }
        final java.util.Set<String> selected = new java.util.HashSet<>();
        String current = mProfile.getAppList();
        if (!current.trim().isEmpty()) selected.addAll(java.util.Arrays.asList(current.split("\\n")));
        final boolean[] checked = new boolean[packages.size()];
        for (int i=0;i<packages.size();i++) checked[i] = selected.contains(packages.get(i));
        new AlertDialog.Builder(getActivity()).setTitle("Select Apps to Bypass VPN")
                .setMultiChoiceItems(labels.toArray(new String[0]), checked, (dialog, which, isChecked) -> {
                    if (isChecked) selected.add(packages.get(which)); else selected.remove(packages.get(which));
                })
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    java.util.ArrayList<String> result = new java.util.ArrayList<>();
                    for (String pkg : packages) if (selected.contains(pkg)) result.add(pkg);
                    mProfile.setAppList(android.text.TextUtils.join("\n", result));
                    syncBypassStateWithAppList();
                    mPrefAppList.setSummary(selectedAppsSummary());
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void resetList(ListPreference... pref) {
        for (ListPreference p : pref)
            p.setSummary(p.getEntry());
    }

    private void addProfile() {
        final EditText e = new EditText(getActivity());
        e.setSingleLine(true);

        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.prof_add)
                .setView(e)
                .setPositiveButton(android.R.string.ok, (d, which) -> {
                    String name = e.getText().toString().trim();
                    if (!TextUtils.isEmpty(name)) {
                        Profile p = mManager.addProfile(name);
                        if (p != null) {
                            mProfile = p;
                            reload();
                            return;
                        }
                    }
                    Toast.makeText(getActivity(),
                            String.format(getString(R.string.err_add_prof), name),
                            Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .create().show();
    }

    private void renameProfile() {
        final EditText input = new EditText(getActivity());
        input.setSingleLine(true);
        input.setText(mProfile.getName());
        new AlertDialog.Builder(getActivity()).setTitle(R.string.prof_rename).setView(input)
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    String newName = input.getText().toString().trim();
                    if (mManager.renameProfile(mProfile.getName(), newName)) {
                        mProfile = mManager.getProfile(newName);
                        reload();
                        Toast.makeText(getActivity(), "Profile renamed", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getActivity(), "Invalid or duplicate profile name", Toast.LENGTH_LONG).show();
                    }
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void removeProfile() {
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.prof_del)
                .setMessage(String.format(getString(R.string.prof_del_confirm), mProfile.getName()))
                .setPositiveButton(android.R.string.ok, (d, which) -> {
                    if (!mManager.removeProfile(mProfile.getName())) {
                        Toast.makeText(getActivity(),
                                getString(R.string.err_del_prof, mProfile.getName()),
                                Toast.LENGTH_SHORT).show();
                    } else {
                        mProfile = mManager.getDefault();
                        reload();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .create().show();
    }

    private boolean mBound = false;
    private boolean mReceiverRegistered = false;
    private final BroadcastReceiver mStateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            mStopHandler.removeCallbacks(mStopTimeout);
            mRunning = intent.getBooleanExtra("running", false);
            mStarting = false;
            String error = intent.getStringExtra("error");
            updateState();
            if (!TextUtils.isEmpty(error) && getActivity() != null) {
                Toast.makeText(getActivity(), error, Toast.LENGTH_LONG).show();
            }
        }
    };

    private void checkState() {
        if (mSwitch == null || getActivity() == null) return;
        mSwitch.setEnabled(true);
        mSwitch.setOnCheckedChangeListener(this);

        if (mBound && mBinder != null) {
            try {
                mRunning = mBinder.isRunning();
            } catch (Exception ignored) {
                mRunning = false;
            }
            if (mStarting && !mRunning) {
                keepSwitchOnWhileStarting();
            } else {
                updateState();
            }
            return;
        }

        if (!mBound) {
            try {
                mBound = getActivity().bindService(
                        new Intent(getActivity(), SocksVpnService.class),
                        mConnection,
                        Context.BIND_AUTO_CREATE
                );
            } catch (Exception ignored) {
                mBound = false;
            }
        }
    }

    private void keepSwitchOnWhileStarting() {
        if (mSwitch == null) return;
        mSwitch.setOnCheckedChangeListener(null);
        mSwitch.setChecked(true);
        mSwitch.setEnabled(true);
        mSwitch.setOnCheckedChangeListener(ProfileFragment.this);
    }

    private void updateState() {
        if (mSwitch == null) return;
        mStopHandler.removeCallbacks(mStopTimeout);
        mSwitch.setOnCheckedChangeListener(null);
        mSwitch.setChecked(mRunning);
        mSwitch.setEnabled(true);
        mStarting = false;
        mStopping = false;
        mSwitch.setOnCheckedChangeListener(ProfileFragment.this);
    }

    private void startVpn() {
        try {
            net.typeblog.socks.util.ByeDpiSettings.fromSettings(
                    mProfile.getTlsRecordPositions(), mProfile.getDesyncMode(), false, "", mProfile.getFakeTtl(),
                    net.typeblog.socks.util.ByeDpiSettings.DEFAULT_SPOOF_CONNECT_IP,
                    net.typeblog.socks.util.ByeDpiSettings.DEFAULT_HANDSHAKE_TIMEOUT_MS,
                    true, mProfile.getDnsHostOverrides());
        } catch (IllegalArgumentException e) {
            Toast.makeText(getActivity(), R.string.fragment_config_invalid, Toast.LENGTH_LONG).show();
            resetMainSwitch();
            return;
        }
        if (!UniversalProxyRelay.PROTO_BYEDPI.equals(mProfile.getProtocol())
                && TextUtils.isEmpty(mProfile.getServer())) {
            Toast.makeText(getActivity(), "Please set Server Address first", Toast.LENGTH_LONG).show();
            resetMainSwitch();
            return;
        }
        syncBypassStateWithAppList();
        mStarting = true;
        Intent i = VpnService.prepare(getActivity());
        if (i != null) startActivityForResult(i, 0);
        else onActivityResult(0, Activity.RESULT_OK, null);
    }

    private void resetMainSwitch() {
        mStarting = false;
        if (mSwitch != null) {
            mSwitch.setOnCheckedChangeListener(null);
            mSwitch.setChecked(false);
            mSwitch.setEnabled(true);
            mSwitch.setOnCheckedChangeListener(this);
        }
    }

    private void stopVpn() {
        mStopping = true;
        mStopHandler.removeCallbacks(mStopTimeout);
        if (getActivity() != null) {
            try {
                Intent stop = new Intent(getActivity(), SocksVpnService.class)
                        .setAction(SocksVpnService.ACTION_STOP);
                getActivity().startService(stop);
            } catch (Exception ignored) {
                try { getActivity().stopService(new Intent(getActivity(), SocksVpnService.class)); }
                catch (Exception ignoredAgain) { }
            }
        }

        mBinder = null;
        mRunning = false;
        if (mSwitch != null) {
            mSwitch.setOnCheckedChangeListener(null);
            mSwitch.setChecked(false);
            mSwitch.setEnabled(true);
            mSwitch.setOnCheckedChangeListener(this);
        }
        if (mBound && getActivity() != null) {
            try { getActivity().unbindService(mConnection); } catch (Exception ignored) { }
            mBound = false;
        }
        mStopHandler.postDelayed(mStopTimeout, 2500L);
    }
}