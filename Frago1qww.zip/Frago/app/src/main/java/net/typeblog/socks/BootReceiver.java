package net.typeblog.socks;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.UserManager;

import net.typeblog.socks.util.Profile;
import net.typeblog.socks.util.ProfileManager;
import net.typeblog.socks.util.Utility;

public class BootReceiver extends BroadcastReceiver {
    private static volatile boolean startedThisBoot = false;

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        boolean isUpdate = Intent.ACTION_MY_PACKAGE_REPLACED.equals(action);
        if (!Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_USER_UNLOCKED.equals(action)
                && !"android.intent.action.QUICKBOOT_POWERON".equals(action)
                && !isUpdate) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            UserManager um = (UserManager) context.getSystemService(Context.USER_SERVICE);
            if (um != null && !um.isUserUnlocked()) return;
        }

        synchronized (BootReceiver.class) {
            if (!isUpdate && startedThisBoot) return;
            Context appCtx = context.getApplicationContext();
            Profile profile;
            try {
                profile = new ProfileManager(appCtx).getDefault();
            } catch (Exception ignored) {
                return;
            }
            if (profile == null || VpnService.prepare(appCtx) != null) return;
            startedThisBoot = true;
            try {
                Utility.startVpn(appCtx, profile);
            } catch (Exception ignored) {
                startedThisBoot = false;
            }
        }
    }
}