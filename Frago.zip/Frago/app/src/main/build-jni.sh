#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")"
rm -rf jniLibs libs obj
mkdir -p jni/byedpi

if [ ! -f jni/byedpi/main.c ]; then
    git clone --depth 1 --branch v0.17.3 https://github.com/hufrea/byedpi.git jni/byedpi
fi

ndk-build

for abi in armeabi-v7a arm64-v8a x86 x86_64; do
    mv "libs/$abi/tun2socks" "libs/$abi/libtun2socks.so"
    mv "libs/$abi/pdnsd" "libs/$abi/libpdnsd.so"
    mv "libs/$abi/byedpi" "libs/$abi/libbyedpi.so"
done

mv libs jniLibs
