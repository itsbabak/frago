package net.typeblog.socks.util;

import org.json.JSONArray;
import org.json.JSONObject;

final class LegacyProfileMigration {
    private LegacyProfileMigration() { }

    static String tlsPositions(String raw) {
        try {
            JSONObject root = new JSONObject(raw);
            String value = root.optString("tlsrecPositions", "").trim();
            JSONArray positions = root.optJSONArray("tlsrec");
            if (positions != null) {
                StringBuilder out = new StringBuilder();
                for (int i = 0; i < positions.length(); i++) {
                    String item = positions.optString(i, "").trim();
                    if (item.isEmpty()) continue;
                    if (out.length() > 0) out.append('\n');
                    out.append(item);
                }
                if (out.length() > 0) value = out.toString();
            }
            return value.isEmpty() ? ByeDpiSettings.DEFAULT_POSITION : ByeDpiSettings.normalizePositions(value);
        } catch (Exception ignored) {
            return ByeDpiSettings.DEFAULT_POSITION;
        }
    }

    static String hostOverrides(String raw) {
        try {
            JSONObject root = new JSONObject(raw);
            JSONObject dns = root.optJSONObject("dns");
            JSONObject hosts = dns == null ? null : dns.optJSONObject("hosts");
            if (hosts == null) return ByeDpiSettings.DEFAULT_HOSTS;
            StringBuilder out = new StringBuilder();
            java.util.Iterator<String> keys = hosts.keys();
            while (keys.hasNext()) {
                String host = keys.next();
                Object value = hosts.opt(host);
                java.util.ArrayList<String> ips = new java.util.ArrayList<>();
                if (value instanceof JSONArray) {
                    JSONArray values = (JSONArray) value;
                    for (int i = 0; i < values.length(); i++) {
                        String ip = values.optString(i, "").trim();
                        if (isIpv4(ip)) ips.add(ip);
                    }
                } else {
                    String ip = hosts.optString(host, "").trim();
                    if (isIpv4(ip)) ips.add(ip);
                }
                if (ips.isEmpty()) continue;
                if (out.length() > 0) out.append('\n');
                out.append(host).append('=');
                for (int i = 0; i < ips.size(); i++) {
                    if (i > 0) out.append(',');
                    out.append(ips.get(i));
                }
            }
            String converted = DnsHostOverrides.normalizeEditorText(out.toString());
            return converted.trim().isEmpty() ? ByeDpiSettings.DEFAULT_HOSTS : converted;
        } catch (Exception ignored) {
            return ByeDpiSettings.DEFAULT_HOSTS;
        }
    }

    private static boolean isIpv4(String value) {
        if (value == null || !value.matches("[0-9.]+")) return false;
        String[] parts = value.split("\\.", -1);
        if (parts.length != 4) return false;
        for (String part : parts) {
            if (part.isEmpty() || part.length() > 3) return false;
            try {
                int n = Integer.parseInt(part);
                if (n < 0 || n > 255) return false;
            } catch (NumberFormatException error) { return false; }
        }
        return true;
    }
}
