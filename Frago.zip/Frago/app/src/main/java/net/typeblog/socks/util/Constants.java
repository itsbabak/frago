package net.typeblog.socks.util;

public class Constants {
    private static final String INTENT_PREFIX = "SOCKS";
    public static final String INTENT_NAME = INTENT_PREFIX + "NAME",
            INTENT_SERVER = INTENT_PREFIX + "SERV",
            INTENT_PORT = INTENT_PREFIX + "PORT",
            INTENT_USERNAME = INTENT_PREFIX + "UNAME",
            INTENT_PASSWORD = INTENT_PREFIX + "PASSWD",
            INTENT_PER_APP = INTENT_PREFIX + "PERAPP",
            INTENT_APP_BYPASS = INTENT_PREFIX + "APPBYPASS",
            INTENT_APP_LIST = INTENT_PREFIX + "APPLIST",
            INTENT_TLSREC_POSITIONS = INTENT_PREFIX + "TLSRECPOSITIONS",
            INTENT_DESYNC_MODE = INTENT_PREFIX + "DESYNCMODE",
            INTENT_FAKE_SNI = INTENT_PREFIX + "FAKESNI",
            INTENT_FAKE_TTL = INTENT_PREFIX + "FAKETTL",
            INTENT_SPOOF_CONNECT_IP = INTENT_PREFIX + "SPOOFCONNECTIP",
            INTENT_HANDSHAKE_TIMEOUT_MS = INTENT_PREFIX + "HANDSHAKETIMEOUTMS",
            INTENT_FAKE_SNI_ENABLED = INTENT_PREFIX + "FAKESNIENABLED",
            INTENT_BLOCK_QUIC = INTENT_PREFIX + "BLOCKQUIC",
            INTENT_DNS_HOST_OVERRIDES = INTENT_PREFIX + "DNSHOSTOVERRIDES",
            INTENT_PROTOCOL = INTENT_PREFIX + "PROTOCOL";
    public static final String PREF = "profile",
            PREF_PROFILE = "profile",
            PREF_LAST_PROFILE = "last_profile",
            PREF_DEFAULT_PROFILE_NAME = "default_profile_name",
            PREF_SERVER_IP = "server_ip",
            PREF_SERVER_PORT = "server_port",
            PREF_AUTH_USERPW = "auth_userpw",
            PREF_AUTH_USERNAME = "auth_username",
            PREF_AUTH_PASSWORD = "auth_password",
            PREF_ADV_PER_APP = "adv_per_app",
            PREF_ADV_APP_BYPASS = "adv_app_bypass",
            PREF_ADV_APP_LIST = "adv_app_list",
            PREF_ADV_AUTO_CONNECT = "adv_auto_connect",
            PREF_PROTOCOL = "proxy_protocol";
}
