package net.typeblog.socks;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.view.View;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            View content = findViewById(android.R.id.content);
            if (content != null && Build.VERSION.SDK_INT >= 35) {
                content.setOnApplyWindowInsetsListener((view, insets) -> {
                    view.setPadding(insets.getSystemWindowInsetLeft(),
                            insets.getSystemWindowInsetTop(),
                            insets.getSystemWindowInsetRight(),
                            insets.getSystemWindowInsetBottom());
                    return insets;
                });
                content.requestApplyInsets();
            }
            if (savedInstanceState == null && getFragmentManager() != null) {
                getFragmentManager().beginTransaction()
                        .replace(android.R.id.content, new ProfileFragment())
                        .commitAllowingStateLoss();
            }
        } catch (Exception ignored) {
        }
    }
}
