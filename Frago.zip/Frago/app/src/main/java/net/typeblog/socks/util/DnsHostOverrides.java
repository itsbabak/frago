package net.typeblog.socks.util;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Local DNS A-record overrides used before the encrypted DNS upstream. */
public final class DnsHostOverrides {
    private static final int MAX_RULES = 64;
    private static final int MAX_IPS_PER_RULE = 8;

    private static final class Entry {
        final Pattern pattern;
        final boolean regex;
        final int priority; // exact domain, wildcard, then general regexp
        final List<byte[]> addresses = new ArrayList<>();
        Entry(Pattern pattern, boolean regex, int priority) {
            this.pattern = pattern;
            this.regex = regex;
            this.priority = priority;
        }
    }

    private final List<Entry> entries = new ArrayList<>();

    public static DnsHostOverrides fromText(String raw) {
        DnsHostOverrides result = new DnsHostOverrides();
        String normalized = normalizeEditorText(raw);
        if (normalized.isEmpty()) return result;
        for (String line : normalized.split("\\n")) {
            int eq = line.indexOf('=');
            String host = line.substring(0, eq).trim();
            String[] ips = line.substring(eq + 1).split(",");
            try {
                boolean regex = host.startsWith("regexp:");
                int priority;
                String expression;
                if (regex) {
                    expression = host.substring("regexp:".length());
                    priority = 2;
                } else if (host.startsWith("*.")) {
                    expression = "(^|\\.)" + Pattern.quote(host.substring(2)) + "$";
                    regex = true;
                    priority = 1;
                } else {
                    expression = Pattern.quote(host.toLowerCase(Locale.ROOT));
                    priority = 0;
                }
                Entry entry = new Entry(Pattern.compile(expression, Pattern.CASE_INSENSITIVE), regex, priority);
                for (String ip : ips) entry.addresses.add(parseIpv4(ip.trim()));
                if (!entry.addresses.isEmpty()) result.entries.add(entry);
            } catch (Exception ignored) {
                // The editor validates before saving; ignore malformed legacy entries safely.
            }
        }
        return result;
    }

    /** Validate and normalize editor text. One line: domain=IPv4[,IPv4...]. */
    public static String normalizeEditorText(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "";
        StringBuilder out = new StringBuilder();
        LinkedHashSet<String> seenHosts = new LinkedHashSet<>();
        String[] lines = raw.replace('\r', '\n').split("\\n");
        int count = 0;
        for (String rawLine : lines) {
            String line = rawLine.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            int eq = line.indexOf('=');
            if (eq <= 0 || eq == line.length() - 1) {
                throw new IllegalArgumentException("Use domain=IPv4[,IPv4] on each line");
            }
            String host = line.substring(0, eq).trim();
            String values = line.substring(eq + 1).trim();
            validateHost(host);
            String identity = host.toLowerCase(Locale.ROOT);
            if (!seenHosts.add(identity)) throw new IllegalArgumentException("Duplicate host rule: " + host);

            String[] candidates = values.split(",");
            LinkedHashSet<String> ips = new LinkedHashSet<>();
            for (String candidate : candidates) {
                String ip = candidate.trim();
                if (!isIpv4(ip)) throw new IllegalArgumentException("Invalid IPv4 address: " + ip);
                ips.add(ip);
            }
            if (ips.isEmpty() || ips.size() > MAX_IPS_PER_RULE) {
                throw new IllegalArgumentException("Each host needs 1 to " + MAX_IPS_PER_RULE + " IPv4 addresses");
            }
            if (++count > MAX_RULES) throw new IllegalArgumentException("Too many DNS override rules");
            if (out.length() > 0) out.append('\n');
            out.append(host).append('=');
            boolean first = true;
            for (String ip : ips) {
                if (!first) out.append(',');
                out.append(ip);
                first = false;
            }
        }
        return out.toString();
    }

    private static void validateHost(String host) {
        if (host.startsWith("regexp:")) {
            String regex = host.substring("regexp:".length());
            if (regex.isEmpty() || regex.length() > 160) throw new IllegalArgumentException("Invalid host expression");
            try { Pattern.compile(regex, Pattern.CASE_INSENSITIVE); }
            catch (Exception error) { throw new IllegalArgumentException("Invalid host expression: " + regex); }
            return;
        }
        String domain = host.startsWith("*.") ? host.substring(2) : host;
        if (domain.length() > 253 || !domain.matches("(?i)[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?")) {
            throw new IllegalArgumentException("Invalid domain: " + host);
        }
        if (domain.contains("..") || domain.startsWith(".") || domain.endsWith(".")) {
            throw new IllegalArgumentException("Invalid domain: " + host);
        }
    }

    private static boolean isIpv4(String value) {
        if (value == null || !value.matches("[0-9.]+")) return false;
        String[] parts = value.split("\\.", -1);
        if (parts.length != 4) return false;
        for (String part : parts) {
            if (part.isEmpty() || part.length() > 3) return false;
            try {
                int n = Integer.parseInt(part);
                if (n < 0 || n > 255) return false;
            } catch (NumberFormatException error) { return false; }
        }
        return true;
    }

    private static byte[] parseIpv4(String value) throws Exception {
        if (!isIpv4(value)) throw new IllegalArgumentException("IPv4 expected");
        byte[] raw = InetAddress.getByName(value).getAddress();
        if (raw.length != 4) throw new IllegalArgumentException("IPv4 expected");
        return raw;
    }

    /** Returns a synthetic DNS response for matching A queries, otherwise null. */
    public byte[] answer(byte[] query, int length) {
        if (entries.isEmpty() || query == null || length < 17) return null;
        try {
            int qd = ((query[4] & 255) << 8) | (query[5] & 255);
            if (qd != 1 || (query[2] & 0x80) != 0) return null;
            int p = 12;
            StringBuilder name = new StringBuilder();
            while (p < length) {
                int n = query[p++] & 255;
                if (n == 0) break;
                if ((n & 0xc0) != 0 || n > 63 || p + n > length) return null;
                if (name.length() > 0) name.append('.');
                name.append(new String(query, p, n, "US-ASCII"));
                p += n;
            }
            if (p + 4 > length) return null;
            int type = ((query[p] & 255) << 8) | (query[p + 1] & 255);
            int clazz = ((query[p + 2] & 255) << 8) | (query[p + 3] & 255);
            if (type != 1 || clazz != 1) return null;
            String hostname = name.toString().toLowerCase(Locale.ROOT);
            Entry matched = null;
            // A specific domain mapping must override broad rules such as regexp:(google).
            for (int priority = 0; priority <= 2 && matched == null; priority++) {
                for (Entry entry : entries) {
                    if (entry.priority != priority) continue;
                    boolean match = entry.regex
                            ? entry.pattern.matcher(hostname).find()
                            : entry.pattern.matcher(hostname).matches();
                    if (match) { matched = entry; break; }
                }
            }
            if (matched == null) return null;

            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(bytes);
            out.write(query, 0, 2);
            int flags = (((query[2] & 255) << 8) | (query[3] & 255));
            out.writeShort((flags & 0x0100) | 0x8080);
            out.writeShort(1);
            out.writeShort(matched.addresses.size());
            out.writeShort(0);
            out.writeShort(0);
            out.write(query, 12, p + 4 - 12);
            for (byte[] ip : matched.addresses) {
                if (ip.length != 4) continue;
                out.writeShort(0xc00c);
                out.writeShort(1);
                out.writeShort(1);
                out.writeInt(300);
                out.writeShort(4);
                out.write(ip);
            }
            out.flush();
            return bytes.toByteArray();
        } catch (Exception ignored) {
            return null;
        }
    }
}
