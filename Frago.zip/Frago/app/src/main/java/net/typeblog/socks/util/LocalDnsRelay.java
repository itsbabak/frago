package net.typeblog.socks.util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Minimal-overhead local DNS relay with host overrides, short TTL cache,
 * and protected UDP/TCP upstream resolution without DoT/DoH/White DNS overhead.
 */
public final class LocalDnsRelay {
    public interface SocketProtector {
        boolean protect(DatagramSocket socket);
        boolean protectSocket(Socket socket);
    }

    private static final int UDP_TIMEOUT_MS = 1200;
    private static final int TCP_TIMEOUT_MS = 2500;
    private static final int MAX_DNS_PACKET = 4096;
    private static final int DNS_CACHE_MAX_ENTRIES = 256;
    private static final List<String> FALLBACK_DNS = Collections.unmodifiableList(
            Arrays.asList("1.1.1.1", "8.8.8.8"));

    private final DnsHostOverrides hostOverrides;
    private final SocketProtector protector;
    private final int socksPort;
    private volatile List<String> upstreamDns = FALLBACK_DNS;
    private volatile boolean running;
    private DatagramSocket serverSocket;
    private Thread listenerThread;
    private ThreadPoolExecutor pool;
    private final Map<String, CachedDnsAnswer> dnsCache = Collections.synchronizedMap(
            new LinkedHashMap<String, CachedDnsAnswer>(DNS_CACHE_MAX_ENTRIES, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, CachedDnsAnswer> eldest) {
                    return size() > DNS_CACHE_MAX_ENTRIES;
                }
            });

    private static final class CachedDnsAnswer {
        final byte[] packet;
        final long expiresAtNanos;
        CachedDnsAnswer(byte[] packet, long expiresAtNanos) {
            this.packet = packet;
            this.expiresAtNanos = expiresAtNanos;
        }
    }

    public LocalDnsRelay(DnsHostOverrides overrides,
                         List<String> systemDnsServers,
                         SocketProtector protector,
                         int socksPort) {
        this.hostOverrides = overrides;
        this.protector = protector;
        this.socksPort = socksPort;
        updateUpstreamDns(systemDnsServers);
    }

    public void updateUpstreamDns(List<String> systemDnsServers) {
        List<String> list = new ArrayList<>();
        if (systemDnsServers != null) {
            for (String ip : systemDnsServers) {
                if (isValidIpv4(ip) && !ip.startsWith("127.") && !ip.startsWith("26.26.26.") && !list.contains(ip)) {
                    list.add(ip);
                }
            }
        }
        for (String fb : FALLBACK_DNS) {
            if (!list.contains(fb)) list.add(fb);
        }
        this.upstreamDns = Collections.unmodifiableList(list);
        dnsCache.clear();
    }

    public synchronized void start() throws Exception {
        if (running) return;
        serverSocket = new DatagramSocket(null);
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress("127.0.0.1", 5354));
        serverSocket.setSoTimeout(0);

        ThreadPoolExecutor executor = new ThreadPoolExecutor(
                1, 1, 10L, TimeUnit.SECONDS,
                new LinkedBlockingQueue<Runnable>(16),
                new ThreadFactory() {
                    @Override
                    public Thread newThread(Runnable r) {
                        Thread t = new Thread(r, "Frago-DNS-Worker");
                        t.setDaemon(true);
                        t.setPriority(Thread.MIN_PRIORITY);
                        return t;
                    }
                },
                new ThreadPoolExecutor.DiscardOldestPolicy());
        executor.allowCoreThreadTimeOut(true);
        pool = executor;

        running = true;
        listenerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                byte[] buffer = new byte[MAX_DNS_PACKET];
                while (running) {
                    try {
                        DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                        serverSocket.receive(request);
                        final int len = request.getLength();
                        if (len < 12) continue;
                        final byte[] query = new byte[len];
                        System.arraycopy(request.getData(), request.getOffset(), query, 0, len);
                        final InetAddress clientAddr = request.getAddress();
                        final int clientPort = request.getPort();

                        byte[] override = hostOverrides == null ? null : hostOverrides.answer(query, query.length);
                        if (override != null && override.length > 0) {
                            sendReply(override, clientAddr, clientPort);
                            continue;
                        }

                        byte[] cached = getCachedAnswer(query);
                        if (cached != null) {
                            sendReply(cached, clientAddr, clientPort);
                            continue;
                        }

                        ThreadPoolExecutor currentPool = pool;
                        if (currentPool != null && !currentPool.isShutdown()) {
                            currentPool.execute(new Runnable() {
                                @Override
                                public void run() {
                                    byte[] answer = resolveUpstream(query);
                                    if (answer != null && answer.length > 0 && running) {
                                        cacheAnswer(query, answer);
                                        sendReply(answer, clientAddr, clientPort);
                                    }
                                }
                            });
                        }
                    } catch (IOException ignored) {
                        if (!running) break;
                    } catch (Exception ignored) {
                    }
                }
            }
        }, "Frago-DNS-Listener");
        listenerThread.setDaemon(true);
        listenerThread.start();
    }

    private void sendReply(byte[] answer, InetAddress addr, int port) {
        DatagramSocket sock = serverSocket;
        if (sock == null || sock.isClosed()) return;
        try {
            sock.send(new DatagramPacket(answer, answer.length, addr, port));
        } catch (Exception ignored) {
        }
    }

    private byte[] resolveUpstream(byte[] query) {
        List<String> servers = upstreamDns;
        for (int i = 0; i < Math.min(servers.size(), 2); i++) {
            byte[] udpReply = queryUdp(servers.get(i), query);
            if (udpReply != null && !isPoisonedAnswer(udpReply)) return udpReply;
        }
        for (String fb : FALLBACK_DNS) {
            byte[] tcpReply = queryTcpViaSocks(fb, 53, query);
            if (tcpReply != null && !isPoisonedAnswer(tcpReply)) return tcpReply;
        }
        return null;
    }

    private byte[] queryUdp(String serverIp, byte[] query) {
        DatagramSocket sock = null;
        try {
            sock = new DatagramSocket();
            if (protector != null) protector.protect(sock);
            sock.setSoTimeout(UDP_TIMEOUT_MS);
            InetAddress dest = InetAddress.getByName(serverIp);
            sock.send(new DatagramPacket(query, query.length, dest, 53));
            byte[] buf = new byte[MAX_DNS_PACKET];
            DatagramPacket resp = new DatagramPacket(buf, buf.length);
            sock.receive(resp);
            int len = resp.getLength();
            if (len < 12) return null;
            byte[] result = new byte[len];
            System.arraycopy(buf, 0, result, 0, len);
            return result;
        } catch (Exception ignored) {
            return null;
        } finally {
            if (sock != null) try { sock.close(); } catch (Exception ignored) { }
        }
    }

    private byte[] queryTcpViaSocks(String dnsIp, int dnsPort, byte[] query) {
        Socket sock = null;
        try {
            byte[] ipBytes = InetAddress.getByName(dnsIp).getAddress();
            if (ipBytes.length != 4) return null;

            sock = new Socket();
            if (protector != null) protector.protectSocket(sock);
            sock.connect(new InetSocketAddress("127.0.0.1", socksPort), TCP_TIMEOUT_MS);
            sock.setSoTimeout(TCP_TIMEOUT_MS);
            sock.setTcpNoDelay(true);

            DataOutputStream out = new DataOutputStream(sock.getOutputStream());
            DataInputStream in = new DataInputStream(sock.getInputStream());

            out.write(new byte[]{0x05, 0x01, 0x00});
            out.flush();
            byte[] greetResp = new byte[2];
            in.readFully(greetResp);
            if (greetResp[0] != 0x05 || greetResp[1] != 0x00) return null;

            byte[] req = new byte[10];
            req[0] = 0x05;
            req[1] = 0x01;
            req[2] = 0x00;
            req[3] = 0x01;
            System.arraycopy(ipBytes, 0, req, 4, 4);
            req[8] = (byte) ((dnsPort >> 8) & 0xFF);
            req[9] = (byte) (dnsPort & 0xFF);
            out.write(req);
            out.flush();

            byte[] connHdr = new byte[4];
            in.readFully(connHdr);
            if (connHdr[0] != 0x05 || connHdr[1] != 0x00) return null;
            int atyp = connHdr[3] & 0xFF;
            if (atyp == 1) in.readFully(new byte[6]);
            else if (atyp == 4) in.readFully(new byte[18]);
            else if (atyp == 3) in.readFully(new byte[in.readUnsignedByte() + 2]);
            else return null;

            out.writeShort(query.length);
            out.write(query);
            out.flush();

            int respLen = in.readUnsignedShort();
            if (respLen < 12 || respLen > MAX_DNS_PACKET) return null;
            byte[] resp = new byte[respLen];
            in.readFully(resp);
            return resp;
        } catch (Exception ignored) {
            return null;
        } finally {
            if (sock != null) try { sock.close(); } catch (Exception ignored) { }
        }
    }

    private static String cacheKey(byte[] query) {
        if (query == null || query.length < 12) return null;
        return new String(query, 2, query.length - 2, java.nio.charset.StandardCharsets.ISO_8859_1);
    }

    private byte[] getCachedAnswer(byte[] query) {
        String key = cacheKey(query);
        if (key == null) return null;
        CachedDnsAnswer entry = dnsCache.get(key);
        if (entry == null) return null;
        if (System.nanoTime() >= entry.expiresAtNanos) {
            dnsCache.remove(key);
            return null;
        }
        byte[] answer = entry.packet.clone();
        answer[0] = query[0];
        answer[1] = query[1];
        return answer;
    }

    private void cacheAnswer(byte[] query, byte[] answer) {
        if (query == null || answer == null || query.length < 12 || answer.length < 12
                || answer.length > MAX_DNS_PACKET || isPoisonedAnswer(answer)) return;
        int flags = ((answer[2] & 0xFF) << 8) | (answer[3] & 0xFF);
        int answerCount = ((answer[6] & 0xFF) << 8) | (answer[7] & 0xFF);
        if ((flags & 0x000F) != 0 || answerCount == 0) return;
        long ttlSeconds = positiveAnswerTtlSeconds(answer);
        if (ttlSeconds <= 0) return;
        String key = cacheKey(query);
        if (key == null) return;
        byte[] copy = answer.clone();
        copy[0] = 0;
        copy[1] = 0;
        long ttlNanos = TimeUnit.SECONDS.toNanos(Math.min(120L, ttlSeconds));
        dnsCache.put(key, new CachedDnsAnswer(copy, System.nanoTime() + ttlNanos));
    }

    private static long positiveAnswerTtlSeconds(byte[] msg) {
        if (msg == null || msg.length < 12) return 0;
        int qd = ((msg[4] & 0xFF) << 8) | (msg[5] & 0xFF);
        int an = ((msg[6] & 0xFF) << 8) | (msg[7] & 0xFF);
        int ns = ((msg[8] & 0xFF) << 8) | (msg[9] & 0xFF);
        int ar = ((msg[10] & 0xFF) << 8) | (msg[11] & 0xFF);
        int pos = 12;
        for (int i = 0; i < qd; i++) {
            pos = skipName(msg, pos);
            if (pos < 0 || pos + 4 > msg.length) return 0;
            pos += 4;
        }
        long minTtl = Long.MAX_VALUE;
        int total = an + ns + ar;
        for (int i = 0; i < total; i++) {
            pos = skipName(msg, pos);
            if (pos < 0 || pos + 10 > msg.length) return 0;
            int type = ((msg[pos] & 0xFF) << 8) | (msg[pos + 1] & 0xFF);
            long ttl = ((long) (msg[pos + 4] & 0xFF) << 24)
                    | ((long) (msg[pos + 5] & 0xFF) << 16)
                    | ((long) (msg[pos + 6] & 0xFF) << 8)
                    | (long) (msg[pos + 7] & 0xFF);
            int rdLen = ((msg[pos + 8] & 0xFF) << 8) | (msg[pos + 9] & 0xFF);
            pos += 10;
            if (pos + rdLen > msg.length) return 0;
            if (i < an && type != 41) minTtl = Math.min(minTtl, ttl);
            pos += rdLen;
        }
        return minTtl == Long.MAX_VALUE ? 0 : minTtl;
    }

    private static boolean isPoisonedAnswer(byte[] msg) {
        if (msg == null || msg.length < 12) return false;
        int anCount = ((msg[6] & 0xFF) << 8) | (msg[7] & 0xFF);
        if (anCount <= 0) return false;
        int qdCount = ((msg[4] & 0xFF) << 8) | (msg[5] & 0xFF);
        int pos = 12;
        for (int i = 0; i < qdCount; i++) {
            pos = skipName(msg, pos);
            if (pos < 0 || pos + 4 > msg.length) return false;
            pos += 4;
        }
        for (int i = 0; i < anCount; i++) {
            pos = skipName(msg, pos);
            if (pos < 0 || pos + 10 > msg.length) return false;
            int type = ((msg[pos] & 0xFF) << 8) | (msg[pos + 1] & 0xFF);
            int rdLen = ((msg[pos + 8] & 0xFF) << 8) | (msg[pos + 9] & 0xFF);
            pos += 10;
            if (pos + rdLen > msg.length) return false;
            if (type == 1 && rdLen == 4) {
                int a = msg[pos] & 0xFF;
                int b = msg[pos + 1] & 0xFF;
                int c = msg[pos + 2] & 0xFF;
                int d = msg[pos + 3] & 0xFF;
                if ((a == 10 && b == 10 && c == 34 && (d >= 34 && d <= 37))
                        || (a == 0 && b == 0 && c == 0 && d == 0)) {
                    return true;
                }
            }
            pos += rdLen;
        }
        return false;
    }

    private static int skipName(byte[] msg, int pos) {
        int jumps = 0;
        while (pos < msg.length && jumps < 64) {
            int len = msg[pos] & 0xFF;
            if (len == 0) return pos + 1;
            if ((len & 0xC0) == 0xC0) return pos + 2;
            pos += 1 + len;
            jumps++;
        }
        return -1;
    }

    private static boolean isValidIpv4(String ip) {
        if (ip == null || !ip.matches("[0-9.]+")) return false;
        String[] parts = ip.split("\\.", -1);
        if (parts.length != 4) return false;
        for (String p : parts) {
            if (p.isEmpty() || p.length() > 3) return false;
            try {
                int n = Integer.parseInt(p);
                if (n < 0 || n > 255) return false;
            } catch (NumberFormatException e) {
                return false;
            }
        }
        return true;
    }

    public synchronized void stop() {
        running = false;
        if (serverSocket != null) {
            try { serverSocket.close(); } catch (Exception ignored) { }
            serverSocket = null;
        }
        if (listenerThread != null) {
            listenerThread.interrupt();
            listenerThread = null;
        }
        if (pool != null) {
            pool.shutdownNow();
            pool = null;
        }
        dnsCache.clear();
    }
}
