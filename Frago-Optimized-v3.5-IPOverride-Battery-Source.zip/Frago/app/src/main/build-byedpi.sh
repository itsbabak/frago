#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")"
JNI_DIR="$PWD/jni"
mkdir -p "$JNI_DIR"

# Pin the ByeDPI source so builds remain reproducible.
if [ ! -f "$JNI_DIR/byedpi/main.c" ]; then
  rm -rf "$JNI_DIR/byedpi"
  git clone --depth 1 --branch v0.17.3 https://github.com/hufrea/byedpi.git "$JNI_DIR/byedpi"
fi

mkdir -p assets/licenses
cp "$JNI_DIR/byedpi/LICENSE" assets/licenses/BYEDPI-LICENSE.txt

if command -v ndk-build >/dev/null 2>&1; then
  NDK_BUILD="$(command -v ndk-build)"
elif [ -n "${ANDROID_NDK_HOME:-}" ] && [ -x "$ANDROID_NDK_HOME/ndk-build" ]; then
  NDK_BUILD="$ANDROID_NDK_HOME/ndk-build"
elif [ -n "${ANDROID_NDK_ROOT:-}" ] && [ -x "$ANDROID_NDK_ROOT/ndk-build" ]; then
  NDK_BUILD="$ANDROID_NDK_ROOT/ndk-build"
else
  echo "ndk-build not found. Install Android NDK and set ANDROID_NDK_HOME." >&2
  exit 1
fi

# Rebuild every native component, not just ByeDPI. NDK r28+ gives the ARM64
# ELF outputs 16 KB page alignment by default (Android 15/16 compatibility).
"$NDK_BUILD" \
  NDK_PROJECT_PATH=. \
  APP_BUILD_SCRIPT=jni/Android.mk \
  APP_ABI="arm64-v8a" \
  APP_MODULES="pdnsd system tun2socks byedpi"

for abi in arm64-v8a; do
  OUT="libs/$abi"
  DEST="jniLibs/$abi"
  mkdir -p "$DEST"

  install -m 755 "$OUT/pdnsd" "$DEST/libpdnsd.so"
  install -m 755 "$OUT/tun2socks" "$DEST/libtun2socks.so"
  install -m 755 "$OUT/libsystem.so" "$DEST/libsystem.so"
  install -m 755 "$OUT/byedpi" "$DEST/libbyedpi.so"
done

# Fail early if any required native executable/library is missing.
for abi in arm64-v8a; do
  for file in libpdnsd.so libtun2socks.so libsystem.so libbyedpi.so; do
    test -s "jniLibs/$abi/$file"
  done
done

printf 'All Frago native components rebuilt for ARM64.\n'
