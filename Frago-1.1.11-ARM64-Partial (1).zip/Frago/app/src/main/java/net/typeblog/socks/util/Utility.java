package net.typeblog.socks.util;

import android.content.Context;
import android.content.Intent;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.util.List;

import net.typeblog.socks.R;
import net.typeblog.socks.SocksVpnService;
import static net.typeblog.socks.util.Constants.*;

public class Utility {

    public static int exec(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(cmd);
            return p.waitFor();
        } catch (Exception e) {
            return -1;
        }
    }

    public static void killPidFile(String f) {
        File file = new File(f);
        if (!file.exists()) return;

        InputStream i;
        try {
            i = new FileInputStream(file);
        } catch (Exception e) {
            return;
        }

        byte[] buf = new byte[512];
        int len;
        StringBuilder str = new StringBuilder();

        try {
            while ((len = i.read(buf, 0, 512)) > 0) {
                str.append(new String(buf, 0, len));
            }
            i.close();
        } catch (Exception e) {
            return;
        }

        try {
            int pid = Integer.parseInt(str.toString().trim().replace("\n", ""));
            if (pid > 0) {
                boolean signalled = false;
                try {
                    Process killer = new ProcessBuilder("/system/bin/kill", "-TERM",
                            Integer.toString(pid)).start();
                    signalled = killer.waitFor() == 0;
                } catch (Exception ignored) { }
                if (!signalled) {
                    try { android.os.Process.killProcess(pid); } catch (Exception ignored) { }
                }
            }
            file.delete();
        } catch (Exception ignored) { }
    }

    public static String join(List<String> list, String separator) {
        if (list.isEmpty()) return "";
        StringBuilder ret = new StringBuilder();
        for (String s : list) {
            ret.append(s).append(separator);
        }
        return ret.substring(0, ret.length() - separator.length());
    }

    public static void makePdnsdConf(Context context, String dns, int port) {
        makePdnsdConf(context, dns, port, false);
    }

    public static void makePdnsdConf(Context context, String dns, int port, boolean udpUpstream) {
        String conf = context.getString(R.string.pdnsd_conf)
                .replace("{DIR}", context.getFilesDir().toString())
                .replace("{IP}", dns)
                .replace("{PORT}", Integer.toString(port));
        if (udpUpstream) conf = conf.replace("query_method=tcp_only", "query_method=udp_only");
        File f = new File(context.getFilesDir() + "/pdnsd.conf");

        if (f.exists()) f.delete();

        try {
            OutputStream out = new FileOutputStream(f);
            out.write(conf.getBytes());
            out.flush();
            out.close();
        } catch (Exception ignored) { }

        File cache = new File(context.getFilesDir() + "/pdnsd.cache");
        try {
            if (cache.exists()) cache.delete();
            cache.createNewFile();
        } catch (Exception ignored) { }
    }

    public static void startVpn(Context context, Profile profile) {
        Intent i = new Intent(context, SocksVpnService.class)
                .putExtra(INTENT_NAME, profile.getName())
                .putExtra(INTENT_PROTOCOL, profile.getProtocol())
                .putExtra(INTENT_SERVER, "fragment".equals(profile.getProtocol()) ? "127.0.0.1" : profile.getServer())
                .putExtra(INTENT_PORT, "fragment".equals(profile.getProtocol()) ? 1081 : profile.getPort())
                .putExtra(INTENT_USERNAME, profile.isUserPw() ? profile.getUsername() : null)
                .putExtra(INTENT_PASSWORD, profile.isUserPw() ? profile.getPassword() : null)
                .putExtra(INTENT_PER_APP, profile.isPerApp())
                .putExtra(INTENT_TLSREC_POSITIONS, profile.getTlsRecordPositions())
                .putExtra(INTENT_DESYNC_MODE, profile.getDesyncMode())
                .putExtra(INTENT_FAKE_SNI, profile.getFakeSni())
                .putExtra(INTENT_FAKE_TTL, profile.getFakeTtl())
                .putExtra(INTENT_FAKE_SNI_ENABLED, profile.isFakeSniEnabled())
                .putExtra(INTENT_BLOCK_QUIC, profile.isBlockQuic())
                .putExtra(INTENT_DNS_HOST_OVERRIDES, profile.getDnsHostOverrides());

        if (profile.isPerApp()) {
            i.putExtra(INTENT_APP_BYPASS, profile.isBypassApp())
                    .putExtra(INTENT_APP_LIST, profile.getAppList().split("\n"));
        }

        if (android.os.Build.VERSION.SDK_INT >= 26) context.startForegroundService(i);
        else context.startService(i);
    }
}
