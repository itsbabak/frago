package net.typeblog.socks.util;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;

/**
 * High-performance QUIC (UDP port 443) sinkhole that is always active during VPN sessions
 * so apps like X immediately fall back to TCP/443 where OOB + fragmentation operates.
 * Operates with 0% idle CPU and leaves DNS (UDP 53) and TCP traffic untouched.
 */
public final class QuicUdp443Blocker {
    private static final int SINKHOLE_PORT = 5355;

    private volatile boolean running;
    private DatagramSocket socket;
    private Thread worker;

    public synchronized void start() throws Exception {
        if (running) return;
        DatagramSocket sock = new DatagramSocket(null);
        sock.setReuseAddress(true);
        sock.bind(new InetSocketAddress("127.0.0.1", SINKHOLE_PORT));
        sock.setSoTimeout(0);
        socket = sock;
        running = true;

        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                byte[] buf = new byte[1500];
                DatagramPacket pkt = new DatagramPacket(buf, buf.length);
                while (running) {
                    try {
                        sock.receive(pkt);
                        // Drop QUIC (UDP 443) packets immediately to force TCP fallback.
                    } catch (IOException ignored) {
                        if (!running) break;
                    } catch (Exception ignored) {
                    }
                }
            }
        }, "Frago-QuicBlock");
        worker.setDaemon(true);
        worker.start();
    }

    public static InetAddress getSinkholeAddress() {
        try {
            return InetAddress.getByName("127.0.0.1");
        } catch (Exception ignored) {
            return null;
        }
    }

    public static int getSinkholePort() {
        return SINKHOLE_PORT;
    }

    public synchronized void stop() {
        running = false;
        if (socket != null) {
            try { socket.close(); } catch (Exception ignored) { }
            socket = null;
        }
        if (worker != null) {
            worker.interrupt();
            worker = null;
        }
    }
}
