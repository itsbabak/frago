# Privacy notes

- Frago stores imported JSON profiles locally in Android app preferences.
- DNS queries received by the VPN DNS gateway are sent to the HTTPS DoH endpoint configured in the imported JSON.
- Regular-expression host overrides in the JSON are answered locally and are not sent to the DoH server.
- Frago's own DoH connections bypass its VPN interface to avoid a DNS recursion loop.
- The app does not include analytics or advertising SDKs.
