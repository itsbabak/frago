# Frago (ARM64)

Frago is a small Android VPN app for a deliberately limited JSON profile format. It rebuilds the ARM64 `tun2socks` bridge in Android UDP-relay mode and implements the local SOCKS5 TCP/UDP endpoints and DNS-over-HTTPS gateway in Java. The application uses no Xray or Sing-box runtime.

## Target

- Samsung Galaxy A36 / A56 and other Android ARM64 (`arm64-v8a`) devices
- Android API 24 or newer
- Release APK is optimized with R8 and resource shrinking
- GitHub Actions reports the APK size and targets 2 MiB maximum

## Importing a profile

1. Build and install the `Frago-ARM64-APK` artifact from GitHub Actions.
2. Open Frago and select **Import JSON file**.
3. Select a JSON file that uses the subset documented below.
4. Turn on the VPN switch and approve Android's VPN permission prompt.

Only JSON file import is exposed. There is no share-link importer and no separate remote SOCKS server form. The JSON's `socks` inbound defines Frago's local SOCKS5 port; the app's local SOCKS server connects directly to destination servers.

## Supported JSON subset

- `inbounds`: one `protocol: "socks"` entry listening on `127.0.0.1`, with a valid port and `settings.udp` to enable SOCKS UDP relay.
- `dns.servers`: HTTPS DoH endpoint, queried using RFC 8484 `application/dns-message` POST.
- `dns.queryStrategy`: `UseIPv4`.
- `dns.hosts`: literal IPv4 address arrays and regular-expression keys such as `regexp:(google)`. Matching A queries receive all configured IPv4 addresses.
- `outbounds`: `freedom` and `blackhole` only. The `freedom.settings.fragment` subset supports `packets: "tlshello"`, `length`, and `interval` ranges.
- `routing.rules`: `type: "field"`, `domain` (`regexp:`, `domain:`, `full:`), numeric `ip` CIDRs, `network: "tcp"` / `"udp"`, and `outboundTag`.

For the supplied profile, non-overridden DNS queries go to `https://kid.openbld.net/dns-query`. Queries whose names match `regexp:(google)` are answered locally with both `65.109.184.128` and `91.107.241.144`; those matching A queries do not need an upstream DoH request. The `.ir` domain and private IP rules select the non-fragmented `direct` outbound. Other TCP traffic selects `fragment-out`; the local SOCKS bridge identifies HTTP Host and TLS SNI where available, collects the first ClientHello across TLS handshake records, then sends those bytes in randomized write chunks with the configured delays. With `settings.udp: true`, the Android UDP relay mode forwards UDP through Frago's local SOCKS UDP listener; the supplied `network: "udp"` rule routes it direct. DNS UDP/53 is intercepted separately and sent to the configured DoH endpoint.

## Important limitations

- This is not a general interpreter for every possible option in the wider JSON ecosystem. Unsupported outbound protocols or routing syntax are rejected during import instead of silently ignored.
- General IPv4 UDP forwarding uses the Android-specific SOCKS UDP relay path in the rebuilt `tun2socks` bridge and Frago's local UDP endpoint. It is not a full implementation of every SOCKS5 UDP edge case: SOCKS UDP fragmentation (`FRAG` other than zero) is dropped, and active flows are capped at 64 with 60-second idle expiry. QUIC/HTTP3 is transported as ordinary UDP and is not TLS-fragmented.
- TLS chunked writes plus delays request TCP segmentation, but the Android/Linux network stack and network path can coalesce or segment data differently. The app cannot guarantee a particular on-wire packet boundary.
- DNS-over-HTTPS bootstrap uses Android's normal network resolver from Frago's own process. Frago is excluded from its own VPN to prevent a DNS recursion loop.

## Build

Open the repository in Android Studio or push it to GitHub. The workflow `.github/workflows/build-arm64-apk.yml` installs Android SDK Platform/Build Tools and NDK 26.3.11579264, rebuilds the ARM64 native bridge with `ANDROID_UDP`, and then builds the optimized release APK. No Xray or Sing-box engine is downloaded or packaged. For a local build, run `bash app/src/main/build-jni.sh` from the extracted source project before running Gradle.

The generated APK is `app/build/outputs/apk/release/app-release.apk` and is uploaded as the Actions artifact `Frago-ARM64-APK`.

## Frago per-app routing update

The Settings screen now includes **Choose apps for VPN**. Select one or more launcher apps to use Android's allow-list VPN mode. If no apps are selected, Frago uses the system-wide VPN mode while excluding Frago itself so its DoH requests do not loop back into the VPN.

The JSON inbound remains the local SOCKS5 endpoint (127.0.0.1 and the configured port). Frago's built-in SOCKS5 server accepts connections from tun2socks and applies the JSON routing and TLS ClientHello write-splitting rules. This is not an external SOCKS5 upstream-proxy form.

Limitations: UDP forwarding is direct according to the supplied JSON; UDP traffic is not subject to the TCP TLS fragment option. TLS fragmentation is implemented as paced, randomized TCP writes of the initial ClientHello bytes. The OS/TCP stack can still coalesce or segment writes differently, so a one-write/one-packet guarantee is not possible. The source changes passed local JVM smoke tests for UDP relay and multi-record ClientHello parsing, but the full Android APK build and physical Samsung-device test have not been completed in this environment.
