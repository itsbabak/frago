# Third-party notices

This project is derived from SocksDroid and retains the project's original license in `LICENSE`.

The ARM64 `tun2socks` and JNI native libraries are retained from the supplied source project. Their corresponding source code and license notices remain in `app/src/main/jni/`.

No external proxy core is bundled or downloaded by the build workflow.
