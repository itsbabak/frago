#!/bin/bash
set -euo pipefail

# Build only Frago's ARM64 tunnel bridge and JNI descriptor helper.
rm -rf jniLibs libs
ndk-build APP_ABI=arm64-v8a
mkdir -p jniLibs/arm64-v8a
mv libs/arm64-v8a/tun2socks jniLibs/arm64-v8a/libtun2socks.so
mv libs/arm64-v8a/libsystem.so jniLibs/arm64-v8a/libsystem.so
rm -rf libs
