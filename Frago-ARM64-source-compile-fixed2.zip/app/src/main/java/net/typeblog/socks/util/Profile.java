package net.typeblog.socks.util;

import android.content.SharedPreferences;

public final class Profile {
    private final SharedPreferences preferences;
    private final String name;
    private final String prefix;

    Profile(SharedPreferences preferences, String name) {
        this.preferences = preferences;
        this.name = name;
        this.prefix = name.replace("_", "__").replace(" ", "_");
    }

    public String getName() { return name; }

    public String getFragoJson() {
        return preferences.getString(prefix + "frago_json", "");
    }

    public void setFragoJson(String json) {
        preferences.edit().putString(prefix + "frago_json", json).apply();
    }

    public java.util.Set<String> getSelectedApps() {
        return new java.util.HashSet<>(preferences.getStringSet(prefix + "selected_apps", java.util.Collections.<String>emptySet()));
    }

    public void setSelectedApps(java.util.Set<String> packages) {
        preferences.edit().putStringSet(prefix + "selected_apps", new java.util.HashSet<>(packages)).apply();
    }

    public boolean autoConnect() {
        return preferences.getBoolean(prefix + "auto", false);
    }

    public void setAutoConnect(boolean enabled) {
        preferences.edit().putBoolean(prefix + "auto", enabled).apply();
    }

    void delete() {
        preferences.edit()
                .remove(prefix + "frago_json")
                .remove(prefix + "auto")
                .remove(prefix + "selected_apps")
                .apply();
    }
}
