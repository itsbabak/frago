package net.typeblog.socks.engine;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;

import javax.net.ssl.HttpsURLConnection;

/** Minimal DNS gateway for Frago. DNS messages are forwarded using RFC 8484 DoH. */
public final class FragoDnsProxy {
    private static final String TAG = "FragoDNS";
    public static final int GATEWAY_PORT = 8091;
    private static final int MAX_DNS_MESSAGE = 4096;

    private final FragoConfig config;
    private volatile boolean running;
    private DatagramSocket socket;
    private Thread receiver;
    private final ExecutorService workers = Executors.newFixedThreadPool(4);

    public FragoDnsProxy(FragoConfig config) {
        this.config = config;
    }

    public synchronized void start() throws Exception {
        if (running) return;
        DatagramSocket udp = new DatagramSocket(null);
        udp.setReuseAddress(true);
        udp.bind(new InetSocketAddress(InetAddress.getByName("0.0.0.0"), GATEWAY_PORT));
        udp.setSoTimeout(1000);
        socket = udp;
        running = true;
        receiver = new Thread(this::receiveLoop, "Frago-DoH-Gateway");
        receiver.setDaemon(true);
        receiver.start();
    }

    public synchronized void stop() {
        running = false;
        DatagramSocket current = socket;
        socket = null;
        if (current != null) current.close();
        workers.shutdownNow();
        if (receiver != null) receiver.interrupt();
        receiver = null;
    }

    private void receiveLoop() {
        while (running) {
            try {
                byte[] data = new byte[MAX_DNS_MESSAGE];
                DatagramPacket packet = new DatagramPacket(data, data.length);
                socket.receive(packet);
                final byte[] query = new byte[packet.getLength()];
                System.arraycopy(packet.getData(), packet.getOffset(), query, 0, packet.getLength());
                final InetAddress clientAddress = packet.getAddress();
                final int clientPort = packet.getPort();
                workers.execute(() -> {
                    byte[] answer;
                    try {
                        answer = answer(query);
                    } catch (Exception e) {
                        Log.w(TAG, "DoH query failed", e);
                        answer = makeErrorResponse(query, 2);
                    }
                    DatagramSocket current = socket;
                    if (running && current != null && answer != null) {
                        try {
                            current.send(new DatagramPacket(answer, answer.length, clientAddress, clientPort));
                        } catch (Exception e) {
                            Log.w(TAG, "Could not return DNS response", e);
                        }
                    }
                });
            } catch (SocketTimeoutException ignored) {
                // Periodically check running state.
            } catch (Exception e) {
                if (running) Log.w(TAG, "DNS gateway stopped unexpectedly", e);
            }
        }
    }

    private byte[] answer(byte[] query) throws Exception {
        Question q = parseQuestion(query);
        if (q == null) return makeErrorResponse(query, 1);

        List<String> override = config.overrideAddresses(q.name);
        if (override != null && q.type == 1 && q.qclass == 1) {
            return makeOverrideResponse(query, q, override);
        }
        // UseIPv4: return NODATA for AAAA instead of allowing IPv6 answers.
        if (config.ipv4Only && q.type == 28 && q.qclass == 1) {
            return makeOverrideResponse(query, q, new ArrayList<>());
        }
        return queryDoh(query);
    }

    /** Resolve a hostname for a SOCKS request, using the same JSON hosts and DoH rules. */
    public List<InetAddress> resolveA(String hostname) throws Exception {
        List<String> override = config.overrideAddresses(hostname);
        List<InetAddress> result = new ArrayList<>();
        if (override != null) {
            for (String ip : override) result.add(InetAddress.getByName(ip));
            return result;
        }
        byte[] response = queryDoh(makeQuery(hostname, 1));
        result.addAll(readARecords(response));
        if (result.isEmpty()) throw new IllegalStateException("DNS returned no IPv4 address for " + hostname);
        return result;
    }

    private byte[] queryDoh(byte[] dnsMessage) throws Exception {
        HttpsURLConnection connection = null;
        try {
            URL url = new URL(config.dohUrl);
            connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(7000);
            connection.setReadTimeout(7000);
            connection.setInstanceFollowRedirects(true);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/dns-message");
            connection.setRequestProperty("Accept", "application/dns-message");
            connection.setFixedLengthStreamingMode(dnsMessage.length);
            OutputStream out = connection.getOutputStream();
            out.write(dnsMessage);
            out.flush();
            out.close();
            int status = connection.getResponseCode();
            InputStream in = status >= 200 && status < 300
                    ? connection.getInputStream() : connection.getErrorStream();
            if (in == null) throw new IllegalStateException("DoH HTTP status " + status);
            byte[] response = readLimited(in, MAX_DNS_MESSAGE);
            in.close();
            if (status < 200 || status >= 300) throw new IllegalStateException("DoH HTTP status " + status);
            if (response.length < 12) throw new IllegalStateException("DoH returned an invalid DNS message");
            return response;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static byte[] readLimited(InputStream in, int limit) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int n;
        while ((n = in.read(buffer)) != -1) {
            if (out.size() + n > limit) throw new IllegalStateException("DNS response is too large");
            out.write(buffer, 0, n);
        }
        return out.toByteArray();
    }

    private static byte[] makeQuery(String hostname, int type) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int id = ThreadLocalRandom.current().nextInt(0, 65536);
        write16(out, id);
        write16(out, 0x0100); // recursion desired
        write16(out, 1); write16(out, 0); write16(out, 0); write16(out, 0);
        String clean = hostname.endsWith(".") ? hostname.substring(0, hostname.length() - 1) : hostname;
        for (String label : clean.split("\\.")) {
            byte[] bytes = label.getBytes("US-ASCII");
            if (bytes.length == 0 || bytes.length > 63) throw new IllegalArgumentException("Invalid DNS name");
            out.write(bytes.length);
            out.write(bytes);
        }
        out.write(0);
        write16(out, type);
        write16(out, 1);
        return out.toByteArray();
    }

    private static byte[] makeOverrideResponse(byte[] query, Question q, List<String> addresses) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(query, 0, 2);
        int requestFlags = u16(query, 2);
        write16(out, 0x8080 | (requestFlags & 0x0100)); // QR + RA + preserve RD
        write16(out, 1);
        int count = q.type == 1 ? addresses.size() : 0;
        write16(out, count);
        write16(out, 0); write16(out, 0);
        out.write(query, 12, q.questionEnd - 12);
        for (String ip : addresses) {
            byte[] address = InetAddress.getByName(ip).getAddress();
            if (address.length != 4) continue;
            write16(out, 0xC00C); // compressed pointer to QNAME
            write16(out, 1); write16(out, 1);
            out.write(new byte[]{0, 0, 0, 60}); // TTL 60 seconds
            write16(out, 4);
            out.write(address);
        }
        return out.toByteArray();
    }

    private static byte[] makeErrorResponse(byte[] query, int rcode) {
        try {
            Question q = parseQuestion(query);
            if (q == null) return null;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            out.write(query, 0, 2);
            int flags = 0x8080 | (u16(query, 2) & 0x0100) | (rcode & 0x0f);
            write16(out, flags); write16(out, 1); write16(out, 0); write16(out, 0); write16(out, 0);
            out.write(query, 12, q.questionEnd - 12);
            return out.toByteArray();
        } catch (Exception ignored) { return null; }
    }

    private static Question parseQuestion(byte[] packet) {
        try {
            if (packet == null || packet.length < 17) return null;
            int pos = 12;
            StringBuilder name = new StringBuilder();
            int labels = 0;
            while (pos < packet.length) {
                int length = packet[pos++] & 0xff;
                if (length == 0) break;
                if ((length & 0xc0) != 0 || length > 63 || pos + length > packet.length) return null;
                if (labels++ > 127) return null;
                if (name.length() > 0) name.append('.');
                name.append(new String(packet, pos, length, "US-ASCII"));
                pos += length;
            }
            if (pos + 4 > packet.length) return null;
            int type = u16(packet, pos);
            int qclass = u16(packet, pos + 2);
            return new Question(name.toString().toLowerCase(java.util.Locale.US), type, qclass, pos + 4);
        } catch (Exception ignored) { return null; }
    }

    private static List<InetAddress> readARecords(byte[] message) throws Exception {
        List<InetAddress> addresses = new ArrayList<>();
        if (message == null || message.length < 12) return addresses;
        int qd = u16(message, 4), an = u16(message, 6);
        int pos = 12;
        for (int i = 0; i < qd; i++) {
            pos = skipName(message, pos);
            if (pos < 0 || pos + 4 > message.length) return addresses;
            pos += 4;
        }
        for (int i = 0; i < an; i++) {
            pos = skipName(message, pos);
            if (pos < 0 || pos + 10 > message.length) break;
            int type = u16(message, pos);
            int clazz = u16(message, pos + 2);
            int size = u16(message, pos + 8);
            pos += 10;
            if (size < 0 || pos + size > message.length) break;
            if (type == 1 && clazz == 1 && size == 4) {
                byte[] ip = new byte[4];
                System.arraycopy(message, pos, ip, 0, 4);
                addresses.add(InetAddress.getByAddress(ip));
            }
            pos += size;
        }
        return addresses;
    }

    private static int skipName(byte[] message, int offset) {
        int pos = offset;
        while (pos < message.length) {
            int length = message[pos++] & 0xff;
            if (length == 0) return pos;
            if ((length & 0xc0) == 0xc0) return pos + 1 <= message.length ? pos + 1 : -1;
            if ((length & 0xc0) != 0 || length > 63 || pos + length > message.length) return -1;
            pos += length;
        }
        return -1;
    }

    private static int u16(byte[] data, int offset) {
        return ((data[offset] & 0xff) << 8) | (data[offset + 1] & 0xff);
    }

    private static void write16(ByteArrayOutputStream out, int value) {
        out.write((value >>> 8) & 0xff);
        out.write(value & 0xff);
    }

    private static final class Question {
        final String name;
        final int type;
        final int qclass;
        final int questionEnd;
        Question(String name, int type, int qclass, int questionEnd) {
            this.name = name; this.type = type; this.qclass = qclass; this.questionEnd = questionEnd;
        }
    }
}
