package net.typeblog.socks.util;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;

import net.typeblog.socks.SocksVpnService;

import static net.typeblog.socks.util.Constants.INTENT_ALLOWED_APPS;
import static net.typeblog.socks.util.Constants.INTENT_CONFIG;
import static net.typeblog.socks.util.Constants.INTENT_NAME;

public final class Utility {
    private static final String TAG = "FragoUtility";

    private Utility() { }

    /** Starts the native tun2socks helper. It daemonizes itself and writes its PID. */
    public static int exec(String command) {
        Process process = null;
        try {
            process = Runtime.getRuntime().exec(command);
            return process.waitFor();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            if (process != null) process.destroy();
            return -1;
        } catch (Exception e) {
            Log.e(TAG, "Could not launch tun2socks", e);
            if (process != null) process.destroy();
            return -1;
        }
    }

    /** Stops the daemonized tun2socks process and removes its PID file. */
    public static void killPidFile(String path) {
        File pidFile = new File(path);
        if (!pidFile.isFile()) return;
        try {
            String value;
            try (BufferedReader reader = new BufferedReader(new FileReader(pidFile))) {
                value = reader.readLine();
            }
            int pid = Integer.parseInt(value == null ? "" : value.trim());
            if (pid > 1) {
                Process kill = Runtime.getRuntime().exec(new String[]{"kill", Integer.toString(pid)});
                if (kill.waitFor() != 0) Log.w(TAG, "tun2socks process may already be stopped");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            Log.w(TAG, "Could not stop tun2socks from PID file", e);
        } finally {
            if (pidFile.exists() && !pidFile.delete()) Log.w(TAG, "Could not delete tun2socks PID file");
        }
    }

    public static void startVpn(Context context, Profile profile) {
        Intent intent = new Intent(context, SocksVpnService.class)
                .putExtra(INTENT_NAME, profile.getName())
                .putExtra(INTENT_CONFIG, profile.getFragoJson())
                .putStringArrayListExtra(INTENT_ALLOWED_APPS, new java.util.ArrayList<>(profile.getSelectedApps()));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }
}
