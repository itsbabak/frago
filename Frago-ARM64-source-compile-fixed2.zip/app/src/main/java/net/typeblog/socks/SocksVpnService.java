package net.typeblog.socks;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.util.Log;

import net.typeblog.socks.engine.FragoConfig;
import net.typeblog.socks.engine.FragoDnsProxy;
import net.typeblog.socks.engine.FragoSocksServer;
import net.typeblog.socks.util.Utility;

import java.util.Objects;

import static net.typeblog.socks.util.Constants.*;
import static net.typeblog.socks.BuildConfig.DEBUG;

public class SocksVpnService extends VpnService {
    class VpnBinder extends IVpnService.Stub {
        @Override public boolean isRunning() { return mRunning; }
        @Override public void stop() { stopMe(); }
    }

    private static final String TAG = "FragoVPN";
    private ParcelFileDescriptor mInterface;
    private volatile boolean mRunning = false;
    private volatile boolean mStarting = false;
    private volatile boolean mStopping = false;
    private volatile FragoDnsProxy mDnsProxy;
    private volatile FragoSocksServer mSocksServer;
    private final IBinder mBinder = new VpnBinder();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (mRunning || mStarting) return START_STICKY;
        mStopping = false;

        final String name = intent.getStringExtra(INTENT_NAME);
        final String rawConfig = intent.getStringExtra(INTENT_CONFIG);

        final FragoConfig config;
        try {
            if (TextUtils.isEmpty(rawConfig)) throw new IllegalArgumentException("ابتدا فایل JSON را وارد کنید.");
            config = FragoConfig.parse(rawConfig);
        } catch (Exception e) {
            Log.e(TAG, "Invalid Frago JSON", e);
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            String channelId = "app.frago.vpn";
            NotificationChannel channel = new NotificationChannel(channelId,
                    getString(R.string.channel_name), NotificationManager.IMPORTANCE_MIN);
            NotificationManager manager = getSystemService(NotificationManager.class);
            Objects.requireNonNull(manager).createNotificationChannel(channel);
            builder = new Notification.Builder(this, channelId);
        } else {
            builder = new Notification.Builder(this);
        }
        int intentFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) intentFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), intentFlags);
        startForeground(1, builder
                .setContentTitle(getString(R.string.notify_title))
                .setContentText(String.format(getString(R.string.notify_msg), name))
                .setPriority(Notification.PRIORITY_MIN)
                .setSmallIcon(R.drawable.ic_vpn)
                .setContentIntent(contentIntent)
                .build());

        java.util.ArrayList<String> allowedApps = intent.getStringArrayListExtra(INTENT_ALLOWED_APPS);
        configure(name, allowedApps);
        if (mInterface == null) {
            Log.e(TAG, "Could not establish the VPN interface");
            stopMe();
            return START_NOT_STICKY;
        }

        final int interfaceFd = mInterface.getFd();
        mStarting = true;
        new Thread(() -> start(interfaceFd, config), "Frago-Connect").start();
        return START_STICKY;
    }

    @Override public void onRevoke() { super.onRevoke(); stopMe(); }
    @Override public IBinder onBind(Intent intent) { return mBinder; }
    @Override public void onDestroy() { stopMe(); super.onDestroy(); }

    private void stopMe() {
        mStopping = true;
        mRunning = false;
        mStarting = false;
        stopForeground(true);

        FragoSocksServer socks = mSocksServer;
        mSocksServer = null;
        if (socks != null) socks.stop();
        FragoDnsProxy dns = mDnsProxy;
        mDnsProxy = null;
        if (dns != null) dns.stop();

        Utility.killPidFile(getFilesDir() + "/tun2socks.pid");
        if (mInterface != null) {
            try {
                System.jniclose(mInterface.getFd());
                mInterface.close();
            } catch (Exception e) {
                Log.w(TAG, "Could not close TUN interface", e);
            }
            mInterface = null;
        }
        stopSelf();
    }

    private void configure(String name, java.util.ArrayList<String> allowedApps) {
        Builder builder = new Builder();
        builder.setMtu(1500)
                .setSession(TextUtils.isEmpty(name) ? "Frago" : name)
                .addAddress("26.26.26.1", 24)
                // Virtual DNS destination; tun2socks redirects UDP/53 to Frago's DoH gateway.
                .addDnsServer("8.8.8.8")
                .addRoute("0.0.0.0", 0)
                .addRoute("8.8.8.8", 32);

        // When apps are selected, only those packages enter the VPN. Otherwise all apps
        // except Frago itself use the tunnel. Frago must bypass its own VPN for DoH.
        try {
            if (allowedApps != null && !allowedApps.isEmpty()) {
                for (String packageName : allowedApps) {
                    if (packageName == null || packageName.equals(getPackageName())) continue;
                    try { builder.addAllowedApplication(packageName); }
                    catch (Exception missing) { Log.w(TAG, "Skipping unavailable app " + packageName); }
                }
            } else {
                builder.addDisallowedApplication(getPackageName());
            }
        } catch (Exception e) {
            Log.e(TAG, "Cannot configure per-app VPN", e);
            return;
        }
        mInterface = builder.establish();
    }

    private void start(int fd, FragoConfig config) {
        if (mStopping) return;
        try {
            // Start the tiny DNS-over-HTTPS gateway and the local SOCKS5 endpoint before tun2socks.
            FragoDnsProxy dns = new FragoDnsProxy(config);
            dns.start();
            mDnsProxy = dns;

            FragoSocksServer socks = new FragoSocksServer(this, config, dns);
            socks.start();
            mSocksServer = socks;

            String command = String.format(java.util.Locale.US,
                    "%s/libtun2socks.so --netif-ipaddr 26.26.26.2"
                            + " --netif-netmask 255.255.255.0"
                            + " --socks-server-addr 127.0.0.1:%d"
                            + " --tunfd %d"
                            + " --tunmtu 1500"
                            + " --loglevel 2"
                            + " --pid %s/tun2socks.pid"
                            + " --sock %s/sock_path"
                            + " --dnsgw 26.26.26.1:%d",
                    getApplicationInfo().nativeLibraryDir, config.socksPort, fd,
                    getFilesDir(), getApplicationInfo().dataDir, FragoDnsProxy.GATEWAY_PORT);
            if (DEBUG) Log.d(TAG, command);
            if (Utility.exec(command) != 0) throw new IllegalStateException("tun2socks failed to start");

            for (int i = 0; i < 5 && !mStopping; i++) {
                if (System.sendfd(fd, getApplicationInfo().dataDir + "/sock_path") != -1) {
                    mRunning = true;
                    mStarting = false;
                    Log.i(TAG, "Frago connected: SOCKS 127.0.0.1:" + config.socksPort
                            + ", DoH " + config.dohUrl);
                    return;
                }
                Thread.sleep(1000L * (i + 1));
            }
            if (!mStopping) throw new IllegalStateException("Could not attach TUN to tun2socks");
        } catch (Exception e) {
            Log.e(TAG, "Frago startup failed", e);
            stopMe();
        }
    }
}
