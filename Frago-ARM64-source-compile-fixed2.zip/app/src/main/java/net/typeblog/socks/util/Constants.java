package net.typeblog.socks.util;

public final class Constants {
    public static final String INTENT_NAME = "FRAGO_NAME";
    public static final String INTENT_CONFIG = "FRAGO_JSON";
    public static final String INTENT_ALLOWED_APPS = "FRAGO_ALLOWED_APPS";

    public static final String PREF = "frago_profile";
    public static final String PREF_PROFILE = "profile";
    public static final String PREF_LAST_PROFILE = "last_profile";
    public static final String PREF_AUTO_CONNECT = "auto_connect";
}
