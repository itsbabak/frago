package net.typeblog.socks.engine;

import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Small, deliberately limited parser for Frago JSON. It supports only the documented local SOCKS, DoH, direct routing and TLS ClientHello fragmentation subset.
 * It implements the subset used by Frago: SOCKS inbound, DoH DNS, hosts,
 * freedom/blackhole outbounds and field routing with tlshello fragmentation.
 */
public final class FragoConfig {
    public final int socksPort;
    public final String dohUrl;
    public final boolean ipv4Only;
    public final List<HostOverride> hostOverrides;
    public final List<RouteRule> routes;
    public final Map<String, Outbound> outbounds;
    public final String defaultOutbound;

    public static final class Range {
        public final int min;
        public final int max;
        public Range(int min, int max) { this.min = min; this.max = max; }
        public int random() {
            if (max <= min) return min;
            return min + java.util.concurrent.ThreadLocalRandom.current().nextInt(max - min + 1);
        }
    }

    public static final class Outbound {
        public final String tag;
        public final String protocol;
        public final boolean fragmentTlsHello;
        public final Range length;
        public final Range interval;
        Outbound(String tag, String protocol, boolean fragmentTlsHello, Range length, Range interval) {
            this.tag = tag; this.protocol = protocol;
            this.fragmentTlsHello = fragmentTlsHello; this.length = length; this.interval = interval;
        }
    }

    public static final class HostOverride {
        final Pattern pattern;
        public final List<String> addresses;
        HostOverride(Pattern pattern, List<String> addresses) { this.pattern = pattern; this.addresses = addresses; }
        public boolean matches(String host) { return host != null && pattern.matcher(host).find(); }
    }

    public static final class RouteRule {
        final List<Pattern> domains = new ArrayList<>();
        final List<Cidr> ips = new ArrayList<>();
        final Set<String> networks = new HashSet<>();
        public final String outboundTag;
        RouteRule(String outboundTag) { this.outboundTag = outboundTag; }
        boolean matches(String host, InetAddress address, String network) {
            if (!networks.isEmpty() && !networks.contains(network.toLowerCase(Locale.US))) return false;
            if (!domains.isEmpty()) {
                if (host == null) return false;
                boolean matched = false;
                for (Pattern p : domains) if (p.matcher(host).find()) { matched = true; break; }
                if (!matched) return false;
            }
            if (!ips.isEmpty()) {
                if (address == null) return false;
                boolean matched = false;
                for (Cidr cidr : ips) if (cidr.contains(address)) { matched = true; break; }
                if (!matched) return false;
            }
            return true;
        }
    }

    private static final class Cidr {
        final byte[] network;
        final int prefix;
        Cidr(String input) throws Exception {
            String[] parts = input.split("/", 2);
            InetAddress addr = InetAddress.getByName(parts[0]);
            network = addr.getAddress();
            prefix = parts.length == 1 ? network.length * 8 : Integer.parseInt(parts[1]);
            if (prefix < 0 || prefix > network.length * 8) throw new IllegalArgumentException("Invalid CIDR: " + input);
        }
        boolean contains(InetAddress address) {
            byte[] candidate = address.getAddress();
            if (candidate.length != network.length) return false;
            int whole = prefix / 8, rem = prefix % 8;
            for (int i = 0; i < whole; i++) if (candidate[i] != network[i]) return false;
            if (rem != 0) {
                int mask = 0xff << (8 - rem);
                if (((candidate[whole] & 0xff) & mask) != ((network[whole] & 0xff) & mask)) return false;
            }
            return true;
        }
    }

    private FragoConfig(int socksPort, String dohUrl, boolean ipv4Only,
                        List<HostOverride> hostOverrides, List<RouteRule> routes,
                        Map<String, Outbound> outbounds, String defaultOutbound) {
        this.socksPort = socksPort;
        this.dohUrl = dohUrl;
        this.ipv4Only = ipv4Only;
        this.hostOverrides = Collections.unmodifiableList(hostOverrides);
        this.routes = Collections.unmodifiableList(routes);
        this.outbounds = Collections.unmodifiableMap(outbounds);
        this.defaultOutbound = defaultOutbound;
    }

    public static FragoConfig parse(String raw) throws JSONException {
        if (TextUtils.isEmpty(raw) || raw.trim().isEmpty()) throw new JSONException("فایل JSON خالی است.");
        JSONObject root = new JSONObject(raw);

        JSONArray inbounds = root.optJSONArray("inbounds");
        if (inbounds == null || inbounds.length() == 0) throw new JSONException("آرایه inbounds پیدا نشد.");
        JSONObject socks = null;
        for (int i = 0; i < inbounds.length(); i++) {
            JSONObject item = inbounds.optJSONObject(i);
            if (item != null && "socks".equalsIgnoreCase(item.optString("protocol"))) { socks = item; break; }
        }
        if (socks == null) throw new JSONException("یک inbound با protocol=socks لازم است.");
        String listen = socks.optString("listen", "127.0.0.1");
        if (!("127.0.0.1".equals(listen) || "localhost".equalsIgnoreCase(listen))) {
            throw new JSONException("SOCKS باید فقط روی 127.0.0.1 گوش کند.");
        }
        int port = socks.optInt("port", -1);
        if (port < 1 || port > 65535) throw new JSONException("پورت SOCKS معتبر نیست.");

        JSONObject dns = root.optJSONObject("dns");
        if (dns == null) throw new JSONException("بخش dns لازم است.");
        JSONArray servers = dns.optJSONArray("servers");
        if (servers == null || servers.length() == 0) throw new JSONException("آدرس DNS پیدا نشد.");
        String doh = null;
        for (int i = 0; i < servers.length(); i++) {
            String s = servers.optString(i, "");
            if (s.startsWith("https://")) { doh = s; break; }
        }
        if (doh == null) throw new JSONException("در نسخه Frago باید DNS از نوع HTTPS/DoH باشد.");
        String strategy = dns.optString("queryStrategy", "UseIPv4");
        boolean ipv4 = "UseIPv4".equalsIgnoreCase(strategy);
        if (!ipv4) throw new JSONException("فعلاً فقط queryStrategy=UseIPv4 پشتیبانی می‌شود.");

        List<HostOverride> hosts = parseHosts(dns.optJSONObject("hosts"));

        JSONArray outboundArray = root.optJSONArray("outbounds");
        if (outboundArray == null || outboundArray.length() == 0) throw new JSONException("آرایه outbounds پیدا نشد.");
        Map<String, Outbound> outboundMap = new HashMap<>();
        String defaultTag = null;
        for (int i = 0; i < outboundArray.length(); i++) {
            JSONObject item = outboundArray.optJSONObject(i);
            if (item == null) continue;
            String tag = item.optString("tag", "");
            String protocol = item.optString("protocol", "").toLowerCase(Locale.US);
            if (TextUtils.isEmpty(tag)) tag = "outbound-" + i;
            if (defaultTag == null) defaultTag = tag;
            if (!("freedom".equals(protocol) || "blackhole".equals(protocol))) {
                throw new JSONException("پروتکل outbound پشتیبانی‌نشده است: " + protocol + "؛ این نسخه مخصوص freedom/blackhole است.");
            }
            boolean frag = false;
            Range length = new Range(10, 400), interval = new Range(1, 30);
            if ("freedom".equals(protocol)) {
                JSONObject settings = item.optJSONObject("settings");
                JSONObject fragment = settings == null ? null : settings.optJSONObject("fragment");
                if (fragment != null) {
                    if (!"tlshello".equalsIgnoreCase(fragment.optString("packets", ""))) {
                        throw new JSONException("فقط fragment.packets=tlshello پشتیبانی می‌شود.");
                    }
                    length = parseRange(fragment.optString("length", "10-400"), "fragment.length", 1, 4096);
                    interval = parseRange(fragment.optString("interval", "1-30"), "fragment.interval", 0, 2000);
                    frag = true;
                }
            }
            outboundMap.put(tag, new Outbound(tag, protocol, frag, length, interval));
        }
        if (outboundMap.isEmpty()) throw new JSONException("هیچ outbound قابل‌استفاده‌ای پیدا نشد.");

        List<RouteRule> routeRules = new ArrayList<>();
        JSONObject routing = root.optJSONObject("routing");
        JSONArray rules = routing == null ? null : routing.optJSONArray("rules");
        if (rules != null) {
            for (int i = 0; i < rules.length(); i++) {
                JSONObject item = rules.optJSONObject(i);
                if (item == null || !"field".equalsIgnoreCase(item.optString("type", "field"))) continue;
                String tag = item.optString("outboundTag", "");
                if (!outboundMap.containsKey(tag)) throw new JSONException("outboundTag ناشناخته: " + tag);
                RouteRule rule = new RouteRule(tag);
                addDomainRules(rule, item.optJSONArray("domain"));
                addIpRules(rule, item.optJSONArray("ip"));
                String network = item.optString("network", "");
                if (!network.isEmpty()) {
                    for (String n : network.split(",")) {
                        String value = n.trim().toLowerCase(Locale.US);
                        if (!value.equals("tcp") && !value.equals("udp")) throw new JSONException("network فقط tcp/udp را می‌پذیرد.");
                        rule.networks.add(value);
                    }
                }
                routeRules.add(rule);
            }
        }
        return new FragoConfig(port, doh, ipv4, hosts, routeRules, outboundMap, defaultTag);
    }

    private static List<HostOverride> parseHosts(JSONObject object) throws JSONException {
        List<HostOverride> result = new ArrayList<>();
        if (object == null) return result;
        java.util.Iterator<String> keys = object.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            String patternText = key.startsWith("regexp:") ? key.substring(7) : Pattern.quote(key);
            Pattern pattern;
            try { pattern = Pattern.compile(patternText, Pattern.CASE_INSENSITIVE); }
            catch (PatternSyntaxException e) { throw new JSONException("Regex نامعتبر در dns.hosts: " + key); }
            JSONArray values = object.optJSONArray(key);
            List<String> addresses = new ArrayList<>();
            if (values != null) {
                for (int i = 0; i < values.length(); i++) {
                    String address = values.optString(i, "");
                    try {
                        InetAddress parsed = InetAddress.getByName(address);
                        if (parsed.getAddress().length == 4) addresses.add(parsed.getHostAddress());
                    } catch (Exception ignored) { }
                }
            } else if (object.opt(key) instanceof String) {
                addresses.add(object.optString(key));
            }
            if (!addresses.isEmpty()) result.add(new HostOverride(pattern, addresses));
        }
        return result;
    }

    private static void addDomainRules(RouteRule rule, JSONArray domains) throws JSONException {
        if (domains == null) return;
        for (int i = 0; i < domains.length(); i++) {
            String d = domains.optString(i, "");
            if (d.startsWith("regexp:")) {
                try { rule.domains.add(Pattern.compile(d.substring(7), Pattern.CASE_INSENSITIVE)); }
                catch (PatternSyntaxException e) { throw new JSONException("قانون دامنه regex نامعتبر است: " + d); }
            } else if (d.startsWith("domain:")) {
                String suffix = d.substring(7).toLowerCase(Locale.US);
                rule.domains.add(Pattern.compile("(^|\\.)" + Pattern.quote(suffix) + "$", Pattern.CASE_INSENSITIVE));
            } else if (d.startsWith("full:")) {
                rule.domains.add(Pattern.compile("^" + Pattern.quote(d.substring(5)) + "$", Pattern.CASE_INSENSITIVE));
            } else {
                throw new JSONException("نوع قانون دامنه پشتیبانی‌نشده است: " + d);
            }
        }
    }

    private static void addIpRules(RouteRule rule, JSONArray ips) throws JSONException {
        if (ips == null) return;
        for (int i = 0; i < ips.length(); i++) {
            String value = ips.optString(i, "");
            try { rule.ips.add(new Cidr(value)); }
            catch (Exception e) { throw new JSONException("CIDR نامعتبر یا پشتیبانی‌نشده: " + value); }
        }
    }

    private static Range parseRange(String value, String name, int minAllowed, int maxAllowed) throws JSONException {
        String[] parts = value.split("-", 2);
        try {
            int min = Integer.parseInt(parts[0].trim());
            int max = parts.length == 1 ? min : Integer.parseInt(parts[1].trim());
            if (min < minAllowed || max > maxAllowed || min > max) throw new NumberFormatException();
            return new Range(min, max);
        } catch (NumberFormatException e) { throw new JSONException(name + " باید بازه معتبر باشد (" + minAllowed + " تا " + maxAllowed + ")."); }
    }

    public Outbound chooseOutbound(String host, InetAddress destination, String network) {
        for (RouteRule rule : routes) {
            if (rule.matches(host, destination, network)) return outbounds.get(rule.outboundTag);
        }
        return outbounds.get(defaultOutbound);
    }

    public List<String> overrideAddresses(String host) {
        for (HostOverride h : hostOverrides) if (h.matches(host)) return h.addresses;
        return null;
    }
}
