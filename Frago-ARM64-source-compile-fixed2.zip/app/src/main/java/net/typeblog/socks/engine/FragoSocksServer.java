package net.typeblog.socks.engine;

import android.net.VpnService;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Set;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;

/** Small local SOCKS5 server used by tun2socks; it has no proxy-core dependency. */
public final class FragoSocksServer {
    private static final String TAG = "FragoSOCKS";
    private static final int MAX_INITIAL_DATA = 65540;

    private final VpnService vpn;
    private final FragoConfig config;
    private final FragoDnsProxy dns;
    private volatile boolean running;
    private ServerSocket listener;
    private Thread acceptThread;
    private final ExecutorService clients = Executors.newFixedThreadPool(16);
    private final Set<Socket> activeSockets = Collections.newSetFromMap(new ConcurrentHashMap<>());

    public FragoSocksServer(VpnService vpn, FragoConfig config, FragoDnsProxy dns) {
        this.vpn = vpn;
        this.config = config;
        this.dns = dns;
    }

    public synchronized void start() throws Exception {
        if (running) return;
        ServerSocket server = new ServerSocket();
        server.setReuseAddress(true);
        server.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), config.socksPort), 64);
        listener = server;
        running = true;
        acceptThread = new Thread(this::acceptLoop, "Frago-SOCKS-Accept");
        acceptThread.setDaemon(true);
        acceptThread.start();
    }

    public synchronized void stop() {
        running = false;
        ServerSocket current = listener;
        listener = null;
        if (current != null) {
            try { current.close(); } catch (Exception ignored) { }
        }
        for (Socket socket : activeSockets) close(socket);
        activeSockets.clear();
        clients.shutdownNow();
        if (acceptThread != null) acceptThread.interrupt();
        acceptThread = null;
    }

    private void acceptLoop() {
        while (running) {
            try {
                final Socket client = listener.accept();
                client.setTcpNoDelay(true);
                activeSockets.add(client);
                try {
                    clients.execute(() -> handle(client));
                } catch (Exception rejected) {
                    activeSockets.remove(client);
                    close(client);
                    if (running) throw rejected;
                }
            } catch (Exception e) {
                if (running) Log.w(TAG, "SOCKS accept failed", e);
            }
        }
    }

    private void handle(Socket client) {
        Socket remote = null;
        try {
            client.setSoTimeout(15000);
            InputStream clientIn = client.getInputStream();
            OutputStream clientOut = client.getOutputStream();

            int version = readU8(clientIn);
            if (version != 5) throw new IOExceptionCompat("Not a SOCKS5 client");
            int methodCount = readU8(clientIn);
            byte[] methods = readExact(clientIn, methodCount);
            boolean noAuth = false;
            for (byte method : methods) if ((method & 0xff) == 0) noAuth = true;
            clientOut.write(new byte[]{5, (byte) (noAuth ? 0 : 0xff)});
            clientOut.flush();
            if (!noAuth) return;

            int reqVersion = readU8(clientIn);
            int command = readU8(clientIn);
            readU8(clientIn); // reserved
            int atyp = readU8(clientIn);
            if (reqVersion != 5 || command != 1) {
                reply(clientOut, 7);
                return;
            }

            String targetHost;
            InetAddress targetAddress = null;
            if (atyp == 1) {
                targetAddress = InetAddress.getByAddress(readExact(clientIn, 4));
                targetHost = targetAddress.getHostAddress();
            } else if (atyp == 4) {
                targetAddress = InetAddress.getByAddress(readExact(clientIn, 16));
                targetHost = targetAddress.getHostAddress();
            } else if (atyp == 3) {
                int length = readU8(clientIn);
                targetHost = new String(readExact(clientIn, length), StandardCharsets.US_ASCII);
            } else {
                reply(clientOut, 8);
                return;
            }
            int targetPort = (readU8(clientIn) << 8) | readU8(clientIn);
            if (targetPort < 1) {
                reply(clientOut, 1);
                return;
            }

            List<InetAddress> targets;
            if (targetAddress != null) {
                targets = java.util.Collections.singletonList(targetAddress);
            } else {
                targets = dns.resolveA(targetHost);
            }

            FragoConfig.Outbound initialRoute = config.chooseOutbound(targetHost, targets.get(0), "tcp");
            if (initialRoute == null || "blackhole".equals(initialRoute.protocol)) {
                reply(clientOut, 2);
                return;
            }

            Exception connectFailure = null;
            for (InetAddress address : targets) {
                Socket candidate = new Socket();
                activeSockets.add(candidate);
                try {
                    if (!vpn.protect(candidate)) throw new IllegalStateException("Could not protect outgoing socket from VPN loop");
                    candidate.setTcpNoDelay(true);
                    candidate.connect(new InetSocketAddress(address, targetPort), 12000);
                    remote = candidate;
                    targetAddress = address;
                    break;
                } catch (Exception e) {
                    activeSockets.remove(candidate);
                    connectFailure = e;
                    try { candidate.close(); } catch (Exception ignored) { }
                }
            }
            if (remote == null) {
                reply(clientOut, 5);
                if (connectFailure != null) Log.d(TAG, "Direct connect failed", connectFailure);
                return;
            }

            reply(clientOut, 0);
            client.setSoTimeout(6000);
            byte[] first = readInitialPayload(client);
            client.setSoTimeout(0);

            String sniffedHost = sniffHost(first);
            String routeHost = sniffedHost == null ? targetHost : sniffedHost;
            FragoConfig.Outbound outbound = config.chooseOutbound(routeHost, targetAddress, "tcp");
            if (outbound == null || "blackhole".equals(outbound.protocol)) return;

            OutputStream remoteOut = remote.getOutputStream();
            if (first.length > 0) {
                if (outbound.fragmentTlsHello && isTlsClientHello(first)) {
                    sendFragmented(remoteOut, first, outbound.length, outbound.interval);
                } else {
                    remoteOut.write(first);
                    remoteOut.flush();
                }
            }

            final Socket upstream = remote;
            final Socket downstream = client;
            Thread reverse = new Thread(() -> copy(upstream, downstream, false), "Frago-SOCKS-Down");
            reverse.setDaemon(true);
            reverse.start();
            copy(client, remote, true);
            try { reverse.join(3000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        } catch (Exception e) {
            if (running) Log.d(TAG, "SOCKS session ended", e);
        } finally {
            if (remote != null) activeSockets.remove(remote);
            activeSockets.remove(client);
            close(remote);
            close(client);
        }
    }

    private static byte[] readInitialPayload(Socket client) throws Exception {
        InputStream in = client.getInputStream();
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        client.setSoTimeout(6000);
        byte[] first = readAtMost(in, 5, 6000);
        data.write(first);
        if (first.length == 5 && (first[0] & 0xff) == 0x16
                && (first[1] & 0xff) == 0x03) {
            int recordLength = ((first[3] & 0xff) << 8) | (first[4] & 0xff);
            if (recordLength > 0 && recordLength <= MAX_INITIAL_DATA - 5) {
                byte[] rest = readAtMost(in, recordLength, 5000);
                data.write(rest);
            }
            return data.toByteArray();
        }
        // For HTTP sniffing, collect only the initial header; other protocols are passed through.
        client.setSoTimeout(150);
        long deadline = java.lang.System.currentTimeMillis() + 250;
        while (data.size() < 8192 && java.lang.System.currentTimeMillis() < deadline) {
            if (containsHeaderEnd(data.toByteArray())) break;
            int wait = (int) Math.max(1, deadline - java.lang.System.currentTimeMillis());
            byte[] more = readAtMost(in, Math.min(1024, 8192 - data.size()), wait);
            if (more.length == 0) break;
            data.write(more);
        }
        return data.toByteArray();
    }

    private static byte[] readAtMost(InputStream in, int count, int timeoutMs) throws Exception {
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        byte[] buffer = new byte[Math.min(4096, Math.max(1, count))];
        long oldDeadline = java.lang.System.currentTimeMillis() + timeoutMs;
        while (data.size() < count) {
            try {
                int read = in.read(buffer, 0, Math.min(buffer.length, count - data.size()));
                if (read < 0) break;
                if (read == 0) continue;
                data.write(buffer, 0, read);
            } catch (SocketTimeoutException e) {
                break;
            }
            if (java.lang.System.currentTimeMillis() > oldDeadline) break;
        }
        return data.toByteArray();
    }

    private static String sniffHost(byte[] data) {
        String sni = readSni(data);
        if (sni != null) return sni;
        String text = new String(data, StandardCharsets.ISO_8859_1);
        int end = text.indexOf("\r\n\r\n");
        if (end < 0) end = text.length();
        String[] lines = text.substring(0, end).split("\r\n");
        for (String line : lines) {
            int colon = line.indexOf(':');
            if (colon > 0 && "host".equalsIgnoreCase(line.substring(0, colon).trim())) {
                String host = line.substring(colon + 1).trim();
                int port = host.lastIndexOf(':');
                if (port > 0 && host.indexOf(']') < port) host = host.substring(0, port);
                return host.toLowerCase(java.util.Locale.US);
            }
        }
        return null;
    }

    private static String readSni(byte[] record) {
        try {
            if (record.length < 9 || (record[0] & 0xff) != 0x16 || (record[5] & 0xff) != 1) return null;
            int p = 9; // TLS record header + ClientHello handshake header
            p += 2 + 32;
            int sessionLength = record[p++] & 0xff;
            p += sessionLength;
            int cipherLength = u16(record, p); p += 2 + cipherLength;
            int compressionLength = record[p++] & 0xff; p += compressionLength;
            if (p + 2 > record.length) return null;
            int extensionsLength = u16(record, p); p += 2;
            int extensionsEnd = Math.min(record.length, p + extensionsLength);
            while (p + 4 <= extensionsEnd) {
                int type = u16(record, p); int size = u16(record, p + 2); p += 4;
                int next = p + size;
                if (next > extensionsEnd) return null;
                if (type == 0 && p + 5 <= next) {
                    int listEnd = p + 2 + u16(record, p);
                    int q = p + 2;
                    while (q + 3 <= listEnd && q + 3 <= next) {
                        int nameType = record[q++] & 0xff;
                        int nameLength = u16(record, q); q += 2;
                        if (q + nameLength > listEnd || q + nameLength > next) return null;
                        if (nameType == 0) return new String(record, q, nameLength, StandardCharsets.US_ASCII)
                                .toLowerCase(java.util.Locale.US);
                        q += nameLength;
                    }
                }
                p = next;
            }
        } catch (Exception ignored) { }
        return null;
    }

    private static boolean isTlsClientHello(byte[] data) {
        return data.length >= 9 && (data[0] & 0xff) == 0x16
                && (data[1] & 0xff) == 0x03 && (data[5] & 0xff) == 1;
    }

    private static void sendFragmented(OutputStream out, byte[] data,
                                       FragoConfig.Range length, FragoConfig.Range interval) throws Exception {
        int offset = 0;
        while (offset < data.length) {
            int count = Math.min(length.random(), data.length - offset);
            out.write(data, offset, count);
            out.flush();
            offset += count;
            if (offset < data.length) Thread.sleep(interval.random());
        }
    }

    private static void copy(Socket from, Socket to, boolean shutdownDestinationOutput) {
        try {
            InputStream in = from.getInputStream();
            OutputStream out = to.getOutputStream();
            byte[] buffer = new byte[16 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
                out.flush();
            }
        } catch (Exception ignored) {
        } finally {
            if (shutdownDestinationOutput) {
                try { to.shutdownOutput(); } catch (Exception ignored) { }
            } else {
                try { to.shutdownOutput(); } catch (Exception ignored) { }
            }
        }
    }

    private static boolean containsHeaderEnd(byte[] data) {
        if (data.length < 4) return false;
        for (int i = 3; i < data.length; i++) {
            if (data[i - 3] == '\r' && data[i - 2] == '\n' && data[i - 1] == '\r' && data[i] == '\n') return true;
        }
        return false;
    }

    private static int readU8(InputStream in) throws Exception {
        int value = in.read();
        if (value < 0) throw new EOFException();
        return value;
    }

    private static byte[] readExact(InputStream in, int count) throws Exception {
        byte[] result = new byte[count];
        int offset = 0;
        while (offset < count) {
            int n = in.read(result, offset, count - offset);
            if (n < 0) throw new EOFException();
            offset += n;
        }
        return result;
    }

    private static void reply(OutputStream out, int status) throws Exception {
        out.write(new byte[]{5, (byte) status, 0, 1, 0, 0, 0, 0, 0, 0});
        out.flush();
    }

    private static int u16(byte[] bytes, int pos) {
        return ((bytes[pos] & 0xff) << 8) | (bytes[pos + 1] & 0xff);
    }

    private static void close(Socket socket) {
        if (socket != null) try { socket.close(); } catch (Exception ignored) { }
    }

    private static final class IOExceptionCompat extends Exception {
        IOExceptionCompat(String message) { super(message); }
    }
}
