# Frago (ARM64)

Frago is a small Android VPN front-end for one deliberately limited JSON profile format. It keeps the existing ARM64 `tun2socks` bridge and implements the local SOCKS5 endpoint and DNS-over-HTTPS gateway in Java. The application uses no external proxy runtime; only the local Frago SOCKS5 server, DoH gateway and existing ARM64 tunnel bridge are included.

## Target

- Samsung Galaxy A36 / A56 and other Android ARM64 (`arm64-v8a`) devices
- Android API 24 or newer
- Release APK is optimized with R8 and resource shrinking
- GitHub Actions reports the APK size and targets 2 MiB maximum

## Importing a profile

1. Build and install the `Frago-ARM64-APK` artifact from GitHub Actions.
2. Open Frago and select **Import JSON file**.
3. Select a JSON file that uses the subset documented below.
4. Turn on the VPN switch and approve Android's VPN permission prompt.

Only JSON file import is exposed. There is no share-link importer and no separate remote SOCKS server form. The JSON's `socks` inbound defines Frago's local SOCKS5 port; the app's local SOCKS server connects directly to destination servers.

## Supported JSON subset

- `inbounds`: one `protocol: "socks"` entry listening on `127.0.0.1`, with a valid port.
- `dns.servers`: HTTPS DoH endpoint, queried using RFC 8484 `application/dns-message` POST.
- `dns.queryStrategy`: `UseIPv4`.
- `dns.hosts`: literal IPv4 address arrays and regular-expression keys such as `regexp:(google)`. Matching A queries receive all configured IPv4 addresses.
- `outbounds`: `freedom` and `blackhole` only. The `freedom.settings.fragment` subset supports `packets: "tlshello"`, `length`, and `interval` ranges.
- `routing.rules`: `type: "field"`, `domain` (`regexp:`, `domain:`, `full:`), numeric `ip` CIDRs, `network: "tcp"` / `"udp"`, and `outboundTag`.

For the supplied profile, non-overridden DNS queries go to `https://kid.openbld.net/dns-query`. Queries whose names match `regexp:(google)` are answered locally with both `65.109.184.128` and `91.107.241.144`; those matching A queries do not need an upstream DoH request. The `.ir` domain and private IP rules select the non-fragmented `direct` outbound. Other TCP traffic selects `fragment-out`; the local SOCKS bridge identifies HTTP Host and TLS SNI where available, then sends the initial TLS ClientHello in randomized write chunks with the configured delays.

## Important limitations

- This is not a general interpreter for every possible option in the wider JSON ecosystem. Unsupported outbound protocols or routing syntax are rejected during import instead of silently ignored.
- The inherited `tun2socks` bridge carries TCP and redirects ordinary UDP DNS packets to Frago's DoH gateway. It does not provide general UDP forwarding or SOCKS5 UDP ASSOCIATE. Thus the JSON `network: "udp"` rule is parsed, but arbitrary UDP applications (including QUIC/HTTP3) are not relayed by this build.
- TLS chunked writes plus delays request TCP segmentation, but the Android/Linux network stack and network path can coalesce or segment data differently. The app cannot guarantee a particular on-wire packet boundary.
- DNS-over-HTTPS bootstrap uses Android's normal network resolver from Frago's own process. Frago is excluded from its own VPN to prevent a DNS recursion loop.

## Build

Open the repository in Android Studio or push it to GitHub. The workflow `.github/workflows/build-arm64-apk.yml` builds the optimized release variant directly. It installs only the Android SDK platform/build tools, then runs Gradle. It does not download or package an external proxy engine.

The generated APK is `app/build/outputs/apk/release/app-release.apk` and is uploaded as the Actions artifact `Frago-ARM64-APK`.

## Frago per-app routing update

The Settings screen now includes **Choose apps for VPN**. Select one or more launcher apps to use Android's allow-list VPN mode. If no apps are selected, Frago uses the system-wide VPN mode while excluding Frago itself so its DoH requests do not loop back into the VPN.

The JSON inbound remains the local SOCKS5 endpoint (127.0.0.1 and the configured port). Frago's built-in SOCKS5 server accepts connections from tun2socks and applies the JSON routing and TLS ClientHello write-splitting rules. This is not an external SOCKS5 upstream-proxy form.

Limitations: the current tun2socks bridge handles TCP plus DNS redirection; it does not provide general UDP/QUIC forwarding. TLS fragmentation is implemented as segmented TCP writes of the initial ClientHello bytes, and network-level packet boundaries are controlled by the OS/TCP stack. The project has not been validated on a physical Samsung device in this environment.
