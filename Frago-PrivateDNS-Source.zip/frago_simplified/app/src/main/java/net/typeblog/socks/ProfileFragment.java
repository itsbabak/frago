package net.typeblog.socks;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.VpnService;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import net.typeblog.socks.util.Profile;
import net.typeblog.socks.util.ProfileManager;
import net.typeblog.socks.util.ProxyUriConfig;
import net.typeblog.socks.util.Utility;
import net.typeblog.socks.util.XrayConfig;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static net.typeblog.socks.util.Constants.*;

/** One-page Frago settings: local SOCKS input, one of three Xray outputs, and app selection. */
public class ProfileFragment extends PreferenceFragment implements
        Preference.OnPreferenceClickListener,
        Preference.OnPreferenceChangeListener,
        CompoundButton.OnCheckedChangeListener {

    private static final int REQUEST_VPN_PERMISSION = 0;
    private static final long STATE_REFRESH_MS = 5000L;

    private ProfileManager mManager;
    private Profile mProfile;
    private Switch mSwitch;
    private boolean mRunning;
    private boolean mStarting;
    private boolean mStopping;
    private boolean mBound;
    private boolean mUiResumed;
    private IVpnService mBinder;

    private ListPreference mPrefProfile;
    private ListPreference mPrefOutputType;
    private CheckBoxPreference mPrefPerApp;
    private CheckBoxPreference mPrefAppBypass;
    private CheckBoxPreference mPrefPrivateDnsEnabled;
    private Preference mPrefPrivateDnsAddress;
    private Preference mPrefSocksInput;
    private Preference mPrefOutputConfig;
    private Preference mPrefOutputStatus;
    private Preference mPrefAppPicker;
    private Preference mPrefAddProfile;
    private Preference mPrefDeleteProfile;

    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            mBinder = IVpnService.Stub.asInterface(binder);
            updateState();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mBinder = null;
            updateState();
        }
    };

    private final Runnable mStateRunnable = new Runnable() {
        @Override
        public void run() {
            if (mSwitch == null || !mUiResumed) return;
            updateState();
            mSwitch.postDelayed(this, STATE_REFRESH_MS);
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings_single);
        mManager = new ProfileManager(getActivity().getApplicationContext());
        initPreferences();
        reload();
    }

    private void initPreferences() {
        mPrefProfile = (ListPreference) findPreference(PREF_PROFILE);
        mPrefOutputType = (ListPreference) findPreference("output_type");
        mPrefPerApp = (CheckBoxPreference) findPreference(PREF_ADV_PER_APP);
        mPrefAppBypass = (CheckBoxPreference) findPreference(PREF_ADV_APP_BYPASS);
        mPrefPrivateDnsEnabled = (CheckBoxPreference) findPreference("private_dns_enabled");
        mPrefPrivateDnsAddress = findPreference("private_dns_address");
        mPrefSocksInput = findPreference("socks_input");
        mPrefOutputConfig = findPreference("output_config");
        mPrefOutputStatus = findPreference("output_status");
        mPrefAppPicker = findPreference("adv_app_picker");
        mPrefAddProfile = findPreference("profile_add");
        mPrefDeleteProfile = findPreference("profile_delete");

        setChangeListener(mPrefProfile);
        setChangeListener(mPrefOutputType);
        setChangeListener(mPrefPerApp);
        setChangeListener(mPrefAppBypass);
        setChangeListener(mPrefPrivateDnsEnabled);

        setClickListener(mPrefOutputConfig);
        setClickListener(mPrefPrivateDnsAddress);
        setClickListener(mPrefAppPicker);
        setClickListener(mPrefAddProfile);
        setClickListener(mPrefDeleteProfile);
    }

    private void setChangeListener(Preference preference) {
        if (preference != null) preference.setOnPreferenceChangeListener(this);
    }

    private void setClickListener(Preference preference) {
        if (preference != null) preference.setOnPreferenceClickListener(this);
    }

    @Override
    public boolean onPreferenceClick(Preference preference) {
        if (preference == mPrefOutputConfig) {
            configureSelectedOutput();
            return true;
        }
        if (preference == mPrefPrivateDnsAddress) {
            editPrivateDnsAddress();
            return true;
        }
        if (preference == mPrefAppPicker) {
            showAppPicker();
            return true;
        }
        if (preference == mPrefAddProfile) {
            addProfile();
            return true;
        }
        if (preference == mPrefDeleteProfile) {
            removeProfile();
            return true;
        }
        return false;
    }

    @Override
    public boolean onPreferenceChange(Preference preference, Object newValue) {
        if (preference == mPrefProfile) {
            String name = String.valueOf(newValue);
            Profile selected = mManager.getProfile(name);
            if (selected == null) return false;
            mProfile = selected;
            mManager.switchDefault(name);
            reload();
            return true;
        }
        if (preference == mPrefOutputType) {
            String type = String.valueOf(newValue);
            if (!isSupportedOutput(type)) return false;
            mProfile.setOutputType(type);
            resetOutputTypeSummary(type);
            updateOutputSummary();
            return true;
        }
        if (preference == mPrefPerApp) {
            boolean enabled = Boolean.parseBoolean(String.valueOf(newValue));
            mProfile.setIsPerApp(enabled);
            return true;
        }
        if (preference == mPrefAppBypass) {
            mProfile.setIsBypassApp(Boolean.parseBoolean(String.valueOf(newValue)));
            return true;
        }
        if (preference == mPrefPrivateDnsEnabled) {
            boolean enabled = Boolean.parseBoolean(String.valueOf(newValue));
            mProfile.setPrivateDnsEnabled(enabled);
            updatePrivateDnsSummary();
            if (enabled && TextUtils.isEmpty(mProfile.getPrivateDnsAddress())) {
                Toast.makeText(getActivity(),
                        "Enter a DNS-over-HTTPS address below to use Private DNS.",
                        Toast.LENGTH_LONG).show();
            }
            return true;
        }
        return false;
    }

    @Override
    public void onResume() {
        super.onResume();
        mUiResumed = true;
        if (getActivity() instanceof MainActivity) {
            mSwitch = ((MainActivity) getActivity()).getVpnSwitch();
            if (mSwitch != null) {
                mSwitch.setOnCheckedChangeListener(this);
                mSwitch.removeCallbacks(mStateRunnable);
                mSwitch.post(mStateRunnable);
            }
        }
        checkState();
    }

    @Override
    public void onPause() {
        mUiResumed = false;
        if (mSwitch != null) {
            mSwitch.removeCallbacks(mStateRunnable);
            mSwitch.setOnCheckedChangeListener(null);
        }
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        if (mSwitch != null) {
            mSwitch.removeCallbacks(mStateRunnable);
            mSwitch.setOnCheckedChangeListener(null);
            mSwitch = null;
        }
        if (mBound) {
            try { getActivity().unbindService(mConnection); }
            catch (Exception ignored) { }
            mBound = false;
            mBinder = null;
        }
        super.onDestroyView();
    }

    @Override
    public void onCheckedChanged(CompoundButton button, boolean checked) {
        if (checked) startVpn();
        else stopVpn();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_VPN_PERMISSION) return;
        if (resultCode == Activity.RESULT_OK) {
            Utility.startVpn(getActivity(), mProfile);
            checkState();
        } else {
            mStarting = false;
            updateState();
        }
    }

    private void configureSelectedOutput() {
        String type = mProfile.getOutputType();
        if ("json".equals(type)) editJsonManually();
        else if ("shadowsocks".equals(type)) editShareLink("shadowsocks");
        else if ("vless".equals(type)) editShareLink("vless");
        else {
            mProfile.setOutputType("json");
            editJsonManually();
        }
    }

    private void editJsonManually() {
        String current = mProfile.getXrayConfig();
        if (TextUtils.isEmpty(current)) {
            current = "{\n"
                    + "  \"log\": {\n    \"loglevel\": \"warning\"\n  },\n"
                    + "  \"inbounds\": [\n"
                    + "    {\n      \"tag\": \"frago-socks-in\",\n"
                    + "      \"listen\": \"127.0.0.1\",\n      \"port\": 10808,\n"
                    + "      \"protocol\": \"socks\",\n      \"settings\": { \"auth\": \"noauth\" }\n    }\n"
                    + "  ],\n  \"outbounds\": [\n"
                    + "    {\n      \"tag\": \"proxy\",\n      \"protocol\": \"freedom\"\n    }\n  ]\n}";
        }

        final EditText editor = createEditor(current, "Paste or type the complete Xray JSON here");
        editor.setMinLines(16);
        editor.setMaxLines(28);
        new AlertDialog.Builder(getActivity())
                .setTitle("JSON / Fragment configuration")
                .setView(editor)
                .setPositiveButton("Save", (dialog, which) -> saveJson(editor.getText().toString()))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void editShareLink(String output) {
        final EditText editor = createEditor("", "Paste "
                + ("vless".equals(output) ? "vless://..." : "ss://...")
                + " link manually");
        editor.setMinLines(3);
        editor.setMaxLines(8);
        new AlertDialog.Builder(getActivity())
                .setTitle("Add " + ("vless".equals(output) ? "VLESS" : "Shadowsocks"))
                .setView(editor)
                .setPositiveButton("Save", (dialog, which) -> {
                    String link = editor.getText().toString().trim();
                    String expectedPrefix = "vless".equals(output) ? "vless://" : "ss://";
                    if (!link.toLowerCase(java.util.Locale.US).startsWith(expectedPrefix)
                            && !("shadowsocks".equals(output)
                            && link.toLowerCase(java.util.Locale.US).startsWith("shadowsocks://"))) {
                        showError("Please enter a valid " + output + " share link.");
                        return;
                    }
                    try {
                        String json = ProxyUriConfig.toXrayJson(link);
                        saveJson(json, output);
                    } catch (Exception e) {
                        showError(e.getMessage());
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void editPrivateDnsAddress() {
        final EditText editor = createEditor(mProfile.getPrivateDnsAddress(),
                "https://dns.google/dns-query or dns.example/dns-query");
        editor.setSingleLine(true);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        new AlertDialog.Builder(getActivity())
                .setTitle("Private DNS · DoH")
                .setMessage("Use an HTTPS DNS-over-HTTPS endpoint. When enabled, Frago applies it to the active JSON, Shadowsocks or VLESS connection.")
                .setView(editor)
                .setPositiveButton("Save", (dialog, which) -> {
                    try {
                        String normalized = XrayConfig.normalizePrivateDnsAddress(
                                editor.getText().toString());
                        mProfile.setPrivateDnsAddress(normalized);
                        updatePrivateDnsSummary();
                        Toast.makeText(getActivity(), "Private DNS address saved.",
                                Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        showError(e.getMessage());
                    }
                })
                .setNeutralButton("Clear", (dialog, which) -> {
                    mProfile.setPrivateDnsAddress("");
                    updatePrivateDnsSummary();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private EditText createEditor(String value, String hint) {
        EditText editor = new EditText(getActivity());
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        editor.setTypeface(android.graphics.Typeface.MONOSPACE);
        editor.setText(value);
        editor.setHint(hint);
        editor.setSelection(editor.length());
        int padding = (int) (16 * getResources().getDisplayMetrics().density);
        editor.setPadding(padding, padding, padding, padding);
        return editor;
    }

    private void saveJson(String raw) {
        saveJson(raw, "json");
    }

    private void saveJson(String raw, String outputType) {
        try {
            XrayConfig.Prepared prepared = XrayConfig.prepare(raw);
            mProfile.setXrayConfig(prepared.json);
            mProfile.setOutputType(outputType);
            mProfile.setXrayMode(true);
            reload();
            Toast.makeText(getActivity(), "Configuration saved. SOCKS input: 127.0.0.1:"
                    + prepared.socksPort, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            showError(e.getMessage());
        }
    }

    private void showError(String message) {
        Toast.makeText(getActivity(), "Invalid configuration: "
                + (TextUtils.isEmpty(message) ? "unknown error" : message), Toast.LENGTH_LONG).show();
    }

    private void showAppPicker() {
        final PackageManager packageManager = getActivity().getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN, null);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> resolved = packageManager.queryIntentActivities(launcher, 0);
        Collections.sort(resolved, new ResolveInfo.DisplayNameComparator(packageManager));

        final List<String> packages = new ArrayList<>();
        final List<CharSequence> labels = new ArrayList<>();
        Set<String> selected = new HashSet<>();
        String saved = mProfile.getAppList();
        if (!TextUtils.isEmpty(saved)) {
            for (String item : saved.split("\\n")) {
                if (!TextUtils.isEmpty(item.trim())) selected.add(item.trim());
            }
        }

        for (ResolveInfo info : resolved) {
            if (info.activityInfo == null) continue;
            String packageName = info.activityInfo.packageName;
            if (packageName.equals(getActivity().getPackageName()) || packages.contains(packageName)) continue;
            packages.add(packageName);
            labels.add(info.loadLabel(packageManager));
        }
        if (packages.isEmpty()) {
            Toast.makeText(getActivity(), "No launchable apps were found.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean[] checked = new boolean[packages.size()];
        for (int i = 0; i < packages.size(); i++) checked[i] = selected.contains(packages.get(i));
        new AlertDialog.Builder(getActivity())
                .setTitle("Choose apps")
                .setMultiChoiceItems(labels.toArray(new CharSequence[0]), checked,
                        (dialog, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton("Save", (dialog, which) -> {
                    StringBuilder list = new StringBuilder();
                    for (int i = 0; i < packages.size(); i++) {
                        if (checked[i]) {
                            if (list.length() > 0) list.append('\n');
                            list.append(packages.get(i));
                        }
                    }
                    mProfile.setAppList(list.toString());
                    mProfile.setIsPerApp(true);
                    if (mPrefPerApp != null) mPrefPerApp.setChecked(true);
                    updateAppPickerSummary();
                    Toast.makeText(getActivity(), "App selection saved.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void reload() {
        if (mProfile == null) mProfile = mManager.getDefault();
        if (mProfile == null) return;

        if (mPrefProfile != null) {
            String[] profiles = mManager.getProfiles();
            mPrefProfile.setEntries(profiles);
            mPrefProfile.setEntryValues(profiles);
            mPrefProfile.setValue(mProfile.getName());
            mPrefProfile.setSummary(mProfile.getName());
        }
        if (mPrefOutputType != null) {
            String type = mProfile.getOutputType();
            if (!isSupportedOutput(type)) type = "json";
            mPrefOutputType.setValue(type);
            resetOutputTypeSummary(type);
        }
        if (mPrefPerApp != null) mPrefPerApp.setChecked(mProfile.isPerApp());
        if (mPrefAppBypass != null) mPrefAppBypass.setChecked(mProfile.isBypassApp());
        if (mPrefPrivateDnsEnabled != null) mPrefPrivateDnsEnabled.setChecked(mProfile.isPrivateDnsEnabled());
        updatePrivateDnsSummary();
        updateOutputSummary();
        updateAppPickerSummary();
    }

    private void resetOutputTypeSummary(String type) {
        if (mPrefOutputType == null) return;
        int index = mPrefOutputType.findIndexOfValue(type);
        CharSequence[] entries = mPrefOutputType.getEntries();
        if (index >= 0 && index < entries.length) mPrefOutputType.setSummary(entries[index]);
    }

    private void updateOutputSummary() {
        if (mPrefSocksInput != null) {
            String config = mProfile.getXrayConfig();
            if (TextUtils.isEmpty(config)) {
                mPrefSocksInput.setSummary("127.0.0.1:10808 · created automatically when the output is configured");
            } else {
                try {
                    XrayConfig.Prepared prepared = XrayConfig.prepare(config);
                    mPrefSocksInput.setSummary("127.0.0.1:" + prepared.socksPort
                            + " · private local input for VPN traffic");
                } catch (Exception e) {
                    mPrefSocksInput.setSummary("127.0.0.1:10808 · configure an output first");
                }
            }
        }
        if (mPrefOutputStatus != null) {
            String config = mProfile.getXrayConfig();
            if (TextUtils.isEmpty(config)) {
                mPrefOutputStatus.setSummary("Not configured");
            } else {
                try {
                    XrayConfig.Prepared prepared = XrayConfig.prepare(config);
                    mPrefOutputStatus.setSummary("Ready · SOCKS input 127.0.0.1:"
                            + prepared.socksPort);
                } catch (Exception e) {
                    mPrefOutputStatus.setSummary("Saved configuration is invalid");
                }
            }
        }
        if (mPrefOutputConfig != null) {
            String type = mProfile.getOutputType();
            if ("shadowsocks".equals(type)) mPrefOutputConfig.setSummary("Paste an ss:// link manually");
            else if ("vless".equals(type)) mPrefOutputConfig.setSummary("Paste a vless:// link manually");
            else mPrefOutputConfig.setSummary("Enter or edit full JSON manually · no file import");
        }
    }

    private void updatePrivateDnsSummary() {
        if (mPrefPrivateDnsAddress == null || mProfile == null) return;
        String address = mProfile.getPrivateDnsAddress();
        boolean enabled = mProfile.isPrivateDnsEnabled();
        mPrefPrivateDnsAddress.setEnabled(true);
        if (TextUtils.isEmpty(address)) {
            mPrefPrivateDnsAddress.setSummary(enabled
                    ? "Enabled · address required · tap to enter a DoH URL"
                    : "Disabled · tap to enter an address");
        } else {
            mPrefPrivateDnsAddress.setSummary((enabled ? "Enabled · " : "Saved · ") + address);
        }
    }

    private void updateAppPickerSummary() {
        if (mPrefAppPicker == null || mProfile == null) return;
        String apps = mProfile.getAppList();
        int count = 0;
        if (!TextUtils.isEmpty(apps)) {
            for (String item : apps.split("\\n")) if (!TextUtils.isEmpty(item.trim())) count++;
        }
        mPrefAppPicker.setSummary(count + " app(s) selected · app names only");
    }

    private boolean isSupportedOutput(String value) {
        return "json".equals(value) || "shadowsocks".equals(value) || "vless".equals(value);
    }

    private void addProfile() {
        final EditText edit = new EditText(getActivity());
        edit.setSingleLine(true);
        edit.setHint("Profile name");
        new AlertDialog.Builder(getActivity())
                .setTitle("Add profile")
                .setView(edit)
                .setPositiveButton("Save", (dialog, which) -> {
                    String name = edit.getText().toString().trim();
                    if (!TextUtils.isEmpty(name)) {
                        Profile profile = mManager.addProfile(name);
                        if (profile != null) {
                            mProfile = profile;
                            reload();
                            return;
                        }
                    }
                    Toast.makeText(getActivity(), "Could not add profile.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void removeProfile() {
        new AlertDialog.Builder(getActivity())
                .setTitle("Delete profile")
                .setMessage("Delete profile " + mProfile.getName() + "?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    if (!mManager.removeProfile(mProfile.getName())) {
                        Toast.makeText(getActivity(), "Cannot delete the default profile.", Toast.LENGTH_SHORT).show();
                    } else {
                        mProfile = mManager.getDefault();
                        reload();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void checkState() {
        if (mSwitch != null) {
            mSwitch.setEnabled(false);
            mSwitch.setOnCheckedChangeListener(null);
        }
        if (!mBound && getActivity() != null) {
            mBound = getActivity().bindService(new Intent(getActivity(), SocksVpnService.class),
                    mConnection, Context.BIND_AUTO_CREATE);
            if (!mBound) updateState();
        }
    }

    private void updateState() {
        if (mBinder == null) {
            mRunning = false;
        } else {
            try { mRunning = mBinder.isRunning(); }
            catch (Exception e) { mRunning = false; }
        }
        if (mSwitch == null) return;
        mSwitch.setOnCheckedChangeListener(null);
        mSwitch.setChecked(mRunning);
        if ((!mStarting && !mStopping) || (mStarting && mRunning) || (mStopping && !mRunning)) {
            mSwitch.setEnabled(true);
        }
        if (mStarting && mRunning) mStarting = false;
        if (mStopping && !mRunning) mStopping = false;
        mSwitch.setOnCheckedChangeListener(this);
    }

    private void startVpn() {
        if (mStarting || mRunning) return;
        if (mProfile == null || TextUtils.isEmpty(mProfile.getXrayConfig())) {
            Toast.makeText(getActivity(), "Configure JSON, Shadowsocks or VLESS output first.",
                    Toast.LENGTH_LONG).show();
            updateState();
            return;
        }
        try {
            XrayConfig.prepare(mProfile.getXrayConfig(),
                    mProfile.isPrivateDnsEnabled(), mProfile.getPrivateDnsAddress());
            mProfile.setXrayMode(true);
        } catch (Exception e) {
            showError(e.getMessage());
            updateState();
            return;
        }
        mStarting = true;
        Intent permissionIntent = VpnService.prepare(getActivity());
        if (permissionIntent != null) {
            startActivityForResult(permissionIntent, REQUEST_VPN_PERMISSION);
        } else {
            Utility.startVpn(getActivity(), mProfile);
            checkState();
        }
    }

    private void stopVpn() {
        if (mBinder == null) return;
        mStopping = true;
        try { mBinder.stop(); }
        catch (Exception ignored) { }
        updateState();
    }
}
