#!/usr/bin/env python3
"""Fast pre-build checks for the exact Frago JSON subset."""
from pathlib import Path
import json
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
config_path = ROOT / "app/src/main/assets/default-config.json"
config = json.loads(config_path.read_text(encoding="utf-8"))

assert config["dns"]["servers"] == ["https://kid.openbld.net/dns-query"]
assert config["dns"]["queryStrategy"] == "UseIPv4"
assert config["dns"]["hosts"]["regexp:(google)"] == [
    "65.109.184.128", "91.107.241.144"
]

socks = next(x for x in config["inbounds"] if x.get("protocol") == "socks")
assert socks["listen"] == "127.0.0.1" and socks["port"] == 10808
assert socks["settings"]["udp"] is True
assert socks["sniffing"]["enabled"] is True
assert "tls" in socks["sniffing"]["destOverride"]

fragment = next(x for x in config["outbounds"] if x.get("tag") == "fragment-out")
assert fragment["protocol"] == "freedom"
assert fragment["settings"]["fragment"] == {
    "packets": "tlshello", "length": "10-400", "interval": "1-30"
}
rules = config["routing"]["rules"]
assert config["routing"]["domainStrategy"] == "AsIs"
assert any(x.get("domain") == [r"regexp:.*\.ir$"] and x.get("outboundTag") == "direct" for x in rules)
assert any(x.get("ip") == ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8"] and x.get("outboundTag") == "direct" for x in rules)
assert any(x.get("network") == "tcp" and x.get("outboundTag") == "fragment-out" for x in rules)
assert any(x.get("network") == "udp" and x.get("outboundTag") == "direct" for x in rules)

manifest = ET.parse(ROOT / "app/src/main/AndroidManifest.xml").getroot()
assert manifest.find("application") is not None
service = ROOT / "app/src/main/java/net/typeblog/socks/FragoVpnService.java"
assert '.addAddress("fd26:26:26::1", 126)' in service.read_text(encoding="utf-8")
config_java = ROOT / "app/src/main/java/net/typeblog/socks/core/FragoConfig.java"
assert "ipv6: 'fd26:26:26::1'" in config_java.read_text(encoding="utf-8")
assert (ROOT / "app/src/main/java/hev/htproxy/TProxyService.java").is_file()
socks_java = ROOT / "app/src/main/java/net/typeblog/socks/core/FragoSocksServer.java"
socks_source = socks_java.read_text(encoding="utf-8")
assert "usernamePassword" in socks_source and "socksUsername.equals(username)" in socks_source
assert "new SecureRandom()" in (ROOT / "app/src/main/java/net/typeblog/socks/FragoVpnService.java").read_text(encoding="utf-8")
assert not list((ROOT / "app/src/main").rglob("libxray.so"))
assert not list((ROOT / "app/src/main").rglob("libtun2socks.so"))

print("Frago project checks passed: JSON routing, DoH, TLS fragment ranges, dual-stack VPN, Android manifest, and no Xray binary.")
