# Building Frago ARM64 APK

## Java versions used by CI

The GitHub Actions workflow uses two Java versions deliberately:

- JDK 17 is selected before `android-actions/setup-android@v4`, because the
  Android command-line SDK tools (`sdkmanager`) require JDK 17 or newer.
- After Android SDK licenses and packages are installed, the workflow switches
  to JDK 11 for Gradle. The project retains Gradle 7.2 and Android Gradle
  Plugin 7.1.3, and this avoids changing the legacy Android build toolchain.

Do not move the JDK 11 setup above `setup-android`; doing so reproduces the
`sdkmanager requires JDK 17 or later` failure.

## GitHub Actions

1. Put all project files in the repository root.
2. Open **Actions** and run **Build Frago ARM64 APK**, or push to `main`/`master`.
3. Download `Frago-ARM64-debug` or `Frago-ARM64-release` from the workflow
   run's Artifacts section after a successful build.

The workflow builds the Hev SOCKS5 TUN library for `arm64-v8a` and then builds
Frago. The app does not bundle or execute Xray.
