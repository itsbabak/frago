package hev.htproxy;

/** JNI binding supplied by the pinned HevSocks5Tunnel Android native build. */
public final class TProxyService {
    private TProxyService() { }

    public static native boolean TProxyStartService(String configPath, int tunFd);
    public static native boolean TProxyStopService();
    public static native boolean TProxyIsRunning();
    public static native long[] TProxyGetStats();

    static {
        System.loadLibrary("hev-socks5-tunnel");
    }
}
