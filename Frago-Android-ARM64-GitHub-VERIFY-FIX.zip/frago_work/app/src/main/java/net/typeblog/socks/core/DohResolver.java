package net.typeblog.socks.core;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Minimal RFC 8484 wire-format DNS-over-HTTPS A-record resolver. */
public final class DohResolver {
    private static final class Entry {
        final InetAddress[] addresses;
        final long expiresAt;
        Entry(InetAddress[] addresses, long expiresAt) { this.addresses = addresses; this.expiresAt = expiresAt; }
    }

    private final String endpoint;
    private final String[] googleOverrides;
    private final Map<String, Entry> cache = new ConcurrentHashMap<>();

    public DohResolver(String endpoint, String[] googleOverrides) {
        this.endpoint = endpoint;
        this.googleOverrides = googleOverrides.clone();
    }

    public InetAddress[] resolve(String hostname) throws Exception {
        String host = hostname == null ? "" : hostname.trim().toLowerCase(Locale.ROOT);
        if (host.isEmpty()) throw new java.net.UnknownHostException("Empty host");
        if (isIpLiteral(host)) return new InetAddress[] { InetAddress.getByName(host) };
        if (host.contains("google")) {
            InetAddress[] result = new InetAddress[googleOverrides.length];
            for (int i = 0; i < googleOverrides.length; i++) result[i] = InetAddress.getByName(googleOverrides[i]);
            return result;
        }
        Entry cached = cache.get(host);
        long now = System.currentTimeMillis();
        if (cached != null && cached.expiresAt > now) return cached.addresses.clone();

        byte[] query = buildAQuery(host);
        HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(8000);
        connection.setReadTimeout(10000);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/dns-message");
        connection.setRequestProperty("Accept", "application/dns-message");
        connection.setFixedLengthStreamingMode(query.length);
        try {
            connection.getOutputStream().write(query);
            int status = connection.getResponseCode();
            if (status != 200) throw new java.io.IOException("DoH HTTP status " + status);
            byte[] response;
            try (InputStream in = connection.getInputStream()) { response = readAll(in, 65535); }
            InetAddress[] found = parseAResponse(response);
            if (found.length == 0) throw new java.net.UnknownHostException(host + " has no A record");
            cache.put(host, new Entry(found, now + 300_000L));
            return found.clone();
        } finally {
            connection.disconnect();
        }
    }

    private static boolean isIpLiteral(String value) {
        return value.indexOf(':') >= 0 || value.matches("[0-9.]+");
    }

    private static byte[] buildAQuery(String host) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        int id = (int) (System.nanoTime() & 0xffff);
        out.writeShort(id);
        out.writeShort(0x0100); // recursion desired
        out.writeShort(1); out.writeShort(0); out.writeShort(0); out.writeShort(0);
        String[] labels = host.split("\\.");
        for (String label : labels) {
            byte[] encoded = label.getBytes(StandardCharsets.US_ASCII);
            if (encoded.length == 0 || encoded.length > 63) throw new java.net.UnknownHostException("Invalid DNS name");
            out.writeByte(encoded.length); out.write(encoded);
        }
        out.writeByte(0);
        out.writeShort(1); // A
        out.writeShort(1); // IN
        return bytes.toByteArray();
    }

    private static InetAddress[] parseAResponse(byte[] data) throws Exception {
        if (data.length < 12) throw new java.io.IOException("Short DNS response");
        int flags = u16(data, 2);
        if ((flags & 0x8000) == 0) throw new java.io.IOException("Not a DNS response");
        int rcode = flags & 0x0f;
        if (rcode != 0 && rcode != 3) throw new java.io.IOException("DNS error: " + rcode);
        int qd = u16(data, 4), an = u16(data, 6), ns = u16(data, 8), ar = u16(data, 10);
        int pos = 12;
        for (int i = 0; i < qd; i++) {
            pos = skipName(data, pos);
            if (pos + 4 > data.length) throw new java.io.IOException("Malformed DNS question");
            pos += 4;
        }
        List<InetAddress> addresses = new ArrayList<>();
        int total = an + ns + ar;
        for (int i = 0; i < total; i++) {
            pos = skipName(data, pos);
            if (pos + 10 > data.length) break;
            int type = u16(data, pos); int clazz = u16(data, pos + 2);
            int rdLength = u16(data, pos + 8); pos += 10;
            if (pos + rdLength > data.length) break;
            if (i < an && type == 1 && clazz == 1 && rdLength == 4) {
                byte[] ip = new byte[4]; System.arraycopy(data, pos, ip, 0, 4);
                addresses.add(InetAddress.getByAddress(ip));
            }
            pos += rdLength;
        }
        return addresses.toArray(new InetAddress[0]);
    }

    private static int skipName(byte[] data, int pos) throws java.io.IOException {
        while (pos < data.length) {
            int length = data[pos] & 0xff;
            if ((length & 0xc0) == 0xc0) {
                if (pos + 1 >= data.length) throw new java.io.IOException("Bad DNS pointer");
                return pos + 2;
            }
            pos++;
            if (length == 0) return pos;
            if (pos + length > data.length) throw new java.io.IOException("Bad DNS label");
            pos += length;
        }
        throw new java.io.IOException("Bad DNS name");
    }

    private static int u16(byte[] data, int pos) { return ((data[pos] & 0xff) << 8) | (data[pos + 1] & 0xff); }

    private static byte[] readAll(InputStream in, int max) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        int n;
        while ((n = in.read(buffer)) != -1) {
            if (out.size() + n > max) throw new java.io.IOException("DNS response too large");
            out.write(buffer, 0, n);
        }
        return out.toByteArray();
    }
}
