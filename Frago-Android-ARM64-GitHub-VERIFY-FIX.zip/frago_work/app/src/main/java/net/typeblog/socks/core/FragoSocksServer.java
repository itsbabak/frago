package net.typeblog.socks.core;

import android.net.VpnService;
import android.util.Log;

import java.io.EOFException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Set;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

/** Small local SOCKS5 direct engine used by the Frago TUN adapter. */
public final class FragoSocksServer {
    private static final String TAG = "FragoSocks";
    private final VpnService vpn;
    private final FragoConfig config;
    private final DohResolver resolver;
    private final TlsHelloFragmenter fragmenter;
    private final String socksUsername;
    private final String socksPassword;
    private final Map<String, AtomicInteger> addressRotation = new ConcurrentHashMap<>();
    private final ExecutorService workers = Executors.newFixedThreadPool(32);
    private volatile boolean running;
    private final Set<Socket> activeClients = ConcurrentHashMap.newKeySet();
    private ServerSocket listener;
    private Thread acceptThread;

    public FragoSocksServer(VpnService vpn, FragoConfig config, String socksUsername, String socksPassword) {
        this.vpn = vpn;
        this.config = config;
        this.socksUsername = socksUsername;
        this.socksPassword = socksPassword;
        this.resolver = new DohResolver(config.dohUrl, config.googleAddresses);
        this.fragmenter = new TlsHelloFragmenter(config);
    }

    public synchronized void start() throws Exception {
        if (running) return;
        listener = new ServerSocket();
        listener.setReuseAddress(true);
        listener.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), config.socksPort), 128);
        running = true;
        acceptThread = new Thread(() -> {
            while (running) {
                try {
                    Socket client = listener.accept();
                    activeClients.add(client);
                    workers.execute(() -> handleClient(client));
                } catch (SocketException stopped) {
                    if (running) Log.e(TAG, "SOCKS listener failed", stopped);
                    break;
                } catch (Exception e) {
                    if (running) Log.e(TAG, "SOCKS accept failed", e);
                }
            }
        }, "Frago-SOCKS-Accept");
        acceptThread.start();
    }

    public synchronized void stop() {
        running = false;
        if (listener != null) try { listener.close(); } catch (Exception ignored) { }
        for (Socket socket : activeClients) close(socket);
        activeClients.clear();
        workers.shutdownNow();
    }

    private void handleClient(Socket client) {
        Socket remote = null;
        try {
            client.setSoTimeout(0);
            InputStream in = client.getInputStream();
            OutputStream out = client.getOutputStream();
            int version = in.read();
            int methodCount = in.read();
            if (version != 5 || methodCount < 1) return;
            byte[] methods = readExact(in, methodCount);
            boolean usernamePassword = false;
            for (byte method : methods) if ((method & 0xff) == 2) usernamePassword = true;
            out.write(new byte[] {5, (byte) (usernamePassword ? 2 : 0xff)}); out.flush();
            if (!usernamePassword) return;

            int authVersion = in.read();
            int usernameLength = in.read();
            if (authVersion != 1 || usernameLength < 1) return;
            String username = new String(readExact(in, usernameLength), StandardCharsets.UTF_8);
            int passwordLength = in.read();
            if (passwordLength < 1) return;
            String password = new String(readExact(in, passwordLength), StandardCharsets.UTF_8);
            boolean authenticated = socksUsername.equals(username) && socksPassword.equals(password);
            out.write(new byte[] {1, (byte) (authenticated ? 0 : 1)}); out.flush();
            if (!authenticated) return;

            byte[] request = readExact(in, 4);
            if ((request[0] & 0xff) != 5 || request[2] != 0) return;
            int command = request[1] & 0xff;
            Address target = readAddress(in, request[3] & 0xff);
            if (command == 1) {
                final InetAddress[] destinations;
                try {
                    destinations = resolve(target.host);
                } catch (Exception dnsError) {
                    writeReply(out, 4); // host unreachable
                    throw dnsError;
                }
                Exception lastError = null;
                int startIndex = nextAddressIndex(target.host, destinations.length);
                for (int i = 0; i < destinations.length; i++) {
                    InetAddress destination = destinations[(startIndex + i) % destinations.length];
                    Socket candidate = new Socket();
                    try {
                        if (!vpn.protect(candidate)) throw new SocketException("Could not protect upstream TCP socket from VPN loop");
                        candidate.setTcpNoDelay(true);
                        candidate.connect(new InetSocketAddress(destination, target.port), 12000);
                        remote = candidate;
                        break;
                    } catch (Exception connectError) {
                        lastError = connectError;
                        close(candidate);
                    }
                }
                if (remote == null) {
                    writeReply(out, 5);
                    if (lastError != null) throw lastError;
                    return;
                }
                writeReply(out, 0);
                proxyTcp(client, remote, target.host);
                remote = null; // closed by proxyTcp
            } else if (command == 3) {
                serveUdpAssociation(client);
            } else {
                writeReply(out, 7);
            }
        } catch (Exception e) {
            if (running) Log.d(TAG, "SOCKS session ended: " + e.getMessage());
        } finally {
            close(remote);
            close(client);
            activeClients.remove(client);
        }
    }

    private void proxyTcp(Socket client, Socket remote, String targetHost) throws Exception {
        Thread down = new Thread(() -> {
            try { copy(remote.getInputStream(), client.getOutputStream()); }
            catch (Exception ignored) { }
            finally { try { client.shutdownOutput(); } catch (Exception ignored) { } }
        }, "Frago-TCP-Down");
        down.start();
        try {
            fragmenter.forward(client.getInputStream(), remote.getOutputStream(), targetHost);
            try { remote.shutdownOutput(); } catch (Exception ignored) { }
            down.join();
        } finally {
            close(remote);
            close(client);
        }
    }

    private void serveUdpAssociation(Socket control) throws Exception {
        DatagramSocket local = new DatagramSocket(null);
        DatagramSocket upstream = new DatagramSocket(null);
        try {
            local.setReuseAddress(true);
            local.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0));
            upstream.bind(new InetSocketAddress(0));
            if (!vpn.protect(local) || !vpn.protect(upstream))
                throw new SocketException("Could not protect UDP relay sockets from VPN loop");
            int localPort = local.getLocalPort();
            OutputStream response = control.getOutputStream();
            // Send the actual relay endpoint rather than the zero port in the first reply.
            // Some clients issue UDP ASSOCIATE with 0.0.0.0:0 and expect the bound port.
            response.write(new byte[] {5, 0, 0, 1, 127, 0, 0, 1, (byte) (localPort >>> 8), (byte) localPort});
            response.flush();

            AtomicReference<InetSocketAddress> clientEndpoint = new AtomicReference<>();
            Map<String, InetAddress> selectedUdpDestinations = new HashMap<>();
            Thread fromTunnel = new Thread(() -> {
                byte[] buffer = new byte[65535];
                while (running && !local.isClosed()) {
                    try {
                        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                        local.receive(packet);
                        clientEndpoint.set(new InetSocketAddress(packet.getAddress(), packet.getPort()));
                        UdpRequest udp = parseUdp(packet.getData(), packet.getOffset(), packet.getLength());
                        if (udp == null) continue;
                        InetAddress destination = selectedUdpDestinations.get(udp.host);
                        if (destination == null) {
                            InetAddress[] destinations = resolve(udp.host);
                            destination = destinations[nextAddressIndex(udp.host, destinations.length)];
                            selectedUdpDestinations.put(udp.host, destination);
                        }
                        DatagramPacket outgoing = new DatagramPacket(udp.payload, udp.payload.length,
                                destination, udp.port);
                        upstream.send(outgoing);
                    } catch (Exception e) {
                        if (!local.isClosed() && running) Log.d(TAG, "UDP request dropped: " + e.getMessage());
                    }
                }
            }, "Frago-UDP-Up");
            Thread toTunnel = new Thread(() -> {
                byte[] buffer = new byte[65535];
                while (running && !upstream.isClosed()) {
                    try {
                        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                        upstream.receive(packet);
                        InetSocketAddress peer = clientEndpoint.get();
                        if (peer == null) continue;
                        byte[] framed = wrapUdp(packet.getAddress(), packet.getPort(), packet.getData(), packet.getOffset(), packet.getLength());
                        local.send(new DatagramPacket(framed, framed.length, peer));
                    } catch (Exception e) {
                        if (!upstream.isClosed() && running) Log.d(TAG, "UDP response dropped: " + e.getMessage());
                    }
                }
            }, "Frago-UDP-Down");
            fromTunnel.start();
            toTunnel.start();
            // The TCP control channel remains open for the lifetime of this UDP association.
            while (running && control.getInputStream().read() != -1) { /* wait for close */ }
        } finally {
            local.close();
            upstream.close();
        }
    }

    private InetAddress[] resolve(String host) throws Exception {
        if (host.indexOf(':') >= 0 || host.matches("[0-9.]+")) return new InetAddress[] { InetAddress.getByName(host) };
        return resolver.resolve(host);
    }

    private int nextAddressIndex(String host, int count) {
        if (count <= 1) return 0;
        AtomicInteger counter = addressRotation.computeIfAbsent(host, ignored -> new AtomicInteger());
        return Math.floorMod(counter.getAndIncrement(), count);
    }

    private static final class Address {
        final String host; final int port;
        Address(String host, int port) { this.host = host; this.port = port; }
    }

    private static Address readAddress(InputStream in, int type) throws Exception {
        String host;
        if (type == 1) {
            byte[] b = readExact(in, 4);
            host = (b[0] & 255) + "." + (b[1] & 255) + "." + (b[2] & 255) + "." + (b[3] & 255);
        } else if (type == 4) {
            byte[] b = readExact(in, 16);
            host = InetAddress.getByAddress(b).getHostAddress();
        } else if (type == 3) {
            int size = in.read();
            if (size < 1) throw new EOFException("Missing domain length");
            host = new String(readExact(in, size), StandardCharsets.US_ASCII);
        } else throw new java.io.IOException("Unsupported SOCKS address type " + type);
        byte[] p = readExact(in, 2);
        return new Address(host, ((p[0] & 255) << 8) | (p[1] & 255));
    }

    private static final class UdpRequest {
        final String host; final int port; final byte[] payload;
        UdpRequest(String host, int port, byte[] payload) { this.host = host; this.port = port; this.payload = payload; }
    }

    private static UdpRequest parseUdp(byte[] data, int offset, int length) throws Exception {
        int p = offset;
        if (length < 4 || data[p++] != 0 || data[p++] != 0 || data[p++] != 0) return null;
        int atyp = data[p++] & 255;
        String host;
        if (atyp == 1) {
            if (p + 4 > offset + length) return null;
            host = (data[p] & 255) + "." + (data[p + 1] & 255) + "." + (data[p + 2] & 255) + "." + (data[p + 3] & 255); p += 4;
        } else if (atyp == 4) {
            if (p + 16 > offset + length) return null;
            byte[] ip = new byte[16]; System.arraycopy(data, p, ip, 0, 16); p += 16;
            host = InetAddress.getByAddress(ip).getHostAddress();
        } else if (atyp == 3) {
            if (p >= offset + length) return null;
            int n = data[p++] & 255;
            if (p + n > offset + length) return null;
            host = new String(data, p, n, StandardCharsets.US_ASCII); p += n;
        } else return null;
        if (p + 2 > offset + length) return null;
        int port = ((data[p++] & 255) << 8) | (data[p++] & 255);
        byte[] payload = new byte[offset + length - p];
        System.arraycopy(data, p, payload, 0, payload.length);
        return new UdpRequest(host, port, payload);
    }

    private static byte[] wrapUdp(InetAddress source, int sourcePort, byte[] payload, int offset, int length) throws Exception {
        byte[] address = source.getAddress();
        int atyp = address.length == 4 ? 1 : 4;
        byte[] result = new byte[3 + 1 + address.length + 2 + length];
        int p = 0;
        result[p++] = 0; result[p++] = 0; result[p++] = 0; result[p++] = (byte) atyp;
        System.arraycopy(address, 0, result, p, address.length); p += address.length;
        result[p++] = (byte) (sourcePort >>> 8); result[p++] = (byte) sourcePort;
        System.arraycopy(payload, offset, result, p, length);
        return result;
    }

    private static byte[] readExact(InputStream in, int count) throws Exception {
        byte[] data = new byte[count];
        int offset = 0;
        while (offset < count) {
            int n = in.read(data, offset, count - offset);
            if (n < 0) throw new EOFException("Unexpected end of SOCKS stream");
            offset += n;
        }
        return data;
    }

    private static void writeReply(OutputStream out, int code) throws Exception { writeReply(out, code, "0.0.0.0", 0); }

    private static void writeReply(OutputStream out, int code, String ip, int port) throws Exception {
        String[] octets = ip.split("\\.");
        byte[] address = new byte[] {0, 0, 0, 0};
        if (octets.length == 4) {
            for (int i = 0; i < 4; i++) address[i] = (byte) Integer.parseInt(octets[i]);
        }
        out.write(new byte[] {5, (byte) code, 0, 1, address[0], address[1], address[2], address[3], (byte) (port >>> 8), (byte) port});
        out.flush();
    }

    private static void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buffer = new byte[16 * 1024];
        int n;
        while ((n = in.read(buffer)) != -1) { out.write(buffer, 0, n); out.flush(); }
    }

    private static void close(Socket socket) { if (socket != null) try { socket.close(); } catch (Exception ignored) { } }
}
