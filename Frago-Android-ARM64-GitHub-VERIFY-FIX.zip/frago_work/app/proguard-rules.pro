# JNI symbols are resolved by package, class and method name at runtime.
-keep class hev.htproxy.TProxyService { *; }

# Keep the Android VPN entry point and reflection-free runtime classes stable.
-keep class net.typeblog.socks.FragoVpnService { *; }
