package net.typeblog.socks.util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Ultra-lightweight local DNS relay.
 * 1) Applies local host overrides (including Gemini/Google IPs) immediately in memory.
 * 2) Queries protected physical/fallback UDP DNS with minimal latency and battery.
 * 3) If UDP times out or returns a poisoned DPI IP (10.10.34.34-37), falls back to
 *    RFC-1035 DNS-over-TCP through local ByeDPI SOCKS5.
 */
public final class LocalDnsRelay {
    public interface SocketProtector {
        boolean protect(DatagramSocket socket);
    }

    private static final int UDP_TIMEOUT_MS = 2500;
    private static final int TCP_TIMEOUT_MS = 5000;
    private static final int MAX_DNS_PACKET = 4096;
    private static final List<String> FALLBACK_DNS = Collections.unmodifiableList(
            Arrays.asList("1.1.1.1", "8.8.8.8"));

    private final DnsHostOverrides hostOverrides;
    private final SocketProtector protector;
    private final int socksPort;
    private volatile List<String> upstreamDns;
    private volatile boolean running;
    private DatagramSocket serverSocket;
    private Thread listenerThread;
    private ThreadPoolExecutor pool;

    public LocalDnsRelay(DnsHostOverrides overrides,
                         List<String> systemDnsServers,
                         SocketProtector protector,
                         int socksPort) {
        this.hostOverrides = overrides;
        this.protector = protector;
        this.socksPort = socksPort;
        updateUpstreamDns(systemDnsServers);
    }

    public void updateUpstreamDns(List<String> systemDnsServers) {
        List<String> list = new ArrayList<>();
        if (systemDnsServers != null) {
            for (String ip : systemDnsServers) {
                if (isValidIpv4(ip) && !ip.startsWith("127.") && !ip.startsWith("26.26.26.") && !list.contains(ip)) {
                    list.add(ip);
                }
            }
        }
        for (String fb : FALLBACK_DNS) {
            if (!list.contains(fb)) list.add(fb);
        }
        List<String> updated = Collections.unmodifiableList(list);
        // Network callbacks can repeat identical DNS state; avoid replacing the
        // immutable snapshot and allocating another list when nothing changed.
        List<String> current = this.upstreamDns;
        if (current == null || !current.equals(updated)) {
            this.upstreamDns = updated;
        }
    }

    public synchronized void start() throws Exception {
        if (running) return;
        serverSocket = new DatagramSocket(null);
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress("127.0.0.1", 5354));
        // Block in kernel with 0% CPU usage while idle (eliminates 1s wake-up polling).
        serverSocket.setSoTimeout(0);

        // DNS is bursty and usually waits on network I/O. Keep concurrency bounded
        // to avoid four simultaneous resolver paths waking the CPU on small devices.
        // A small queue absorbs short bursts without allowing unbounded memory growth.
        ThreadPoolExecutor executor = new ThreadPoolExecutor(
                1, 3, 15L, TimeUnit.SECONDS,
                new LinkedBlockingQueue<Runnable>(32),
                new ThreadFactory() {
                    @Override
                    public Thread newThread(final Runnable r) {
                        Thread t = new Thread(new Runnable() {
                            @Override
                            public void run() {
                                // DNS resolution is background work; let UI and network
                                // forwarding threads take priority under CPU pressure.
                                android.os.Process.setThreadPriority(
                                        android.os.Process.THREAD_PRIORITY_BACKGROUND);
                                r.run();
                            }
                        }, "Frago-DNS-Worker");
                        t.setDaemon(true);
                        return t;
                    }
                },
                new ThreadPoolExecutor.DiscardOldestPolicy());
        executor.allowCoreThreadTimeOut(true);
        pool = executor;

        running = true;
        listenerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                byte[] buffer = new byte[MAX_DNS_PACKET];
                while (running) {
                    try {
                        DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                        serverSocket.receive(request);
                        final int len = request.getLength();
                        if (len < 12) continue;
                        final byte[] query = new byte[len];
                        System.arraycopy(request.getData(), request.getOffset(), query, 0, len);
                        final InetAddress clientAddr = request.getAddress();
                        final int clientPort = request.getPort();

                        // Fast-path: answer Gemini/Google host overrides immediately in memory.
                        byte[] override = hostOverrides == null ? null : hostOverrides.answer(query, query.length);
                        if (override != null && override.length > 0) {
                            sendReply(override, clientAddr, clientPort);
                            continue;
                        }

                        ThreadPoolExecutor currentPool = pool;
                        if (currentPool != null && !currentPool.isShutdown()) {
                            currentPool.execute(new Runnable() {
                                @Override
                                public void run() {
                                    byte[] answer = resolveUpstream(query);
                                    if (answer != null && answer.length > 0 && running) {
                                        sendReply(answer, clientAddr, clientPort);
                                    }
                                }
                            });
                        }
                    } catch (IOException ignored) {
                        if (!running) break;
                    } catch (Exception ignored) {
                    }
                }
            }
        }, "Frago-DNS-Listener");
        listenerThread.setDaemon(true);
        listenerThread.start();
    }

    private void sendReply(byte[] answer, InetAddress addr, int port) {
        DatagramSocket sock = serverSocket;
        if (sock == null || sock.isClosed()) return;
        try {
            sock.send(new DatagramPacket(answer, answer.length, addr, port));
        } catch (Exception ignored) {
        }
    }

    private byte[] resolveUpstream(byte[] query) {
        List<String> servers = upstreamDns;
        for (int i = 0; i < Math.min(servers.size(), 2); i++) {
            byte[] udpReply = queryUdp(servers.get(i), query);
            if (udpReply != null && !isPoisonedAnswer(udpReply)) return udpReply;
        }
        for (String fb : FALLBACK_DNS) {
            byte[] tcpReply = queryTcpViaSocks(fb, 53, query);
            if (tcpReply != null && !isPoisonedAnswer(tcpReply)) return tcpReply;
        }
        return null;
    }

    private byte[] queryUdp(String serverIp, byte[] query) {
        DatagramSocket sock = null;
        try {
            sock = new DatagramSocket();
            if (protector != null) protector.protect(sock);
            sock.setSoTimeout(UDP_TIMEOUT_MS);
            InetAddress dest = InetAddress.getByName(serverIp);
            sock.send(new DatagramPacket(query, query.length, dest, 53));
            byte[] buf = new byte[MAX_DNS_PACKET];
            DatagramPacket resp = new DatagramPacket(buf, buf.length);
            sock.receive(resp);
            int len = resp.getLength();
            if (len < 12) return null;
            byte[] result = new byte[len];
            System.arraycopy(buf, 0, result, 0, len);
            return result;
        } catch (Exception ignored) {
            return null;
        } finally {
            if (sock != null) try { sock.close(); } catch (Exception ignored) { }
        }
    }

    private byte[] queryTcpViaSocks(String dnsIp, int dnsPort, byte[] query) {
        Socket sock = null;
        try {
            byte[] ipBytes = InetAddress.getByName(dnsIp).getAddress();
            if (ipBytes.length != 4) return null;

            sock = new Socket();
            sock.connect(new InetSocketAddress("127.0.0.1", socksPort), TCP_TIMEOUT_MS);
            sock.setSoTimeout(TCP_TIMEOUT_MS);
            sock.setTcpNoDelay(true);

            DataOutputStream out = new DataOutputStream(sock.getOutputStream());
            DataInputStream in = new DataInputStream(sock.getInputStream());

            out.write(new byte[]{0x05, 0x01, 0x00});
            out.flush();
            byte[] greetResp = new byte[2];
            in.readFully(greetResp);
            if (greetResp[0] != 0x05 || greetResp[1] != 0x00) return null;

            byte[] req = new byte[10];
            req[0] = 0x05;
            req[1] = 0x01;
            req[2] = 0x00;
            req[3] = 0x01;
            System.arraycopy(ipBytes, 0, req, 4, 4);
            req[8] = (byte) ((dnsPort >> 8) & 0xFF);
            req[9] = (byte) (dnsPort & 0xFF);
            out.write(req);
            out.flush();

            byte[] connHdr = new byte[4];
            in.readFully(connHdr);
            if (connHdr[0] != 0x05 || connHdr[1] != 0x00) return null;
            int atyp = connHdr[3] & 0xFF;
            if (atyp == 1) in.readFully(new byte[6]);
            else if (atyp == 4) in.readFully(new byte[18]);
            else if (atyp == 3) in.readFully(new byte[in.readUnsignedByte() + 2]);
            else return null;

            out.writeShort(query.length);
            out.write(query);
            out.flush();

            int respLen = in.readUnsignedShort();
            if (respLen < 12 || respLen > MAX_DNS_PACKET) return null;
            byte[] resp = new byte[respLen];
            in.readFully(resp);
            return resp;
        } catch (Exception ignored) {
            return null;
        } finally {
            if (sock != null) try { sock.close(); } catch (Exception ignored) { }
        }
    }

    private static boolean isPoisonedAnswer(byte[] msg) {
        if (msg == null || msg.length < 12) return false;
        int anCount = ((msg[6] & 0xFF) << 8) | (msg[7] & 0xFF);
        if (anCount <= 0) return false;
        int qdCount = ((msg[4] & 0xFF) << 8) | (msg[5] & 0xFF);
        int pos = 12;
        for (int i = 0; i < qdCount; i++) {
            pos = skipName(msg, pos);
            if (pos < 0 || pos + 4 > msg.length) return false;
            pos += 4;
        }
        for (int i = 0; i < anCount; i++) {
            pos = skipName(msg, pos);
            if (pos < 0 || pos + 10 > msg.length) return false;
            int type = ((msg[pos] & 0xFF) << 8) | (msg[pos + 1] & 0xFF);
            int rdLen = ((msg[pos + 8] & 0xFF) << 8) | (msg[pos + 9] & 0xFF);
            pos += 10;
            if (pos + rdLen > msg.length) return false;
            if (type == 1 && rdLen == 4) {
                int a = msg[pos] & 0xFF;
                int b = msg[pos + 1] & 0xFF;
                int c = msg[pos + 2] & 0xFF;
                int d = msg[pos + 3] & 0xFF;
                if ((a == 10 && b == 10 && c == 34 && (d >= 34 && d <= 37))
                        || (a == 0 && b == 0 && c == 0 && d == 0)) {
                    return true;
                }
            }
            pos += rdLen;
        }
        return false;
    }

    private static int skipName(byte[] msg, int pos) {
        int jumps = 0;
        while (pos < msg.length && jumps < 64) {
            int len = msg[pos] & 0xFF;
            if (len == 0) return pos + 1;
            if ((len & 0xC0) == 0xC0) return pos + 2;
            pos += 1 + len;
            jumps++;
        }
        return -1;
    }

    private static boolean isValidIpv4(String ip) {
        if (ip == null || !ip.matches("[0-9.]+")) return false;
        String[] parts = ip.split("\\.", -1);
        if (parts.length != 4) return false;
        for (String p : parts) {
            if (p.isEmpty() || p.length() > 3) return false;
            try {
                int n = Integer.parseInt(p);
                if (n < 0 || n > 255) return false;
            } catch (NumberFormatException e) {
                return false;
            }
        }
        return true;
    }

    public synchronized void stop() {
        running = false;
        if (serverSocket != null) {
            try { serverSocket.close(); } catch (Exception ignored) { }
            serverSocket = null;
        }
        if (listenerThread != null) {
            listenerThread.interrupt();
            listenerThread = null;
        }
        if (pool != null) {
            pool.shutdownNow();
            pool = null;
        }
    }
}
