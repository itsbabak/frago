package net.typeblog.socks.util;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Pattern;

/** Typed runtime settings for ByeDPI packet desync and local DNS host overrides. */
public final class ByeDpiSettings {
    private static final int MAX_TLS_SPLITS = 8;
    private static final Pattern POSITION = Pattern.compile(
            "^-?(?:0[xX][0-9a-fA-F]+|[0-9]+)(?::[0-9]+(?::[0-9]+)?)?(?:\\+[shn](?:[emrs])?)?$");

    // 4 TLS records by default (3 split points)
    public static final String DEFAULT_POSITION = "1+s\n5+s\n10+s";
    // Gemini / Google IP overrides preserved untouched
    public static final String DEFAULT_GOOGLE_HOSTS = "regexp:(google)=65.109.184.128,91.107.241.144";
    // X/Twitter domains use the same two user-supplied override addresses.
    public static final String DEFAULT_X_HOSTS = "regexp:(^|\\.)(x\\.com|twitter\\.com|t\\.co|twimg\\.com)$=65.109.184.128,91.107.241.144";
    public static final String DEFAULT_HOSTS = DEFAULT_GOOGLE_HOSTS + "\n" + DEFAULT_X_HOSTS;

    public static final String MODE_DISABLED = "disabled";
    public static final String MODE_TLSREC_ONLY = "tlsrec_only";
    public static final String MODE_OOB_ONLY = "oob_only";
    public static final String MODE_TLSREC_OOB = "tlsrec_oob";
    public static final String DEFAULT_DESYNC_MODE = MODE_TLSREC_OOB;

    public final List<String> tlsRecordPositions;
    public final String desyncMode;
    public final DnsHostOverrides hostOverrides;

    private ByeDpiSettings(List<String> positions, String desyncMode, DnsHostOverrides overrides) {
        this.tlsRecordPositions = positions;
        this.desyncMode = desyncMode;
        this.hostOverrides = overrides;
    }

    public static ByeDpiSettings fromSettings(String positions, String desyncMode, String hosts) {
        String normalizedPositions = normalizePositions(positions);
        String normalizedMode = normalizeDesyncMode(desyncMode);
        String normalizedHosts = DnsHostOverrides.normalizeEditorText(hosts);
        return new ByeDpiSettings(
                parsePositions(normalizedPositions),
                normalizedMode,
                DnsHostOverrides.fromText(normalizedHosts));
    }

    public static String normalizeDesyncMode(String raw) {
        if (raw == null || raw.trim().isEmpty()) return DEFAULT_DESYNC_MODE;
        String value = raw.trim();
        if (MODE_DISABLED.equals(value) || MODE_TLSREC_ONLY.equals(value)
                || MODE_OOB_ONLY.equals(value) || MODE_TLSREC_OOB.equals(value)) return value;
        return DEFAULT_DESYNC_MODE;
    }

    public static String normalizePositions(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "";
        StringBuilder out = new StringBuilder();
        LinkedHashSet<String> unique = new LinkedHashSet<>();
        String[] lines = raw.replace('\r', '\n').split("\\n");
        for (String line : lines) {
            String value = line.trim();
            if (value.isEmpty() || value.startsWith("#")) continue;
            if (!POSITION.matcher(value).matches()) {
                throw new IllegalArgumentException("Invalid TLS split position: " + value);
            }
            try {
                String[] sections = value.split("\\+", 2)[0].split(":");
                long offset = decodePosition(sections[0]);
                if (offset < -65535 || offset > 65535) throw new NumberFormatException();
                if (sections.length > 1) {
                    long repeat = Long.parseLong(sections[1]);
                    if (repeat <= 0 || repeat > 1000) throw new NumberFormatException();
                }
                if (sections.length > 2) {
                    long skip = Long.parseLong(sections[2]);
                    if (skip < 0 || skip > 1000) throw new NumberFormatException();
                }
            } catch (Exception invalid) {
                throw new IllegalArgumentException("Invalid TLS split offset: " + value);
            }
            if (!unique.add(value)) throw new IllegalArgumentException("Duplicate TLS split position: " + value);
            if (unique.size() > MAX_TLS_SPLITS) {
                throw new IllegalArgumentException("Use no more than " + MAX_TLS_SPLITS + " TLS split points");
            }
            if (out.length() > 0) out.append('\n');
            out.append(value);
        }
        return out.toString();
    }

    private static long decodePosition(String value) {
        if (value.startsWith("0x") || value.startsWith("0X")) return Long.parseLong(value.substring(2), 16);
        return Long.parseLong(value);
    }

    private static List<String> parsePositions(String normalized) {
        List<String> values = new ArrayList<>();
        if (normalized != null && !normalized.trim().isEmpty()) {
            for (String line : normalized.split("\\n")) {
                String value = line.trim();
                if (!value.isEmpty()) values.add(value);
            }
        }
        return values;
    }

    public List<String> toByeDpiArgs() {
        List<String> args = new ArrayList<>();
        // Resource & battery optimization: release idle/stale sockets rapidly & cap memory
        args.add("--timeout");
        args.add("10");
        args.add("--max-conn");
        args.add("512");

        if (MODE_DISABLED.equals(desyncMode)) return args;

        if (MODE_TLSREC_ONLY.equals(desyncMode) || MODE_TLSREC_OOB.equals(desyncMode)) {
            for (String position : tlsRecordPositions) {
                args.add("--tlsrec");
                args.add(position);
            }
        }

        if (MODE_OOB_ONLY.equals(desyncMode) || MODE_TLSREC_OOB.equals(desyncMode)) {
            args.add("--oob");
            args.add("1+s");
        }
        return args;
    }

    public static String positionsSummary(String positions) {
        try {
            int splits = parsePositions(normalizePositions(positions)).size();
            if (splits == 0) return "TLS record fragmentation is disabled";
            return (splits + 1) + " TLS records · " + splits + " split point(s)";
        } catch (Exception error) {
            return "Invalid TLS split positions";
        }
    }

    public static int recordCount(String positions) {
        return parsePositions(normalizePositions(positions)).size() + 1;
    }

    public static String defaultPositionsForRecordCount(int records) {
        if (records <= 1) return "";
        int splitCount = Math.min(records - 1, MAX_TLS_SPLITS);
        String[] offsets = {"1", "5", "10", "20", "30", "50", "80", "100"};
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < splitCount; i++) {
            if (result.length() > 0) result.append('\n');
            result.append(offsets[i]).append("+s");
        }
        return result.toString();
    }
}
