package net.typeblog.socks;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.ServiceConnection;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.IBinder;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.ListPreference;
import android.preference.PreferenceCategory;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import net.typeblog.socks.util.Profile;
import net.typeblog.socks.util.ProfileManager;
import net.typeblog.socks.util.Utility;

import java.util.Locale;

import static net.typeblog.socks.util.Constants.*;

public class ProfileFragment extends PreferenceFragment implements Preference.OnPreferenceClickListener, Preference.OnPreferenceChangeListener,
        CompoundButton.OnCheckedChangeListener {
    private ProfileManager mManager;
    private Profile mProfile;

    private Switch mSwitch;
    private boolean mRunning = false;
    private boolean mStarting = false, mStopping = false;
    private final Handler mStopHandler = new Handler(Looper.getMainLooper());
    private final Runnable mStopTimeout = new Runnable() {
        @Override public void run() {
            if (!mStopping) return;
            // Do not leave the toggle locked if Android drops the state broadcast.
            mRunning = false;
            updateState();
        }
    };
    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName p1, IBinder binder) {
            mBinder = IVpnService.Stub.asInterface(binder);

            try {
                mRunning = mBinder.isRunning();
            } catch (Exception ignored) { mRunning = false; }
            // A bind can complete before onStartCommand has finished starting
            // the tunnel. Do not immediately undo the user's ON action.
            if (mStarting && !mRunning) {
                keepSwitchOnWhileStarting();
                return;
            }
            updateState();
        }

        @Override
        public void onServiceDisconnected(ComponentName p1) {
            mBinder = null;
            mRunning = false;
            if (mStarting) {
                keepSwitchOnWhileStarting();
            } else {
                updateState();
            }
        }
    };
    private IVpnService mBinder;

    private ListPreference mPrefProfile;
    private ListPreference mPrefDesyncMode;
    private ListPreference mPrefTlsCount;
    private Preference mPrefDnsHosts;
    private Preference mPrefAppList;
    private PreferenceCategory mTlsCategory, mDnsCategory, mAdvancedCategory;
    private android.preference.PreferenceScreen mScreen;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings);
        mScreen = getPreferenceScreen();
        mScreen.setOrderingAsAdded(false);
        setHasOptionsMenu(true);
        mManager = new ProfileManager(getActivity().getApplicationContext());
        initPreferences();
        reload();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.main, menu);

        MenuItem s = menu.findItem(R.id.switch_main);
        mSwitch = s.getActionView().findViewById(R.id.switch_action_button);
        mSwitch.setOnCheckedChangeListener(this);
        checkState();
    }


    @Override public void onResume() {
        super.onResume();
        if (!mReceiverRegistered && getActivity() != null) {
            IntentFilter filter = new IntentFilter(SocksVpnService.ACTION_STATE);
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                getActivity().registerReceiver(mStateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                getActivity().registerReceiver(mStateReceiver, filter);
            }
            mReceiverRegistered = true;
        }
        if (mSwitch != null) checkState();
    }
    @Override public void onPause() {
        if (mReceiverRegistered && getActivity() != null) {
            try { getActivity().unregisterReceiver(mStateReceiver); } catch (Exception ignored) { }
            mReceiverRegistered = false;
        }
        if (mBound && getActivity() != null) {
            try { getActivity().unbindService(mConnection); } catch (Exception ignored) { }
            mBound = false; mBinder = null;
        }
        super.onPause();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.prof_add) {
            addProfile();
            return true;
        } else if (id == R.id.prof_del) {
            removeProfile();
            return true;
        } else if (id == R.id.prof_rename) {
            renameProfile();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onPreferenceClick(Preference p) {
        if (p == mPrefAppList) { showAppPicker(); return true; }
        if (p == mPrefDnsHosts) { showDnsHostEditor(); return true; }
        
        return false;
    }

    @Override
    public boolean onPreferenceChange(Preference p, Object newValue) {
        if (p == mPrefProfile) {
            String name = newValue.toString();
            mProfile = mManager.getProfile(name);
            mManager.switchDefault(name);
            reload();
            return true;
        } else if (p == mPrefTlsCount) {
            try {
                int records = Integer.parseInt(newValue.toString());
                if (records < 1 || records > 9) throw new IllegalArgumentException("Choose between 1 and 9 TLS records");
                String positions = net.typeblog.socks.util.ByeDpiSettings.defaultPositionsForRecordCount(records);
                mProfile.setTlsRecordPositions(positions);
                updateTlsSummary();
                return true;
            } catch (Exception error) {
                Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_LONG).show();
                return false;
            }
        } else if (p == mPrefDesyncMode) {
            String mode = newValue == null ? net.typeblog.socks.util.ByeDpiSettings.DEFAULT_DESYNC_MODE : newValue.toString();
            mProfile.setDesyncMode(mode);
            mPrefDesyncMode.setValue(mode);
            resetList(mPrefDesyncMode);
            updateTlsSummary();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton p1, boolean checked) {
        if (mStarting || mStopping) {
            if (mSwitch != null) {
                mSwitch.setOnCheckedChangeListener(null);
                mSwitch.setChecked(mRunning || mStarting);
                mSwitch.setOnCheckedChangeListener(this);
            }
            return;
        }
        if (checked) {
            startVpn();
        } else {
            stopVpn();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != 0) return;
        if (resultCode == Activity.RESULT_OK) {
            try {
                Utility.startVpn(getActivity(), mProfile);
                checkState();
            } catch (Exception error) {
                Toast.makeText(getActivity(), R.string.connection_start_failed, Toast.LENGTH_LONG).show();
                resetMainSwitch();
            }
        } else {
            mRunning = false;
            updateState();
        }
    }

    private void initPreferences() {
        mPrefProfile = (ListPreference) findPreference(PREF_PROFILE);
        mAdvancedCategory = (PreferenceCategory) findPreference("advanced");
        mPrefAppList = findPreference(PREF_ADV_APP_LIST);
        mTlsCategory = (PreferenceCategory) findPreference("tls_fragment_category");
        mDnsCategory = (PreferenceCategory) findPreference("dns_override_category");
        mPrefTlsCount = (ListPreference) findPreference("tlsrec_count");
        mPrefDesyncMode = (ListPreference) findPreference("desync_mode");
        mPrefDnsHosts = findPreference("dns_host_overrides");
        mPrefTlsCount.setPersistent(false);
        mPrefDesyncMode.setPersistent(false);
        mPrefDnsHosts.setPersistent(false);

        mPrefProfile.setOnPreferenceChangeListener(this);
        mPrefAppList.setOnPreferenceClickListener(this);
        mPrefTlsCount.setOnPreferenceChangeListener(this);
        mPrefDesyncMode.setOnPreferenceChangeListener(this);
        mPrefDnsHosts.setOnPreferenceClickListener(this);


    }

    private void reload() {
        if (mProfile == null) mProfile = mManager.getDefault();
        mPrefProfile.setEntries(mManager.getProfiles());
        mPrefProfile.setEntryValues(mManager.getProfiles());
        mPrefProfile.setValue(mProfile.getName());
        resetList(mPrefProfile);
        mProfile.setIsPerApp(true);
        mProfile.setAutoConnect(true);
        mPrefAppList.setSummary(selectedAppsSummary());
        int recordCount = net.typeblog.socks.util.ByeDpiSettings.recordCount(mProfile.getTlsRecordPositions());
        mPrefTlsCount.setValue(Integer.toString(Math.min(9, Math.max(1, recordCount))));
        resetList(mPrefTlsCount);
        mPrefDesyncMode.setValue(net.typeblog.socks.util.ByeDpiSettings.normalizeDesyncMode(mProfile.getDesyncMode()));
        resetList(mPrefDesyncMode);
        updateTlsSummary();
        updateDnsHostsSummary();
        updateProtocolVisibility();
    }

    private void updateProtocolVisibility() {
        if (mProfile == null) return;
        if (mTlsCategory.getParent() == null) mScreen.addPreference(mTlsCategory);
        if (mDnsCategory.getParent() == null) mScreen.addPreference(mDnsCategory);
        mTlsCategory.setOrder(1);
        mDnsCategory.setOrder(2);
        mAdvancedCategory.setOrder(3);
    }

    private void updateTlsSummary() {
        if (mProfile == null || mPrefTlsCount == null) return;
        int records = net.typeblog.socks.util.ByeDpiSettings.recordCount(mProfile.getTlsRecordPositions());
        String mode = net.typeblog.socks.util.ByeDpiSettings.normalizeDesyncMode(mProfile.getDesyncMode());
        boolean tlsEnabled = net.typeblog.socks.util.ByeDpiSettings.MODE_TLSREC_ONLY.equals(mode)
                || net.typeblog.socks.util.ByeDpiSettings.MODE_TLSREC_OOB.equals(mode);
        mPrefTlsCount.setEnabled(tlsEnabled);
        mPrefTlsCount.setSummary(!tlsEnabled ? "Not used in the selected mode"
                : records <= 1 ? "TLS record fragmentation is disabled" : records + " TLS records will be used");
    }

    private void updateDnsHostsSummary() {
        if (mProfile == null || mPrefDnsHosts == null) return;
        String rules = mProfile.getDnsHostOverrides();
        int count = 0;
        for (String line : rules.split("\n")) {
            if (!line.trim().isEmpty() && !line.trim().startsWith("#")) count++;
        }
        mPrefDnsHosts.setSummary(count == 0 ? getString(R.string.dns_host_empty)
                : count + " service mapping(s) · Tap to manage");
    }

    /** Form-based DNS override editor: a service/domain plus up to two IPv4 addresses. */
    private void showDnsHostEditor() {
        if (getActivity() == null || mProfile == null) return;
        final Activity activity = getActivity();
        final int pad = (int) (16 * activity.getResources().getDisplayMetrics().density + 0.5f);
        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad / 2, pad, 0);

        TextView help = new TextView(activity);
        help.setText(R.string.dns_host_editor_help);
        root.addView(help, new LinearLayout.LayoutParams(-1, -2));

        // One-tap presets for the two supported service rules.
        LinearLayout presets = new LinearLayout(activity);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        Button googlePreset = new Button(activity);
        googlePreset.setText("Google");
        googlePreset.setAllCaps(false);
        Button xPreset = new Button(activity);
        xPreset.setText("X");
        xPreset.setAllCaps(false);
        presets.addView(googlePreset, new LinearLayout.LayoutParams(0, -2, 1f));
        presets.addView(xPreset, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(presets, new LinearLayout.LayoutParams(-1, -2));

        TextView domainLabel = new TextView(activity);
        domainLabel.setText(R.string.dns_host_domain_label);
        domainLabel.setPadding(0, pad, 0, pad / 3);
        root.addView(domainLabel);
        final EditText domain = new EditText(activity);
        domain.setSingleLine(true);
        domain.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        domain.setHint(R.string.dns_host_domain_hint);
        root.addView(domain, new LinearLayout.LayoutParams(-1, -2));

        TextView ip1Label = new TextView(activity);
        ip1Label.setText(R.string.dns_host_ip1_label);
        ip1Label.setPadding(0, pad / 2, 0, pad / 3);
        root.addView(ip1Label);
        final EditText ip1 = new EditText(activity);
        ip1.setSingleLine(true);
        ip1.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        ip1.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(15)});
        ip1.setHint("65.109.184.128");
        root.addView(ip1, new LinearLayout.LayoutParams(-1, -2));

        TextView ip2Label = new TextView(activity);
        ip2Label.setText(R.string.dns_host_ip2_label);
        ip2Label.setPadding(0, pad / 2, 0, pad / 3);
        root.addView(ip2Label);
        final EditText ip2 = new EditText(activity);
        ip2.setSingleLine(true);
        ip2.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        ip2.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(15)});
        ip2.setHint("91.107.241.144");
        root.addView(ip2, new LinearLayout.LayoutParams(-1, -2));

        Button addUpdate = new Button(activity);
        addUpdate.setText(R.string.dns_host_add_update);
        root.addView(addUpdate, new LinearLayout.LayoutParams(-1, -2));

        TextView savedLabel = new TextView(activity);
        savedLabel.setText(R.string.dns_host_existing);
        savedLabel.setPadding(0, pad, 0, pad / 3);
        root.addView(savedLabel);

        ScrollView listScroll = new ScrollView(activity);
        LinearLayout rulesContainer = new LinearLayout(activity);
        rulesContainer.setOrientation(LinearLayout.VERTICAL);
        listScroll.addView(rulesContainer, new ScrollView.LayoutParams(-1, -2));
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, (int) (160 * activity.getResources().getDisplayMetrics().density));
        root.addView(listScroll, scrollParams);

        final AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(R.string.dns_host_editor_title)
                .setView(root)
                .setPositiveButton(android.R.string.ok, null)
                .create();

        final Runnable[] refreshRules = new Runnable[1];
        refreshRules[0] = new Runnable() {
            @Override public void run() {
                rulesContainer.removeAllViews();
                String raw = mProfile.getDnsHostOverrides();
                String[] lines = raw.split("\n");
                boolean hasRules = false;
                for (final String line : lines) {
                    final String value = line.trim();
                    if (value.isEmpty() || value.startsWith("#")) continue;
                    int eq = value.indexOf('=');
                    if (eq <= 0) continue;
                    hasRules = true;
                    final String host = value.substring(0, eq).trim();
                    final String[] ips = value.substring(eq + 1).split(",");
                    LinearLayout row = new LinearLayout(activity);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    Button select = new Button(activity);
                    String[] displayIps = ips;
                    StringBuilder display = new StringBuilder(host);
                    for (String displayIp : displayIps) {
                        if (displayIp != null && !displayIp.trim().isEmpty()) {
                            display.append("\n").append(displayIp.trim());
                        }
                    }
                    select.setText(display.toString());
                    select.setAllCaps(false);
                    select.setSingleLine(false);
                    select.setMaxLines(4);
                    select.setGravity(android.view.Gravity.CENTER_VERTICAL | android.view.Gravity.START);
                    select.setTextSize(12);
                    select.setPadding(pad / 2, pad / 3, pad / 2, pad / 3);
                    select.setOnClickListener(v -> {
                        domain.setText(host);
                        ip1.setText(ips.length > 0 ? ips[0].trim() : "");
                        ip2.setText(ips.length > 1 ? ips[1].trim() : "");
                    });
                    row.addView(select, new LinearLayout.LayoutParams(0, -2, 1f));
                    Button remove = new Button(activity);
                    remove.setText(R.string.dns_host_remove);
                    remove.setAllCaps(false);
                    remove.setOnClickListener(v -> {
                        StringBuilder updated = new StringBuilder();
                        for (String candidate : mProfile.getDnsHostOverrides().split("\n")) {
                            if (candidate.trim().isEmpty()) continue;
                            int split = candidate.indexOf('=');
                            String candidateHost = split > 0 ? candidate.substring(0, split).trim() : "";
                            if (!candidateHost.equalsIgnoreCase(host)) {
                                if (updated.length() > 0) updated.append('\n');
                                updated.append(candidate.trim());
                            }
                        }
                        try {
                            mProfile.setDnsHostOverrides(net.typeblog.socks.util.DnsHostOverrides.normalizeEditorText(updated.toString()));
                            updateDnsHostsSummary();
                            refreshRules[0].run();
                        } catch (IllegalArgumentException error) {
                            Toast.makeText(activity, error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                    row.addView(remove, new LinearLayout.LayoutParams(-2, -2));
                    rulesContainer.addView(row, new LinearLayout.LayoutParams(-1, -2));
                }
                if (!hasRules) {
                    TextView empty = new TextView(activity);
                    empty.setText(R.string.dns_host_empty);
                    rulesContainer.addView(empty);
                }
            }
        };

        googlePreset.setOnClickListener(v -> {
            domain.setText("regexp:(google)");
            ip1.setText("65.109.184.128");
            ip2.setText("91.107.241.144");
            addUpdate.performClick();
        });
        xPreset.setOnClickListener(v -> {
            domain.setText("regexp:(^|\\.)(x\\.com|twitter\\.com|t\\.co|twimg\\.com)$");
            ip1.setText("65.109.184.128");
            ip2.setText("91.107.241.144");
            addUpdate.performClick();
        });

        addUpdate.setOnClickListener(v -> {
            String host = domain.getText().toString().trim();
            String first = ip1.getText().toString().trim();
            String second = ip2.getText().toString().trim();
            if (host.isEmpty() || first.isEmpty()) {
                Toast.makeText(activity, R.string.dns_host_invalid, Toast.LENGTH_LONG).show();
                return;
            }
            String mapping = host + "=" + first + (second.isEmpty() ? "" : "," + second);
            StringBuilder updated = new StringBuilder();
            boolean replaced = false;
            for (String candidate : mProfile.getDnsHostOverrides().split("\n")) {
                String value = candidate.trim();
                if (value.isEmpty()) continue;
                int eq = value.indexOf('=');
                String candidateHost = eq > 0 ? value.substring(0, eq).trim() : "";
                if (candidateHost.equalsIgnoreCase(host)) {
                    if (!replaced) {
                        if (updated.length() > 0) updated.append('\n');
                        updated.append(mapping);
                        replaced = true;
                    }
                } else {
                    if (updated.length() > 0) updated.append('\n');
                    updated.append(value);
                }
            }
            if (!replaced) {
                if (updated.length() > 0) updated.append('\n');
                updated.append(mapping);
            }
            try {
                String normalized = net.typeblog.socks.util.DnsHostOverrides.normalizeEditorText(updated.toString());
                mProfile.setDnsHostOverrides(normalized);
                updateDnsHostsSummary();
                domain.setText("");
                ip1.setText("");
                ip2.setText("");
                refreshRules[0].run();
                Toast.makeText(activity, R.string.dns_host_saved, Toast.LENGTH_SHORT).show();
            } catch (IllegalArgumentException error) {
                Toast.makeText(activity, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        dialog.setOnShowListener(ignored -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> dialog.dismiss());
            refreshRules[0].run();
        });
        dialog.show();
    }

    private String selectedAppsSummary() {
        String raw = mProfile == null ? "" : mProfile.getAppList();
        if (raw.trim().isEmpty()) return "No apps selected · VPN bypasses all apps";
        String mode = raw.startsWith("B|") ? "Bypass selected apps" : "VPN selected apps";
        int count = raw.split("\\n").length;
        return mode + " · " + count + " app(s)";
    }

    private void showAppPicker() {
        final Activity activity = getActivity();
        if (activity == null) return;
        final PackageManager pm = activity.getPackageManager();
        final java.util.LinkedHashMap<String, ApplicationInfo> found = new java.util.LinkedHashMap<>();
        Intent launchIntent = new Intent(Intent.ACTION_MAIN);
        launchIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo ri : pm.queryIntentActivities(launchIntent, 0)) {
            if (ri.activityInfo != null && ri.activityInfo.applicationInfo != null) {
                ApplicationInfo ai = ri.activityInfo.applicationInfo;
                if (!activity.getPackageName().equals(ai.packageName)) found.put(ai.packageName, ai);
            }
        }
        final java.util.ArrayList<ApplicationInfo> apps = new java.util.ArrayList<>(found.values());
        java.util.Collections.sort(apps, (a,b) -> pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString()));
        if (apps.isEmpty()) return;

        final java.util.HashMap<String, String> rules = new java.util.HashMap<>();
        String saved = mProfile.getAppList();
        for (String line : saved.split("\\n")) {
            if (line.startsWith("V|") || line.startsWith("B|")) rules.put(line.substring(2), line.substring(0,1));
            else if (!line.trim().isEmpty()) rules.put(line.trim(), mProfile.isBypassApp() ? "B" : "V");
        }

        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(12 * activity.getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);
        ScrollView scroll = new ScrollView(activity);
        LinearLayout rows = new LinearLayout(activity);
        rows.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(rows);
        final java.util.HashMap<String, android.widget.RadioGroup> groups = new java.util.HashMap<>();
        for (ApplicationInfo app : apps) {
            String pkg = app.packageName;
            LinearLayout row = new LinearLayout(activity);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(0, pad/2, 0, pad/2);
            TextView label = new TextView(activity);
            label.setText(pm.getApplicationLabel(app));
            row.addView(label);
            android.widget.RadioGroup rg = new android.widget.RadioGroup(activity);
            rg.setOrientation(android.widget.RadioGroup.HORIZONTAL);
            android.widget.RadioButton none = new android.widget.RadioButton(activity); none.setText("None"); none.setId(0);
            android.widget.RadioButton vpn = new android.widget.RadioButton(activity); vpn.setText("VPN"); vpn.setId(1);
            android.widget.RadioButton bypass = new android.widget.RadioButton(activity); bypass.setText("Bypass"); bypass.setId(2);
            rg.addView(none); rg.addView(vpn); rg.addView(bypass);
            String rule = rules.get(pkg);
            rg.check("V".equals(rule) ? 1 : "B".equals(rule) ? 2 : 0);
            rg.setOnCheckedChangeListener((group, checkedId) -> {
                if (checkedId == 0) rules.remove(pkg);
                else {
                    String selectedMode = checkedId == 1 ? "V" : "B";
                    rules.clear();
                    for (java.util.Map.Entry<String, android.widget.RadioGroup> entry : groups.entrySet()) {
                        if (entry.getValue().getCheckedRadioButtonId() == checkedId) rules.put(entry.getKey(), selectedMode);
                        else if (entry.getValue().getCheckedRadioButtonId() != 0) entry.getValue().check(0);
                    }
                    rules.put(pkg, selectedMode);
                }
            });
            groups.put(pkg, rg);
            row.addView(rg);
            rows.addView(row);
            View divider = new View(activity); divider.setBackgroundColor(0x22000000);
            rows.addView(divider, new LinearLayout.LayoutParams(-1, 1));
        }
        root.addView(scroll, new LinearLayout.LayoutParams(-1, (int)(440 * activity.getResources().getDisplayMetrics().density)));
        new AlertDialog.Builder(activity).setTitle(R.string.adv_app_list).setView(root)
                .setPositiveButton(android.R.string.ok, (d,w) -> {
                    java.util.ArrayList<String> lines = new java.util.ArrayList<>();
                    for (ApplicationInfo app : apps) {
                        String mode = rules.get(app.packageName);
                        if (mode != null) lines.add(mode + "|" + app.packageName);
                    }
                    mProfile.setAppList(android.text.TextUtils.join("\n", lines));
                    mProfile.setIsPerApp(true);
                    mPrefAppList.setSummary(selectedAppsSummary());
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void resetList(ListPreference... pref) {
        for (ListPreference p : pref)
            p.setSummary(p.getEntry());
    }

    private void resetListN(ListPreference pref, Object newValue) {
        pref.setSummary(newValue.toString());
    }

    private void resetText(EditTextPreference... pref) {
        for (EditTextPreference p : pref) {
            if ((p.getEditText().getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) != InputType.TYPE_TEXT_VARIATION_PASSWORD) {
                p.setSummary(p.getText());
            } else {
                if (p.getText().length() > 0)
                    p.setSummary(String.format(Locale.US,
                            String.format(Locale.US, "%%0%dd", p.getText().length()), 0)
                            .replace("0", "*"));
                else
                    p.setSummary("");
            }
        }
    }

    private void resetTextN(EditTextPreference pref, Object newValue) {
        if ((pref.getEditText().getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) != InputType.TYPE_TEXT_VARIATION_PASSWORD) {
            pref.setSummary(newValue.toString());
        } else {
            String text = newValue.toString();
            if (text.length() > 0)
                pref.setSummary(String.format(Locale.US,
                        String.format(Locale.US, "%%0%dd", text.length()), 0)
                        .replace("0", "*"));
            else
                pref.setSummary("");
        }
    }

    private void addProfile() {
        final EditText e = new EditText(getActivity());
        e.setSingleLine(true);

        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.prof_add)
                .setView(e)
                .setPositiveButton(android.R.string.ok, (d, which) -> {
                    String name = e.getText().toString().trim();

                    if (!TextUtils.isEmpty(name)) {
                        Profile p = mManager.addProfile(name);

                        if (p != null) {
                            mProfile = p;
                            reload();
                            return;
                        }
                    }

                    Toast.makeText(getActivity(),
                            String.format(getString(R.string.err_add_prof), name),
                            Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.cancel, (d, which) -> {

                })
                .create().show();
    }

    private void renameProfile() {
        final EditText input = new EditText(getActivity());
        input.setSingleLine(true);
        input.setText(mProfile.getName());
        new AlertDialog.Builder(getActivity()).setTitle(R.string.prof_rename).setView(input)
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    String newName = input.getText().toString().trim();
                    if (mManager.renameProfile(mProfile.getName(), newName)) {
                        mProfile = mManager.getProfile(newName);
                        reload();
                        Toast.makeText(getActivity(), "Profile renamed", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getActivity(), "Invalid or duplicate profile name", Toast.LENGTH_LONG).show();
                    }
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void removeProfile() {
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.prof_del)
                .setMessage(String.format(getString(R.string.prof_del_confirm), mProfile.getName()))
                .setPositiveButton(android.R.string.ok, (d, which) -> {
                    if (!mManager.removeProfile(mProfile.getName())) {
                        Toast.makeText(getActivity(),
                                getString(R.string.err_del_prof, mProfile.getName()),
                                Toast.LENGTH_SHORT).show();
                    } else {
                        mProfile = mManager.getDefault();
                        reload();
                    }
                })
                .setNegativeButton(android.R.string.cancel, (d, which) -> {

                })
                .create().show();
    }

    private boolean mBound = false;
    private boolean mReceiverRegistered = false;
    private final BroadcastReceiver mStateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            mStopHandler.removeCallbacks(mStopTimeout);
            mRunning = intent.getBooleanExtra("running", false);
            mStarting = false;
            String error = intent.getStringExtra("error");
            updateState();
            if (!TextUtils.isEmpty(error) && getActivity() != null) {
                Toast.makeText(getActivity(), error, Toast.LENGTH_LONG).show();
            }
        }
    };
    private void checkState() {
        if (mSwitch == null || getActivity() == null) return;

        // Never disable the main switch while querying service state.
        // BIND_AUTO_CREATE is required: bindService(..., 0) returns false when
        // the VPN service has not been started yet, which previously left the
        // switch disabled forever on a fresh launch.
        mSwitch.setEnabled(true);
        mSwitch.setOnCheckedChangeListener(this);

        if (mBound && mBinder != null) {
            try {
                mRunning = mBinder.isRunning();
            } catch (Exception ignored) {
                mRunning = false;
            }
            if (mStarting && !mRunning) {
                keepSwitchOnWhileStarting();
            } else {
                updateState();
            }
            return;
        }

        if (!mBound) {
            try {
                mBound = getActivity().bindService(
                        new Intent(getActivity(), SocksVpnService.class),
                        mConnection,
                        Context.BIND_AUTO_CREATE
                );
            } catch (Exception ignored) {
                mBound = false;
            }
        }
    }

    private void keepSwitchOnWhileStarting() {
        if (mSwitch == null) return;
        mSwitch.setOnCheckedChangeListener(null);
        mSwitch.setChecked(true);
        mSwitch.setEnabled(true);
        mSwitch.setOnCheckedChangeListener(ProfileFragment.this);
    }

    private void updateState() {
        if (mSwitch == null) return;
        mStopHandler.removeCallbacks(mStopTimeout);
        mSwitch.setOnCheckedChangeListener(null);
        mSwitch.setChecked(mRunning);
        mSwitch.setEnabled(true);
        mStarting = false;
        mStopping = false;
        mSwitch.setOnCheckedChangeListener(ProfileFragment.this);
    }

    private void startVpn() {
        try {
            net.typeblog.socks.util.ByeDpiSettings.fromSettings(
                    mProfile.getTlsRecordPositions(), mProfile.getDesyncMode(), mProfile.getDnsHostOverrides());
        } catch (IllegalArgumentException e) {
            Toast.makeText(getActivity(), R.string.fragment_config_invalid, Toast.LENGTH_LONG).show();
            resetMainSwitch();
            return;
        }
        mStarting = true;
        Intent i = VpnService.prepare(getActivity());
        if (i != null) startActivityForResult(i, 0);
        else onActivityResult(0, Activity.RESULT_OK, null);
    }

    private void resetMainSwitch() {
        mStarting = false;
        if (mSwitch != null) {
            mSwitch.setOnCheckedChangeListener(null);
            mSwitch.setChecked(false);
            mSwitch.setEnabled(true);
            mSwitch.setOnCheckedChangeListener(this);
        }
    }

    private void stopVpn() {
        mStopping = true;
        mStopHandler.removeCallbacks(mStopTimeout);
        if (getActivity() != null) {
            // Do not rely on stopService()/onDestroy() for VpnService shutdown.
            // The explicit command reaches onStartCommand and closes the VPN TUN fd.
            try {
                Intent stop = new Intent(getActivity(), SocksVpnService.class)
                        .setAction(SocksVpnService.ACTION_STOP);
                getActivity().startService(stop);
            } catch (Exception ignored) {
                // Keep a lifecycle fallback if Android rejects the explicit command.
                try { getActivity().stopService(new Intent(getActivity(), SocksVpnService.class)); }
                catch (Exception ignoredAgain) { }
            }
        }

        mBinder = null;
        mRunning = false;
        if (mSwitch != null) {
            mSwitch.setOnCheckedChangeListener(null);
            mSwitch.setChecked(false);
            mSwitch.setEnabled(true);
            mSwitch.setOnCheckedChangeListener(this);
        }
        if (mBound && getActivity() != null) {
            try { getActivity().unbindService(mConnection); } catch (Exception ignored) { }
            mBound = false;
        }
        mStopHandler.postDelayed(mStopTimeout, 2500L);
    }
}
