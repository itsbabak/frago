#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CAP 64
int main(void) {
  uint8_t ring[CAP], reference[CAP];
  int head = 0, used = 0, ref_used = 0;
  unsigned seed = 20261126;
  for (int step = 0; step < 200000; ++step) {
    seed = seed * 1664525u + 1013904223u;
    int do_write = ((seed >> 30) & 1) && ref_used < CAP;
    if (do_write) {
      int n = 1 + (int)((seed >> 8) % (unsigned)(CAP - ref_used));
      for (int i = 0; i < n; ++i) {
        uint8_t v = (uint8_t)(seed + (unsigned)i + (unsigned)step);
        int pos = (head + used) % CAP;
        ring[pos] = v;
        reference[ref_used++] = v;
        used++;
      }
    } else if (ref_used) {
      int contiguous = CAP - head;
      if (contiguous > used) contiguous = used;
      int n = 1 + (int)((seed >> 12) % (unsigned)contiguous);
      assert(n <= used && n <= ref_used);
      assert(memcmp(ring + head, reference, (size_t)n) == 0);
      head = (head + n) % CAP;
      used -= n;
      memmove(reference, reference + n, (size_t)(ref_used - n));
      ref_used -= n;
      if (!used) head = 0;
    }
    assert(used == ref_used);
    for (int i = 0; i < used; ++i)
      assert(ring[(head + i) % CAP] == reference[i]);
  }
  puts("ring-buffer randomized test: PASS (200000 operations)");
  return 0;
}
