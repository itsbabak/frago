#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

# Resolve the NDK installed by Android SDK / GitHub Actions.
if ! command -v ndk-build >/dev/null 2>&1; then
    NDK_ROOT="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
    if [[ -z "$NDK_ROOT" && -n "${ANDROID_HOME:-}" ]]; then
        NDK_ROOT="$ANDROID_HOME/ndk/26.3.11579264"
    fi
    if [[ -z "$NDK_ROOT" && -n "${ANDROID_SDK_ROOT:-}" ]]; then
        NDK_ROOT="$ANDROID_SDK_ROOT/ndk/26.3.11579264"
    fi
    if [[ -z "$NDK_ROOT" || ! -x "$NDK_ROOT/ndk-build" ]]; then
        echo "ERROR: ndk-build was not found. Install Android NDK 26.3.11579264 or set ANDROID_NDK_HOME." >&2
        exit 1
    fi
    NDK_BUILD="$NDK_ROOT/ndk-build"
else
    NDK_BUILD="$(command -v ndk-build)"
fi

rm -rf jniLibs libs
"$NDK_BUILD" APP_ABI=arm64-v8a APP_PLATFORM=android-21
mkdir -p jniLibs/arm64-v8a
mv libs/arm64-v8a/tun2socks jniLibs/arm64-v8a/libtun2socks.so
mv libs/arm64-v8a/libsystem.so jniLibs/arm64-v8a/libsystem.so
rm -rf libs

# Sanity-check that the rebuilt tunnel exposes the Android UDP relay switch.
if ! strings jniLibs/arm64-v8a/libtun2socks.so | grep -q -- '--enable-udprelay'; then
    echo "ERROR: tun2socks was built without the Android UDP relay support." >&2
    exit 1
fi

echo "Built Frago ARM64 native libraries (TCP + Android SOCKS UDP relay)."
