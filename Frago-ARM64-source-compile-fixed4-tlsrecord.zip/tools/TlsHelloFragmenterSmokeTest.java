import java.io.ByteArrayOutputStream;
import java.util.Arrays;

import net.typeblog.socks.engine.FragoTlsHelloFragmenter;

/** Build-time smoke test for Frago's independent TLS record fragmenter. */
public final class TlsHelloFragmenterSmokeTest {
    private static int u16(byte[] data, int pos) {
        return ((data[pos] & 0xff) << 8) | (data[pos + 1] & 0xff);
    }

    public static void main(String[] args) throws Exception {
        byte[] helloPayload = new byte[1000];
        helloPayload[0] = 1; // ClientHello handshake type
        helloPayload[1] = 0;
        helloPayload[2] = 3;
        helloPayload[3] = (byte) 0xe4; // Handshake body length = 996
        for (int i = 4; i < helloPayload.length; i++) {
            helloPayload[i] = (byte) (i * 17);
        }

        byte[] trailing = new byte[]{0x17, 0x03, 0x03, 0, 3, 1, 2, 3};
        ByteArrayOutputStream input = new ByteArrayOutputStream();
        input.write(new byte[]{0x16, 0x03, 0x03, 0x03, (byte) 0xe8});
        input.write(helloPayload);
        input.write(trailing);
        byte[] original = input.toByteArray();

        if (!FragoTlsHelloFragmenter.canFragment(original)) {
            throw new AssertionError("Complete TLS ClientHello record was not recognized");
        }

        ByteArrayOutputStream output = new ByteArrayOutputStream();
        int expectedRecords = FragoTlsHelloFragmenter.write(output, original, 100, 100, 0, 0);
        byte[] fragmented = output.toByteArray();

        ByteArrayOutputStream rebuiltPayload = new ByteArrayOutputStream();
        int offset = 0;
        int seenRecords = 0;
        while (offset + 5 <= fragmented.length && (fragmented[offset] & 0xff) == 0x16) {
            int partLength = u16(fragmented, offset + 3);
            if (partLength <= 0 || partLength > 100 || offset + 5 + partLength > fragmented.length) {
                throw new AssertionError("Invalid TLS record length");
            }
            if ((fragmented[offset + 1] & 0xff) != 3 || (fragmented[offset + 2] & 0xff) != 3) {
                throw new AssertionError("TLS record version was not preserved");
            }
            rebuiltPayload.write(fragmented, offset + 5, partLength);
            offset += 5 + partLength;
            seenRecords++;
        }

        if (seenRecords != expectedRecords || seenRecords != 10) {
            throw new AssertionError("Unexpected fragment count: " + seenRecords);
        }
        if (!Arrays.equals(helloPayload, rebuiltPayload.toByteArray())) {
            throw new AssertionError("ClientHello handshake bytes changed during fragmentation");
        }
        if (!Arrays.equals(trailing, Arrays.copyOfRange(fragmented, offset, fragmented.length))) {
            throw new AssertionError("Bytes after the initial TLS record were not preserved");
        }
        if (FragoTlsHelloFragmenter.canFragment(new byte[]{0x17, 0x03, 0x03, 0, 4, 1, 2, 3, 4})) {
            throw new AssertionError("Non-handshake TLS record was incorrectly accepted");
        }

        System.out.println("PASS: " + seenRecords + " valid TLS records; handshake payload and trailing bytes preserved.");
    }
}
