package net.typeblog.socks.util;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Lightweight local DNS relay combining host overrides, White DNS resolution,
 * and low-overhead caching with minimal CPU/battery footprint.
 */
public final class LocalDnsRelay {
    public interface SocketProtector {
        boolean protect(DatagramSocket socket);
        boolean protectSocket(Socket socket);
    }

    private static final int MAX_DNS_PACKET = 4096;
    private static final int DNS_CACHE_MAX_ENTRIES = 128;

    private final DnsHostOverrides hostOverrides;
    private final SocketProtector protector;
    private final int socksPort;
    private final boolean whiteDnsEnabled;
    private final String configuredWhiteDns;
    private final WhiteDnsResolver whiteDnsResolver;
    private volatile List<String> systemDnsServers = Collections.emptyList();
    private volatile boolean running;
    private DatagramSocket serverSocket;
    private Thread listenerThread;
    private ThreadPoolExecutor pool;
    private final Map<String, CachedDnsAnswer> dnsCache = Collections.synchronizedMap(
            new LinkedHashMap<String, CachedDnsAnswer>(DNS_CACHE_MAX_ENTRIES, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, CachedDnsAnswer> eldest) {
                    return size() > DNS_CACHE_MAX_ENTRIES;
                }
            });

    private static final class CachedDnsAnswer {
        final byte[] packet;
        final long expiresAtNanos;
        CachedDnsAnswer(byte[] packet, long expiresAtNanos) {
            this.packet = packet;
            this.expiresAtNanos = expiresAtNanos;
        }
    }

    public LocalDnsRelay(DnsHostOverrides overrides,
                         List<String> systemDnsServers,
                         SocketProtector protector,
                         int socksPort,
                         boolean whiteDnsEnabled,
                         String whiteDnsServers) {
        this.hostOverrides = overrides;
        this.protector = protector;
        this.socksPort = socksPort;
        this.whiteDnsEnabled = whiteDnsEnabled;
        this.configuredWhiteDns = (whiteDnsServers == null || whiteDnsServers.trim().isEmpty())
                ? WhiteDnsResolver.DEFAULT_WHITE_DNS : whiteDnsServers.trim();
        List<String> sanitizedSys = sanitizeDnsList(systemDnsServers);
        this.systemDnsServers = sanitizedSys;
        this.whiteDnsResolver = new WhiteDnsResolver(
                this.configuredWhiteDns,
                sanitizedSys,
                new WhiteDnsResolver.SocketProtector() {
                    @Override
                    public boolean protect(DatagramSocket socket) {
                        return protector != null && protector.protect(socket);
                    }

                    @Override
                    public boolean protectSocket(Socket socket) {
                        return protector != null && protector.protectSocket(socket);
                    }
                },
                socksPort);
    }

    private static List<String> sanitizeDnsList(List<String> raw) {
        if (raw == null || raw.isEmpty()) return Collections.emptyList();
        List<String> out = new ArrayList<>();
        for (String ip : raw) {
            if (WhiteDnsResolver.isValidIpv4(ip)
                    && !ip.startsWith("127.")
                    && !ip.startsWith("26.26.26.")
                    && !out.contains(ip)) {
                out.add(ip);
            }
        }
        return Collections.unmodifiableList(out);
    }

    public void updateUpstreamDns(List<String> newSystemDnsServers) {
        List<String> sanitized = sanitizeDnsList(newSystemDnsServers);
        this.systemDnsServers = sanitized;
        if (this.whiteDnsResolver != null) {
            this.whiteDnsResolver.updateServers(this.configuredWhiteDns, sanitized);
        }
        dnsCache.clear();
    }

    public synchronized void start() throws Exception {
        if (running) return;
        serverSocket = new DatagramSocket(null);
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress("127.0.0.1", 5354));
        serverSocket.setSoTimeout(0);

        ThreadPoolExecutor executor = new ThreadPoolExecutor(
                1, 1, 15L, TimeUnit.SECONDS,
                new LinkedBlockingQueue<Runnable>(32),
                new ThreadFactory() {
                    @Override
                    public Thread newThread(Runnable r) {
                        Thread t = new Thread(r, "Frago-DNS-Worker");
                        t.setDaemon(true);
                        t.setPriority(Thread.MIN_PRIORITY);
                        return t;
                    }
                },
                new ThreadPoolExecutor.DiscardOldestPolicy());
        executor.allowCoreThreadTimeOut(true);
        pool = executor;

        running = true;
        listenerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                byte[] buffer = new byte[MAX_DNS_PACKET];
                while (running) {
                    try {
                        DatagramPacket request = new DatagramPacket(buffer, buffer.length);
                        serverSocket.receive(request);
                        final int len = request.getLength();
                        if (len < 12) continue;
                        final byte[] query = new byte[len];
                        System.arraycopy(request.getData(), request.getOffset(), query, 0, len);
                        final InetAddress clientAddr = request.getAddress();
                        final int clientPort = request.getPort();

                        byte[] override = hostOverrides == null ? null : hostOverrides.answer(query, query.length);
                        if (override != null && override.length > 0) {
                            sendReply(override, clientAddr, clientPort);
                            continue;
                        }

                        byte[] cached = getCachedAnswer(query);
                        if (cached != null) {
                            sendReply(cached, clientAddr, clientPort);
                            continue;
                        }

                        ThreadPoolExecutor currentPool = pool;
                        if (currentPool != null && !currentPool.isShutdown()) {
                            currentPool.execute(new Runnable() {
                                @Override
                                public void run() {
                                    byte[] answer = resolveUpstream(query);
                                    if (answer != null && answer.length > 0 && running) {
                                        cacheAnswer(query, answer);
                                        sendReply(answer, clientAddr, clientPort);
                                    }
                                }
                            });
                        }
                    } catch (IOException ignored) {
                        if (!running) break;
                    } catch (Exception ignored) {
                    }
                }
            }
        }, "Frago-DNS-Listener");
        listenerThread.setDaemon(true);
        listenerThread.start();
    }

    private void sendReply(byte[] answer, InetAddress addr, int port) {
        DatagramSocket sock = serverSocket;
        if (sock == null || sock.isClosed()) return;
        try {
            sock.send(new DatagramPacket(answer, answer.length, addr, port));
        } catch (Exception ignored) {
        }
    }

    private byte[] resolveUpstream(byte[] query) {
        if (whiteDnsEnabled && whiteDnsResolver != null) {
            byte[] whiteReply = whiteDnsResolver.resolveQuery(query);
            if (whiteReply != null && !WhiteDnsResolver.isPoisonedAnswer(whiteReply)) {
                return whiteReply;
            }
        }
        List<String> sys = systemDnsServers;
        if (sys != null && !sys.isEmpty()) {
            WhiteDnsResolver sysFallback = new WhiteDnsResolver(
                    String.join(",", sys),
                    Collections.emptyList(),
                    new WhiteDnsResolver.SocketProtector() {
                        @Override
                        public boolean protect(DatagramSocket socket) {
                            return protector != null && protector.protect(socket);
                        }

                        @Override
                        public boolean protectSocket(Socket socket) {
                            return protector != null && protector.protectSocket(socket);
                        }
                    },
                    socksPort);
            byte[] sysReply = sysFallback.resolveQuery(query);
            if (sysReply != null && !WhiteDnsResolver.isPoisonedAnswer(sysReply)) {
                return sysReply;
            }
        }
        return null;
    }

    private static String cacheKey(byte[] query) {
        if (query == null || query.length < 12) return null;
        return new String(query, 2, query.length - 2, java.nio.charset.StandardCharsets.ISO_8859_1);
    }

    private byte[] getCachedAnswer(byte[] query) {
        String key = cacheKey(query);
        if (key == null) return null;
        CachedDnsAnswer entry = dnsCache.get(key);
        if (entry == null) return null;
        if (System.nanoTime() >= entry.expiresAtNanos) {
            dnsCache.remove(key);
            return null;
        }
        byte[] answer = entry.packet.clone();
        answer[0] = query[0];
        answer[1] = query[1];
        return answer;
    }

    private void cacheAnswer(byte[] query, byte[] answer) {
        if (query == null || answer == null || query.length < 12 || answer.length < 12
                || answer.length > MAX_DNS_PACKET || WhiteDnsResolver.isPoisonedAnswer(answer)) return;
        int flags = ((answer[2] & 0xFF) << 8) | (answer[3] & 0xFF);
        int answerCount = ((answer[6] & 0xFF) << 8) | (answer[7] & 0xFF);
        if ((flags & 0x000F) != 0 || answerCount == 0) return;
        long ttlSeconds = positiveAnswerTtlSeconds(answer);
        if (ttlSeconds <= 0) return;
        String key = cacheKey(query);
        if (key == null) return;
        byte[] copy = answer.clone();
        copy[0] = 0;
        copy[1] = 0;
        long ttlNanos = TimeUnit.SECONDS.toNanos(Math.min(60L, ttlSeconds));
        dnsCache.put(key, new CachedDnsAnswer(copy, System.nanoTime() + ttlNanos));
    }

    private static long positiveAnswerTtlSeconds(byte[] msg) {
        if (msg == null || msg.length < 12) return 0;
        int qd = ((msg[4] & 0xFF) << 8) | (msg[5] & 0xFF);
        int an = ((msg[6] & 0xFF) << 8) | (msg[7] & 0xFF);
        int ns = ((msg[8] & 0xFF) << 8) | (msg[9] & 0xFF);
        int ar = ((msg[10] & 0xFF) << 8) | (msg[11] & 0xFF);
        int pos = 12;
        for (int i = 0; i < qd; i++) {
            pos = skipName(msg, pos);
            if (pos < 0 || pos + 4 > msg.length) return 0;
            pos += 4;
        }
        long minTtl = Long.MAX_VALUE;
        int total = an + ns + ar;
        for (int i = 0; i < total; i++) {
            pos = skipName(msg, pos);
            if (pos < 0 || pos + 10 > msg.length) return 0;
            int type = ((msg[pos] & 0xFF) << 8) | (msg[pos + 1] & 0xFF);
            long ttl = ((long) (msg[pos + 4] & 0xFF) << 24)
                    | ((long) (msg[pos + 5] & 0xFF) << 16)
                    | ((long) (msg[pos + 6] & 0xFF) << 8)
                    | (long) (msg[pos + 7] & 0xFF);
            int rdLen = ((msg[pos + 8] & 0xFF) << 8) | (msg[pos + 9] & 0xFF);
            pos += 10;
            if (pos + rdLen > msg.length) return 0;
            if (i < an && type != 41) minTtl = Math.min(minTtl, ttl);
            pos += rdLen;
        }
        return minTtl == Long.MAX_VALUE ? 0 : minTtl;
    }

    private static int skipName(byte[] msg, int pos) {
        int jumps = 0;
        while (pos < msg.length && jumps < 64) {
            int len = msg[pos] & 0xFF;
            if (len == 0) return pos + 1;
            if ((len & 0xC0) == 0xC0) return pos + 2;
            pos += 1 + len;
            jumps++;
        }
        return -1;
    }

    public synchronized void stop() {
        running = false;
        if (serverSocket != null) {
            try { serverSocket.close(); } catch (Exception ignored) { }
            serverSocket = null;
        }
        if (listenerThread != null) {
            listenerThread.interrupt();
            listenerThread = null;
        }
        if (pool != null) {
            pool.shutdownNow();
            pool = null;
        }
        dnsCache.clear();
    }
}
