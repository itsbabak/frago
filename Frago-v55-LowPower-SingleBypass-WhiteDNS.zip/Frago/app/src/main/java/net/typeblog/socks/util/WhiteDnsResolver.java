package net.typeblog.socks.util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Lightweight White DNS resolver using clean/whitelisted upstream DNS servers
 * over protected UDP (port 53) with SOCKS5 TCP fallback, avoiding TLS/DoH/DoT
 * handshake overhead for lower CPU and battery consumption.
 */
public final class WhiteDnsResolver {
    public interface SocketProtector {
        boolean protect(DatagramSocket socket);
        boolean protectSocket(Socket socket);
    }

    public static final String DEFAULT_WHITE_DNS = "78.157.42.100,78.157.42.101,178.22.122.100,185.51.200.2";
    private static final int UDP_TIMEOUT_MS = 1200;
    private static final int TCP_TIMEOUT_MS = 2500;
    private static final int MAX_DNS_PACKET = 4096;

    private final SocketProtector protector;
    private final int socksPort;
    private volatile List<String> servers;

    public WhiteDnsResolver(String configuredServers, List<String> systemDnsServers,
                            SocketProtector protector, int socksPort) {
        this.protector = protector;
        this.socksPort = socksPort;
        updateServers(configuredServers, systemDnsServers);
    }

    public static String normalizeServersText(String raw) {
        if (raw == null || raw.trim().isEmpty()) {
            return DEFAULT_WHITE_DNS;
        }
        String cleaned = raw.replace(';', ',').replace('\n', ',').replace('\r', ',');
        String[] tokens = cleaned.split(",");
        LinkedHashSet<String> valid = new LinkedHashSet<>();
        for (String tok : tokens) {
            String ip = tok.trim();
            if (ip.isEmpty()) continue;
            if (!isValidIpv4(ip)) {
                throw new IllegalArgumentException("Invalid IPv4 DNS server: " + ip);
            }
            if (!ip.startsWith("127.") && !ip.startsWith("26.26.26.")) {
                valid.add(ip);
            }
        }
        if (valid.isEmpty()) {
            return DEFAULT_WHITE_DNS;
        }
        return String.join(",", valid);
    }

    public void updateServers(String configuredServers, List<String> systemDnsServers) {
        Set<String> ordered = new LinkedHashSet<>();
        String normalized = DEFAULT_WHITE_DNS;
        try {
            normalized = normalizeServersText(configuredServers);
        } catch (Exception ignored) {
            normalized = DEFAULT_WHITE_DNS;
        }
        for (String ip : normalized.split(",")) {
            if (isValidIpv4(ip.trim())) ordered.add(ip.trim());
        }
        if (systemDnsServers != null) {
            for (String sysIp : systemDnsServers) {
                if (isValidIpv4(sysIp) && !sysIp.startsWith("127.") && !sysIp.startsWith("26.26.26.")) {
                    ordered.add(sysIp);
                }
            }
        }
        this.servers = Collections.unmodifiableList(new ArrayList<>(ordered));
    }

    public byte[] resolveQuery(byte[] query) {
        if (query == null || query.length < 12) return null;
        List<String> list = this.servers;
        int limit = Math.min(list.size(), 4);
        for (int i = 0; i < limit; i++) {
            String ip = list.get(i);
            byte[] udpReply = queryUdp(ip, 53, query);
            if (udpReply != null && !isPoisonedAnswer(udpReply)) {
                return udpReply;
            }
        }
        for (int i = 0; i < Math.min(list.size(), 2); i++) {
            String ip = list.get(i);
            byte[] tcpReply = queryTcpViaSocks(ip, 53, query);
            if (tcpReply != null && !isPoisonedAnswer(tcpReply)) {
                return tcpReply;
            }
        }
        return null;
    }

    private byte[] queryUdp(String serverIp, int port, byte[] query) {
        DatagramSocket sock = null;
        try {
            sock = new DatagramSocket();
            if (protector != null) protector.protect(sock);
            sock.setSoTimeout(UDP_TIMEOUT_MS);
            InetAddress dest = InetAddress.getByName(serverIp);
            sock.send(new DatagramPacket(query, query.length, dest, port));
            byte[] buf = new byte[MAX_DNS_PACKET];
            DatagramPacket resp = new DatagramPacket(buf, buf.length);
            sock.receive(resp);
            int len = resp.getLength();
            if (len < 12) return null;
            byte[] result = new byte[len];
            System.arraycopy(buf, 0, result, 0, len);
            return result;
        } catch (Exception ignored) {
            return null;
        } finally {
            if (sock != null) try { sock.close(); } catch (Exception ignored) { }
        }
    }

    private byte[] queryTcpViaSocks(String dnsIp, int dnsPort, byte[] query) {
        Socket sock = null;
        try {
            byte[] ipBytes = InetAddress.getByName(dnsIp).getAddress();
            if (ipBytes.length != 4) return null;

            sock = new Socket();
            if (protector != null) protector.protectSocket(sock);
            sock.connect(new InetSocketAddress("127.0.0.1", socksPort), TCP_TIMEOUT_MS);
            sock.setSoTimeout(TCP_TIMEOUT_MS);
            sock.setTcpNoDelay(true);

            DataOutputStream out = new DataOutputStream(sock.getOutputStream());
            DataInputStream in = new DataInputStream(sock.getInputStream());

            out.write(new byte[]{0x05, 0x01, 0x00});
            out.flush();
            byte[] greetResp = new byte[2];
            in.readFully(greetResp);
            if (greetResp[0] != 0x05 || greetResp[1] != 0x00) return null;

            byte[] req = new byte[10];
            req[0] = 0x05;
            req[1] = 0x01;
            req[2] = 0x00;
            req[3] = 0x01;
            System.arraycopy(ipBytes, 0, req, 4, 4);
            req[8] = (byte) ((dnsPort >> 8) & 0xFF);
            req[9] = (byte) (dnsPort & 0xFF);
            out.write(req);
            out.flush();

            byte[] connHdr = new byte[4];
            in.readFully(connHdr);
            if (connHdr[0] != 0x05 || connHdr[1] != 0x00) return null;
            int atyp = connHdr[3] & 0xFF;
            if (atyp == 1) in.readFully(new byte[6]);
            else if (atyp == 4) in.readFully(new byte[18]);
            else if (atyp == 3) in.readFully(new byte[in.readUnsignedByte() + 2]);
            else return null;

            out.writeShort(query.length);
            out.write(query);
            out.flush();

            int respLen = in.readUnsignedShort();
            if (respLen < 12 || respLen > MAX_DNS_PACKET) return null;
            byte[] resp = new byte[respLen];
            in.readFully(resp);
            return resp;
        } catch (Exception ignored) {
            return null;
        } finally {
            if (sock != null) try { sock.close(); } catch (Exception ignored) { }
        }
    }

    static boolean isPoisonedAnswer(byte[] msg) {
        if (msg == null || msg.length < 12) return false;
        int anCount = ((msg[6] & 0xFF) << 8) | (msg[7] & 0xFF);
        if (anCount <= 0) return false;
        int qdCount = ((msg[4] & 0xFF) << 8) | (msg[5] & 0xFF);
        int pos = 12;
        for (int i = 0; i < qdCount; i++) {
            pos = skipName(msg, pos);
            if (pos < 0 || pos + 4 > msg.length) return false;
            pos += 4;
        }
        for (int i = 0; i < anCount; i++) {
            pos = skipName(msg, pos);
            if (pos < 0 || pos + 10 > msg.length) return false;
            int type = ((msg[pos] & 0xFF) << 8) | (msg[pos + 1] & 0xFF);
            int rdLen = ((msg[pos + 8] & 0xFF) << 8) | (msg[pos + 9] & 0xFF);
            pos += 10;
            if (pos + rdLen > msg.length) return false;
            if (type == 1 && rdLen == 4) {
                int a = msg[pos] & 0xFF;
                int b = msg[pos + 1] & 0xFF;
                int c = msg[pos + 2] & 0xFF;
                int d = msg[pos + 3] & 0xFF;
                if ((a == 10 && b == 10 && c == 34 && (d >= 34 && d <= 37))
                        || (a == 0 && b == 0 && c == 0 && d == 0)) {
                    return true;
                }
            }
            pos += rdLen;
        }
        return false;
    }

    private static int skipName(byte[] msg, int pos) {
        int jumps = 0;
        while (pos < msg.length && jumps < 64) {
            int len = msg[pos] & 0xFF;
            if (len == 0) return pos + 1;
            if ((len & 0xC0) == 0xC0) return pos + 2;
            pos += 1 + len;
            jumps++;
        }
        return -1;
    }

    static boolean isValidIpv4(String ip) {
        if (ip == null || !ip.matches("[0-9.]+")) return false;
        String[] parts = ip.split("\\.", -1);
        if (parts.length != 4) return false;
        for (String p : parts) {
            if (p.isEmpty() || p.length() > 3) return false;
            try {
                int n = Integer.parseInt(p);
                if (n < 0 || n > 255) return false;
            } catch (NumberFormatException e) {
                return false;
            }
        }
        return true;
    }
}
