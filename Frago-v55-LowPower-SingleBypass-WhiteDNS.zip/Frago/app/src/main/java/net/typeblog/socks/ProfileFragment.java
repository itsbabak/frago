package net.typeblog.socks;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.ServiceConnection;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.IBinder;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.ListPreference;
import android.preference.PreferenceCategory;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.widget.CompoundButton;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import net.typeblog.socks.util.Profile;
import net.typeblog.socks.util.ProfileManager;
import net.typeblog.socks.util.Utility;

import java.util.Locale;

import static net.typeblog.socks.util.Constants.*;

public class ProfileFragment extends PreferenceFragment implements Preference.OnPreferenceClickListener, Preference.OnPreferenceChangeListener,
        CompoundButton.OnCheckedChangeListener {
    private ProfileManager mManager;
    private Profile mProfile;

    private Switch mSwitch;
    private boolean mRunning = false;
    private boolean mStarting = false, mStopping = false;
    private final Handler mStopHandler = new Handler(Looper.getMainLooper());
    private final Runnable mStopTimeout = new Runnable() {
        @Override public void run() {
            if (!mStopping) return;
            // Do not leave the toggle locked if Android drops the state broadcast.
            mRunning = false;
            updateState();
        }
    };
    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName p1, IBinder binder) {
            mBinder = IVpnService.Stub.asInterface(binder);

            try {
                mRunning = mBinder.isRunning();
            } catch (Exception ignored) { mRunning = false; }
            // A bind can complete before onStartCommand has finished starting
            // the tunnel. Do not immediately undo the user's ON action.
            if (mStarting && !mRunning) {
                keepSwitchOnWhileStarting();
                return;
            }
            updateState();
        }

        @Override
        public void onServiceDisconnected(ComponentName p1) {
            mBinder = null;
            mRunning = false;
            if (mStarting) {
                keepSwitchOnWhileStarting();
            } else {
                updateState();
            }
        }
    };
    private IVpnService mBinder;

    private ListPreference mPrefProfile;
    private EditTextPreference mPrefTlsPositions;
    private Preference mPrefDesyncMode;
    private ListPreference mPrefFakeTtl;
    private ListPreference mPrefTlsCount;
    private Preference mPrefDnsHosts;
    private Preference mPrefAppList;
    private CheckBoxPreference mPrefPerApp, mPrefAppBypass, mPrefAuto, mPrefWhiteDnsEnabled;
    private EditTextPreference mPrefWhiteDnsServers;
    private PreferenceCategory mTlsCategory, mDnsCategory, mAdvancedCategory;
    private android.preference.PreferenceScreen mScreen;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings);
        mScreen = getPreferenceScreen();
        mScreen.setOrderingAsAdded(false);
        setHasOptionsMenu(true);
        mManager = new ProfileManager(getActivity().getApplicationContext());
        initPreferences();
        reload();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.main, menu);

        MenuItem s = menu.findItem(R.id.switch_main);
        mSwitch = s.getActionView().findViewById(R.id.switch_action_button);
        mSwitch.setOnCheckedChangeListener(this);
        checkState();
    }


    @Override public void onResume() {
        super.onResume();
        if (!mReceiverRegistered && getActivity() != null) {
            IntentFilter filter = new IntentFilter(SocksVpnService.ACTION_STATE);
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                getActivity().registerReceiver(mStateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                getActivity().registerReceiver(mStateReceiver, filter);
            }
            mReceiverRegistered = true;
        }
        if (mSwitch != null) checkState();
    }
    @Override public void onPause() {
        if (mReceiverRegistered && getActivity() != null) {
            try { getActivity().unregisterReceiver(mStateReceiver); } catch (Exception ignored) { }
            mReceiverRegistered = false;
        }
        if (mBound && getActivity() != null) {
            try { getActivity().unbindService(mConnection); } catch (Exception ignored) { }
            mBound = false; mBinder = null;
        }
        super.onPause();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.prof_add) {
            addProfile();
            return true;
        } else if (id == R.id.prof_del) {
            removeProfile();
            return true;
        } else if (id == R.id.prof_rename) {
            renameProfile();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onPreferenceClick(Preference p) {
        if (p == mPrefAppList) { showAppPicker(); return true; }
        if (p == mPrefDnsHosts) { showDnsHostEditor(); return true; }
        
        return false;
    }

    @Override
    public boolean onPreferenceChange(Preference p, Object newValue) {
        if (p == mPrefProfile) {
            String name = newValue.toString();
            mProfile = mManager.getProfile(name);
            mManager.switchDefault(name);
            reload();
            return true;
        } else if (p == mPrefPerApp) {
            mProfile.setIsPerApp(Boolean.parseBoolean(newValue.toString()));
            return true;
        } else if (p == mPrefAppBypass) {
            mProfile.setIsBypassApp(Boolean.parseBoolean(newValue.toString()));
            return true;
        } else if (p == mPrefAuto) {
            mProfile.setAutoConnect(Boolean.parseBoolean(newValue.toString()));
            return true;
        } else if (p == mPrefTlsCount) {
            try {
                int records = Integer.parseInt(newValue.toString());
                if (records < 1 || records > 16) throw new IllegalArgumentException("Choose between 1 and 16 TLS records");
                String positions = net.typeblog.socks.util.ByeDpiSettings.defaultPositionsForRecordCount(records);
                mProfile.setTlsRecordPositions(positions);
                if (mPrefTlsPositions != null) mPrefTlsPositions.setText(positions);
                if (mPrefTlsCount != null) {
                    mPrefTlsCount.setValue(Integer.toString(records));
                    resetList(mPrefTlsCount);
                }
                updateTlsSummary();
                updateDesyncSummary();
                return true;
            } catch (Exception error) {
                Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_LONG).show();
                return false;
            }
        } else if (p == mPrefTlsPositions) {
            try {
                String normalized = net.typeblog.socks.util.ByeDpiSettings.normalizePositions(newValue.toString());
                mProfile.setTlsRecordPositions(normalized);
                if (mPrefTlsCount != null) mPrefTlsCount.setValue(Integer.toString(net.typeblog.socks.util.ByeDpiSettings.recordCount(normalized)));
                updateTlsSummary();
                return true;
            } catch (IllegalArgumentException error) {
                Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_LONG).show();
                return false;
            }
        } else if (p == mPrefDesyncMode) {
            String mode = net.typeblog.socks.util.ByeDpiSettings.normalizeDesyncMode(newValue.toString());
            mProfile.setDesyncMode(mode);
            updateDesyncSummary();
            return true;
        } else if (p == mPrefFakeTtl) {
            try {
                int ttl = net.typeblog.socks.util.ByeDpiSettings.normalizeFakeTtl(Integer.parseInt(newValue.toString()));
                mProfile.setFakeTtl(ttl);
                mPrefFakeTtl.setValue(Integer.toString(ttl));
                mPrefFakeTtl.setSummary("TTL = " + ttl);
                return true;
            } catch (Exception error) {
                Toast.makeText(getActivity(), "Invalid TTL", Toast.LENGTH_SHORT).show();
                return false;
            }
        } else if (p == mPrefWhiteDnsEnabled) {
            boolean enabled = Boolean.parseBoolean(newValue.toString());
            mProfile.setWhiteDnsEnabled(enabled);
            if (mPrefWhiteDnsServers != null) mPrefWhiteDnsServers.setEnabled(enabled);
            return true;
        } else if (p == mPrefWhiteDnsServers) {
            try {
                String raw = newValue == null ? "" : newValue.toString().trim();
                String clean = net.typeblog.socks.util.WhiteDnsResolver.normalizeServersText(raw);
                mProfile.setWhiteDnsServers(clean);
                if (mPrefWhiteDnsServers != null) {
                    mPrefWhiteDnsServers.setText(clean);
                    mPrefWhiteDnsServers.setSummary(clean);
                }
                return true;
            } catch (IllegalArgumentException err) {
                Toast.makeText(getActivity(), err.getMessage(), Toast.LENGTH_LONG).show();
                return false;
            }
        } else {
            return false;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton p1, boolean checked) {
        if (mStarting || mStopping) {
            if (mSwitch != null) {
                mSwitch.setOnCheckedChangeListener(null);
                mSwitch.setChecked(mRunning || mStarting);
                mSwitch.setOnCheckedChangeListener(this);
            }
            return;
        }
        if (checked) {
            startVpn();
        } else {
            stopVpn();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != 0) return;
        if (resultCode == Activity.RESULT_OK) {
            try {
                Utility.startVpn(getActivity(), mProfile);
                checkState();
            } catch (Exception error) {
                Toast.makeText(getActivity(), R.string.connection_start_failed, Toast.LENGTH_LONG).show();
                resetMainSwitch();
            }
        } else {
            mRunning = false;
            updateState();
        }
    }

    private void initPreferences() {
        mPrefProfile = (ListPreference) findPreference(PREF_PROFILE);
        mAdvancedCategory = (PreferenceCategory) findPreference("advanced");
        mPrefPerApp = (CheckBoxPreference) findPreference(PREF_ADV_PER_APP);
        mPrefAppBypass = (CheckBoxPreference) findPreference(PREF_ADV_APP_BYPASS);
        mPrefAppList = findPreference(PREF_ADV_APP_LIST);
        mPrefAuto = (CheckBoxPreference) findPreference(PREF_ADV_AUTO_CONNECT);
        mTlsCategory = (PreferenceCategory) findPreference("tls_fragment_category");
        mDnsCategory = (PreferenceCategory) findPreference("dns_override_category");
        mPrefTlsCount = (ListPreference) findPreference("tlsrec_count");
        mPrefTlsPositions = (EditTextPreference) findPreference("tlsrec_positions");
        mPrefDesyncMode = findPreference("desync_mode");
        mPrefFakeTtl = (ListPreference) findPreference("fake_ttl");
        mPrefDnsHosts = findPreference("dns_host_overrides");
        mPrefWhiteDnsEnabled = (CheckBoxPreference) findPreference("white_dns_enabled");
        mPrefWhiteDnsServers = (EditTextPreference) findPreference("white_dns_servers");
        if (mPrefTlsCount != null) mPrefTlsCount.setPersistent(false);
        if (mPrefTlsPositions != null) mPrefTlsPositions.setPersistent(false);
        if (mPrefFakeTtl != null) mPrefFakeTtl.setPersistent(false);
        if (mPrefDnsHosts != null) mPrefDnsHosts.setPersistent(false);
        if (mPrefWhiteDnsEnabled != null) mPrefWhiteDnsEnabled.setPersistent(false);
        if (mPrefWhiteDnsServers != null) mPrefWhiteDnsServers.setPersistent(false);

        if (mPrefProfile != null) mPrefProfile.setOnPreferenceChangeListener(this);
        if (mPrefPerApp != null) mPrefPerApp.setOnPreferenceChangeListener(this);
        if (mPrefAppBypass != null) mPrefAppBypass.setOnPreferenceChangeListener(this);
        if (mPrefAppList != null) mPrefAppList.setOnPreferenceClickListener(this);
        if (mPrefAuto != null) mPrefAuto.setOnPreferenceChangeListener(this);
        if (mPrefTlsCount != null) mPrefTlsCount.setOnPreferenceChangeListener(this);
        if (mPrefTlsPositions != null) mPrefTlsPositions.setOnPreferenceChangeListener(this);
        if (mPrefFakeTtl != null) mPrefFakeTtl.setOnPreferenceChangeListener(this);
        if (mPrefDnsHosts != null) mPrefDnsHosts.setOnPreferenceClickListener(this);
        if (mPrefWhiteDnsEnabled != null) mPrefWhiteDnsEnabled.setOnPreferenceChangeListener(this);
        if (mPrefWhiteDnsServers != null) mPrefWhiteDnsServers.setOnPreferenceChangeListener(this);


    }

    private void reload() {
        if (mProfile == null) mProfile = mManager.getDefault();
        if (mProfile == null) return;
        if (mPrefProfile != null) {
            mPrefProfile.setEntries(mManager.getProfiles());
            mPrefProfile.setEntryValues(mManager.getProfiles());
            mPrefProfile.setValue(mProfile.getName());
            resetList(mPrefProfile);
        }
        if (mPrefPerApp != null) mPrefPerApp.setChecked(mProfile.isPerApp());
        if (mPrefAppBypass != null) mPrefAppBypass.setChecked(mProfile.isBypassApp());
        if (mPrefAuto != null) mPrefAuto.setChecked(mProfile.autoConnect());
        if (mPrefAppList != null) mPrefAppList.setSummary(selectedAppsSummary());
        if (mPrefTlsPositions != null) mPrefTlsPositions.setText(mProfile.getTlsRecordPositions());
        int recordCount = net.typeblog.socks.util.ByeDpiSettings.recordCount(mProfile.getTlsRecordPositions());
        if (mPrefTlsCount != null) {
            mPrefTlsCount.setValue(Integer.toString(Math.min(16, Math.max(1, recordCount))));
            resetList(mPrefTlsCount);
        }
        if (mPrefDesyncMode != null) {
            mPrefDesyncMode.setSelectable(false);
        }
        if (mPrefFakeTtl != null) {
            mPrefFakeTtl.setEnabled(false);
            int fakeTtl = mProfile.getFakeTtl();
            mPrefFakeTtl.setValue(Integer.toString(fakeTtl));
            mPrefFakeTtl.setSummary("TTL = " + fakeTtl);
        }
        updateTlsSummary();
        updateDesyncSummary();
        boolean whiteDnsOn = mProfile.isWhiteDnsEnabled();
        if (mPrefWhiteDnsEnabled != null) mPrefWhiteDnsEnabled.setChecked(whiteDnsOn);
        if (mPrefWhiteDnsServers != null) {
            mPrefWhiteDnsServers.setEnabled(whiteDnsOn);
            String wServers = mProfile.getWhiteDnsServers();
            mPrefWhiteDnsServers.setText(wServers);
            mPrefWhiteDnsServers.setSummary(wServers);
        }
        updateDnsHostsSummary();
        updateProtocolVisibility();
    }

    private void updateProtocolVisibility() {
        if (mProfile == null) return;
        if (mScreen != null && mTlsCategory != null && mTlsCategory.getParent() == null) mScreen.addPreference(mTlsCategory);
        if (mScreen != null && mDnsCategory != null && mDnsCategory.getParent() == null) mScreen.addPreference(mDnsCategory);
        if (mTlsCategory != null) mTlsCategory.setOrder(1);
        if (mDnsCategory != null) mDnsCategory.setOrder(2);
        if (mAdvancedCategory != null) mAdvancedCategory.setOrder(3);
    }



    private void updateDesyncSummary() {
        if (mProfile == null || mPrefDesyncMode == null) return;
        int records = net.typeblog.socks.util.ByeDpiSettings.recordCount(mProfile.getTlsRecordPositions());
        mPrefDesyncMode.setSummary("OOB + Split + Disorder Pro (Strong) · TLS Split: " + records);
    }

    private void updateTlsSummary() {
        if (mProfile == null || mPrefTlsCount == null || mPrefTlsPositions == null) return;
        String positions = mProfile.getTlsRecordPositions();
        int records = net.typeblog.socks.util.ByeDpiSettings.recordCount(positions);
        mPrefTlsCount.setSummary(records <= 1
                ? "TLS record fragmentation is disabled"
                : records + " TLS records will be used");
        mPrefTlsPositions.setSummary(net.typeblog.socks.util.ByeDpiSettings.positionsSummary(positions));
    }

    private void updateDnsHostsSummary() {
        if (mProfile == null || mPrefDnsHosts == null) return;
        String rules = mProfile.getDnsHostOverrides();
        int count = 0;
        for (String line : rules.split("\n")) {
            if (!line.trim().isEmpty() && !line.trim().startsWith("#")) count++;
        }
        mPrefDnsHosts.setSummary(count == 0 ? getString(R.string.dns_host_empty)
                : count + " service mapping(s) · Tap to manage");
    }

    /** Form-based DNS override editor: a service/domain plus up to two IPv4 addresses. */
    private void showDnsHostEditor() {
        if (getActivity() == null || mProfile == null) return;
        final Activity activity = getActivity();
        final int pad = (int) (16 * activity.getResources().getDisplayMetrics().density + 0.5f);
        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad / 2, pad, 0);

        TextView help = new TextView(activity);
        help.setText(R.string.dns_host_editor_help);
        root.addView(help, new LinearLayout.LayoutParams(-1, -2));

        TextView domainLabel = new TextView(activity);
        domainLabel.setText(R.string.dns_host_domain_label);
        domainLabel.setPadding(0, pad, 0, pad / 3);
        root.addView(domainLabel);
        final EditText domain = new EditText(activity);
        domain.setSingleLine(true);
        domain.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        domain.setHint(R.string.dns_host_domain_hint);
        root.addView(domain, new LinearLayout.LayoutParams(-1, -2));

        TextView ip1Label = new TextView(activity);
        ip1Label.setText(R.string.dns_host_ip1_label);
        ip1Label.setPadding(0, pad / 2, 0, pad / 3);
        root.addView(ip1Label);
        final EditText ip1 = new EditText(activity);
        ip1.setSingleLine(true);
        ip1.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        ip1.setHint("104.244.42.1,151.101.1.195");
        root.addView(ip1, new LinearLayout.LayoutParams(-1, -2));

        TextView ip2Label = new TextView(activity);
        ip2Label.setText(R.string.dns_host_ip2_label);
        ip2Label.setPadding(0, pad / 2, 0, pad / 3);
        root.addView(ip2Label);
        final EditText ip2 = new EditText(activity);
        ip2.setSingleLine(true);
        ip2.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        ip2.setHint("104.244.42.65,151.101.65.195");
        root.addView(ip2, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout presetRow = new LinearLayout(activity);
        presetRow.setOrientation(LinearLayout.HORIZONTAL);
        Button presetX = new Button(activity);
        presetX.setText("X / Twitter");
        presetX.setAllCaps(false);
        presetX.setOnClickListener(v -> {
            domain.setText("regexp:(x\\.com|twitter\\.com|twimg\\.com|t\\.co)");
            ip1.setText("104.244.42.1,104.244.42.65");
            ip2.setText("151.101.1.195,151.101.65.195");
        });
        Button presetCf = new Button(activity);
        presetCf.setText("Cloudflare Site");
        presetCf.setAllCaps(false);
        presetCf.setOnClickListener(v -> {
            domain.setText("regexp:(example\\.com)");
            ip1.setText("104.19.229.21");
            ip2.setText("172.67.180.10");
        });
        Button presetTg = new Button(activity);
        presetTg.setText("Telegram");
        presetTg.setAllCaps(false);
        presetTg.setOnClickListener(v -> {
            domain.setText("regexp:(telegram\\.org|t\\.me|telegram\\.me|telegra\\.ph)");
            ip1.setText("149.154.167.99");
            ip2.setText("149.154.167.50");
        });
        presetRow.addView(presetX, new LinearLayout.LayoutParams(0, -2, 1f));
        presetRow.addView(presetCf, new LinearLayout.LayoutParams(0, -2, 1f));
        presetRow.addView(presetTg, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(presetRow, new LinearLayout.LayoutParams(-1, -2));

        Button addUpdate = new Button(activity);
        addUpdate.setText(R.string.dns_host_add_update);
        root.addView(addUpdate, new LinearLayout.LayoutParams(-1, -2));

        TextView savedLabel = new TextView(activity);
        savedLabel.setText(R.string.dns_host_existing);
        savedLabel.setPadding(0, pad, 0, pad / 3);
        root.addView(savedLabel);

        ScrollView listScroll = new ScrollView(activity);
        LinearLayout rulesContainer = new LinearLayout(activity);
        rulesContainer.setOrientation(LinearLayout.VERTICAL);
        listScroll.addView(rulesContainer, new ScrollView.LayoutParams(-1, -2));
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, (int) (160 * activity.getResources().getDisplayMetrics().density));
        root.addView(listScroll, scrollParams);

        final AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(R.string.dns_host_editor_title)
                .setView(root)
                .setPositiveButton(android.R.string.ok, null)
                .create();

        final Runnable[] refreshRules = new Runnable[1];
        refreshRules[0] = new Runnable() {
            @Override public void run() {
                rulesContainer.removeAllViews();
                String raw = mProfile.getDnsHostOverrides();
                String[] lines = raw.split("\n");
                boolean hasRules = false;
                for (final String line : lines) {
                    final String value = line.trim();
                    if (value.isEmpty() || value.startsWith("#")) continue;
                    int eq = value.indexOf('=');
                    if (eq <= 0) continue;
                    hasRules = true;
                    final String host = value.substring(0, eq).trim();
                    final String[] ips = value.substring(eq + 1).split(",");
                    LinearLayout row = new LinearLayout(activity);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    Button select = new Button(activity);
                    select.setText(host + "  →  " + value.substring(eq + 1).trim());
                    select.setAllCaps(false);
                    select.setOnClickListener(v -> {
                        domain.setText(host);
                        if (ips.length <= 2) {
                            ip1.setText(ips.length > 0 ? ips[0].trim() : "");
                            ip2.setText(ips.length > 1 ? ips[1].trim() : "");
                        } else {
                            int mid = (ips.length + 1) / 2;
                            StringBuilder p1 = new StringBuilder();
                            StringBuilder p2 = new StringBuilder();
                            for (int idx = 0; idx < ips.length; idx++) {
                                String cleanIp = ips[idx].trim();
                                if (idx < mid) {
                                    if (p1.length() > 0) p1.append(',');
                                    p1.append(cleanIp);
                                } else {
                                    if (p2.length() > 0) p2.append(',');
                                    p2.append(cleanIp);
                                }
                            }
                            ip1.setText(p1.toString());
                            ip2.setText(p2.toString());
                        }
                    });
                    row.addView(select, new LinearLayout.LayoutParams(0, -2, 1f));
                    Button remove = new Button(activity);
                    remove.setText(R.string.dns_host_remove);
                    remove.setAllCaps(false);
                    remove.setOnClickListener(v -> {
                        StringBuilder updated = new StringBuilder();
                        for (String candidate : mProfile.getDnsHostOverrides().split("\n")) {
                            if (candidate.trim().isEmpty()) continue;
                            int split = candidate.indexOf('=');
                            String candidateHost = split > 0 ? candidate.substring(0, split).trim() : "";
                            if (!candidateHost.equalsIgnoreCase(host)) {
                                if (updated.length() > 0) updated.append('\n');
                                updated.append(candidate.trim());
                            }
                        }
                        try {
                            mProfile.setDnsHostOverrides(net.typeblog.socks.util.DnsHostOverrides.normalizeEditorText(updated.toString()));
                            updateDnsHostsSummary();
                            refreshRules[0].run();
                        } catch (IllegalArgumentException error) {
                            Toast.makeText(activity, error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                    row.addView(remove, new LinearLayout.LayoutParams(-2, -2));
                    rulesContainer.addView(row, new LinearLayout.LayoutParams(-1, -2));
                }
                if (!hasRules) {
                    TextView empty = new TextView(activity);
                    empty.setText(R.string.dns_host_empty);
                    rulesContainer.addView(empty);
                }
            }
        };

        addUpdate.setOnClickListener(v -> {
            String host = domain.getText().toString().trim();
            String first = ip1.getText().toString().trim();
            String second = ip2.getText().toString().trim();
            if (host.isEmpty() || first.isEmpty()) {
                Toast.makeText(activity, R.string.dns_host_invalid, Toast.LENGTH_LONG).show();
                return;
            }
            String mapping = host + "=" + first + (second.isEmpty() ? "" : "," + second);
            StringBuilder updated = new StringBuilder();
            boolean replaced = false;
            for (String candidate : mProfile.getDnsHostOverrides().split("\n")) {
                String value = candidate.trim();
                if (value.isEmpty()) continue;
                int eq = value.indexOf('=');
                String candidateHost = eq > 0 ? value.substring(0, eq).trim() : "";
                if (candidateHost.equalsIgnoreCase(host)) {
                    if (!replaced) {
                        if (updated.length() > 0) updated.append('\n');
                        updated.append(mapping);
                        replaced = true;
                    }
                } else {
                    if (updated.length() > 0) updated.append('\n');
                    updated.append(value);
                }
            }
            if (!replaced) {
                if (updated.length() > 0) updated.append('\n');
                updated.append(mapping);
            }
            try {
                String normalized = net.typeblog.socks.util.DnsHostOverrides.normalizeEditorText(updated.toString());
                mProfile.setDnsHostOverrides(normalized);
                updateDnsHostsSummary();
                domain.setText("");
                ip1.setText("");
                ip2.setText("");
                refreshRules[0].run();
                Toast.makeText(activity, R.string.dns_host_saved, Toast.LENGTH_SHORT).show();
            } catch (IllegalArgumentException error) {
                Toast.makeText(activity, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        dialog.setOnShowListener(ignored -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> dialog.dismiss());
            refreshRules[0].run();
        });
        dialog.show();
    }


    private String selectedAppsSummary() {
        String raw = mProfile == null ? "" : mProfile.getAppList();
        if (raw.trim().isEmpty()) return getString(R.string.adv_app_list_sum);
        String[] packages = raw.split("\\n");
        PackageManager pm = getActivity().getPackageManager();
        java.util.ArrayList<String> names = new java.util.ArrayList<>();
        for (String pkg : packages) try { names.add(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()); } catch (Exception ignored) { }
        return names.isEmpty() ? getString(R.string.adv_app_list_sum) : android.text.TextUtils.join(", ", names);
    }

    private void showAppPicker() {
        final PackageManager pm = getActivity().getPackageManager();
        final java.util.LinkedHashMap<String, ApplicationInfo> userApps = new java.util.LinkedHashMap<>();
        Intent launchIntent = new Intent(Intent.ACTION_MAIN);
        launchIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        java.util.List<ResolveInfo> launchables = pm.queryIntentActivities(launchIntent, 0);
        for (ResolveInfo resolve : launchables) {
            ActivityInfo activity = resolve.activityInfo;
            if (activity == null || activity.applicationInfo == null) continue;
            ApplicationInfo app = activity.applicationInfo;
            if (app.packageName.equals(getActivity().getPackageName())) continue;
            userApps.put(app.packageName, app);
        }

        final java.util.ArrayList<ApplicationInfo> apps = new java.util.ArrayList<>(userApps.values());
        java.util.Collections.sort(apps, (a,b) -> pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString()));
        final java.util.ArrayList<String> labels = new java.util.ArrayList<>();
        final java.util.ArrayList<String> packages = new java.util.ArrayList<>();
        for (ApplicationInfo app : apps) {
            labels.add(pm.getApplicationLabel(app).toString());
            packages.add(app.packageName);
        }
        if (packages.isEmpty()) {
            Toast.makeText(getActivity(), "No launcher apps found", Toast.LENGTH_SHORT).show();
            return;
        }
        final java.util.Set<String> selected = new java.util.HashSet<>();
        String current = mProfile.getAppList();
        if (!current.trim().isEmpty()) selected.addAll(java.util.Arrays.asList(current.split("\\n")));
        final boolean[] checked = new boolean[packages.size()];
        for (int i=0;i<packages.size();i++) checked[i] = selected.contains(packages.get(i));
        new AlertDialog.Builder(getActivity()).setTitle(R.string.adv_app_list)
                .setMultiChoiceItems(labels.toArray(new String[0]), checked, (dialog, which, isChecked) -> {
                    if (isChecked) selected.add(packages.get(which)); else selected.remove(packages.get(which));
                })
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    java.util.ArrayList<String> result = new java.util.ArrayList<>();
                    for (String pkg : packages) if (selected.contains(pkg)) result.add(pkg);
                    mProfile.setAppList(android.text.TextUtils.join("\n", result));
                    mPrefAppList.setSummary(selectedAppsSummary());
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void resetList(ListPreference... pref) {
        for (ListPreference p : pref)
            p.setSummary(p.getEntry());
    }

    private void resetListN(ListPreference pref, Object newValue) {
        pref.setSummary(newValue.toString());
    }

    private void resetText(EditTextPreference... pref) {
        for (EditTextPreference p : pref) {
            if ((p.getEditText().getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) != InputType.TYPE_TEXT_VARIATION_PASSWORD) {
                p.setSummary(p.getText());
            } else {
                if (p.getText().length() > 0)
                    p.setSummary(String.format(Locale.US,
                            String.format(Locale.US, "%%0%dd", p.getText().length()), 0)
                            .replace("0", "*"));
                else
                    p.setSummary("");
            }
        }
    }

    private void resetTextN(EditTextPreference pref, Object newValue) {
        if ((pref.getEditText().getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) != InputType.TYPE_TEXT_VARIATION_PASSWORD) {
            pref.setSummary(newValue.toString());
        } else {
            String text = newValue.toString();
            if (text.length() > 0)
                pref.setSummary(String.format(Locale.US,
                        String.format(Locale.US, "%%0%dd", text.length()), 0)
                        .replace("0", "*"));
            else
                pref.setSummary("");
        }
    }

    private void addProfile() {
        final EditText e = new EditText(getActivity());
        e.setSingleLine(true);

        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.prof_add)
                .setView(e)
                .setPositiveButton(android.R.string.ok, (d, which) -> {
                    String name = e.getText().toString().trim();

                    if (!TextUtils.isEmpty(name)) {
                        Profile p = mManager.addProfile(name);

                        if (p != null) {
                            mProfile = p;
                            reload();
                            return;
                        }
                    }

                    Toast.makeText(getActivity(),
                            String.format(getString(R.string.err_add_prof), name),
                            Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.cancel, (d, which) -> {

                })
                .create().show();
    }

    private void renameProfile() {
        final EditText input = new EditText(getActivity());
        input.setSingleLine(true);
        input.setText(mProfile.getName());
        new AlertDialog.Builder(getActivity()).setTitle(R.string.prof_rename).setView(input)
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    String newName = input.getText().toString().trim();
                    if (mManager.renameProfile(mProfile.getName(), newName)) {
                        mProfile = mManager.getProfile(newName);
                        reload();
                        Toast.makeText(getActivity(), "Profile renamed", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getActivity(), "Invalid or duplicate profile name", Toast.LENGTH_LONG).show();
                    }
                }).setNegativeButton(android.R.string.cancel, null).show();
    }

    private void removeProfile() {
        new AlertDialog.Builder(getActivity())
                .setTitle(R.string.prof_del)
                .setMessage(String.format(getString(R.string.prof_del_confirm), mProfile.getName()))
                .setPositiveButton(android.R.string.ok, (d, which) -> {
                    if (!mManager.removeProfile(mProfile.getName())) {
                        Toast.makeText(getActivity(),
                                getString(R.string.err_del_prof, mProfile.getName()),
                                Toast.LENGTH_SHORT).show();
                    } else {
                        mProfile = mManager.getDefault();
                        reload();
                    }
                })
                .setNegativeButton(android.R.string.cancel, (d, which) -> {

                })
                .create().show();
    }

    private boolean mBound = false;
    private boolean mReceiverRegistered = false;
    private final BroadcastReceiver mStateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            mStopHandler.removeCallbacks(mStopTimeout);
            mRunning = intent.getBooleanExtra("running", false);
            mStarting = false;
            String error = intent.getStringExtra("error");
            updateState();
            if (!TextUtils.isEmpty(error) && getActivity() != null) {
                Toast.makeText(getActivity(), error, Toast.LENGTH_LONG).show();
            }
        }
    };
    private void checkState() {
        if (mSwitch == null || getActivity() == null) return;

        // Never disable the main switch while querying service state.
        // BIND_AUTO_CREATE is required: bindService(..., 0) returns false when
        // the VPN service has not been started yet, which previously left the
        // switch disabled forever on a fresh launch.
        mSwitch.setEnabled(true);
        mSwitch.setOnCheckedChangeListener(this);

        if (mBound && mBinder != null) {
            try {
                mRunning = mBinder.isRunning();
            } catch (Exception ignored) {
                mRunning = false;
            }
            if (mStarting && !mRunning) {
                keepSwitchOnWhileStarting();
            } else {
                updateState();
            }
            return;
        }

        if (!mBound) {
            try {
                mBound = getActivity().bindService(
                        new Intent(getActivity(), SocksVpnService.class),
                        mConnection,
                        Context.BIND_AUTO_CREATE
                );
            } catch (Exception ignored) {
                mBound = false;
            }
        }
    }

    private void keepSwitchOnWhileStarting() {
        if (mSwitch == null) return;
        mSwitch.setOnCheckedChangeListener(null);
        mSwitch.setChecked(true);
        mSwitch.setEnabled(true);
        mSwitch.setOnCheckedChangeListener(ProfileFragment.this);
    }

    private void updateState() {
        if (mSwitch == null) return;
        mStopHandler.removeCallbacks(mStopTimeout);
        mSwitch.setOnCheckedChangeListener(null);
        mSwitch.setChecked(mRunning);
        mSwitch.setEnabled(true);
        mStarting = false;
        mStopping = false;
        mSwitch.setOnCheckedChangeListener(ProfileFragment.this);
    }

    private void startVpn() {
        try {
            net.typeblog.socks.util.ByeDpiSettings.fromSettings(
                    mProfile.getTlsRecordPositions(), mProfile.getDesyncMode(), mProfile.isFakeSniEnabled(), mProfile.getFakeSni(), mProfile.getFakeTtl(), net.typeblog.socks.util.ByeDpiSettings.DEFAULT_SPOOF_CONNECT_IP, net.typeblog.socks.util.ByeDpiSettings.DEFAULT_HANDSHAKE_TIMEOUT_MS, false, "", true, mProfile.getDnsHostOverrides());
        } catch (IllegalArgumentException e) {
            Toast.makeText(getActivity(), R.string.fragment_config_invalid, Toast.LENGTH_LONG).show();
            resetMainSwitch();
            return;
        }
        mStarting = true;
        Intent i = VpnService.prepare(getActivity());
        if (i != null) startActivityForResult(i, 0);
        else onActivityResult(0, Activity.RESULT_OK, null);
    }

    private void resetMainSwitch() {
        mStarting = false;
        if (mSwitch != null) {
            mSwitch.setOnCheckedChangeListener(null);
            mSwitch.setChecked(false);
            mSwitch.setEnabled(true);
            mSwitch.setOnCheckedChangeListener(this);
        }
    }

    private void stopVpn() {
        mStopping = true;
        mStopHandler.removeCallbacks(mStopTimeout);
        if (getActivity() != null) {
            // Do not rely on stopService()/onDestroy() for VpnService shutdown.
            // The explicit command reaches onStartCommand and closes the VPN TUN fd.
            try {
                Intent stop = new Intent(getActivity(), SocksVpnService.class)
                        .setAction(SocksVpnService.ACTION_STOP);
                getActivity().startService(stop);
            } catch (Exception ignored) {
                // Keep a lifecycle fallback if Android rejects the explicit command.
                try { getActivity().stopService(new Intent(getActivity(), SocksVpnService.class)); }
                catch (Exception ignoredAgain) { }
            }
        }

        mBinder = null;
        mRunning = false;
        if (mSwitch != null) {
            mSwitch.setOnCheckedChangeListener(null);
            mSwitch.setChecked(false);
            mSwitch.setEnabled(true);
            mSwitch.setOnCheckedChangeListener(this);
        }
        if (mBound && getActivity() != null) {
            try { getActivity().unbindService(mConnection); } catch (Exception ignored) { }
            mBound = false;
        }
        mStopHandler.postDelayed(mStopTimeout, 2500L);
    }
}
