package net.typeblog.socks;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;

import net.typeblog.socks.util.Profile;
import net.typeblog.socks.util.ProfileManager;
import net.typeblog.socks.util.Utility;

public class BootReceiver extends BroadcastReceiver {
    private static volatile boolean startedThisBoot = false;

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        boolean isUpdate = Intent.ACTION_MY_PACKAGE_REPLACED.equals(action);
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_USER_UNLOCKED.equals(action)
                && !isUpdate) return;
        synchronized (BootReceiver.class) {
            if (!isUpdate && startedThisBoot) return;
            Profile profile;
            try { profile = new ProfileManager(context.getApplicationContext()).getDefault(); }
            catch (Exception ignored) { return; }
            if (!profile.autoConnect() || VpnService.prepare(context) != null) return;
            startedThisBoot = true;
            try { Utility.startVpn(context.getApplicationContext(), profile); }
            catch (Exception ignored) { startedThisBoot = false; }
        }
    }
}
