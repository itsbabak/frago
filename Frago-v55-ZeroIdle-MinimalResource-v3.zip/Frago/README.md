# Frago 1.1.9

Frago is a lightweight Android VPN app powered by the ByeDPI native engine. Configuration is performed in the app's settings; users do not need to paste or maintain JSON.

## In-app settings

- **TLS record count:** choose 2 to 9 records, or disable TLS-record splitting. Frago generates starting split positions automatically.
- **Custom TLS split positions:** optional advanced field, one ByeDPI `--tlsrec` position per line. Each position is passed as a separate `--tlsrec` argument.
- **Secure DNS (DoH) switch:** OFF by default. OFF forwards DNS to the active network DNS over UDP; ON uses `https://kid.openbld.net/dns-query` (or a configured HTTPS resolver). The switch is stored per profile and takes effect after reconnecting. It does not change Android system Private DNS.
- **Service IP overrides:** add a domain/service matcher and one or two IPv4 addresses using a simple form. Multiple rules can be stored, independent of the DoH switch. Exact domains, `*.example.com` wildcards, and `regexp:...` patterns are supported.
- **Per-app VPN:** choose installed launcher apps by their visible names; package IDs are not required.
- **Boot auto-connect:** retained. Smart Connect and its Usage Access permission have been removed.

The default Google mapping is retained: `regexp:(google)` → `65.109.184.128`, `91.107.241.144`.

## Compatibility and operation

When an older installation contains an imported JSON profile, Frago silently extracts its DoH URL and `dns.hosts` mappings into the new settings once, then removes the old JSON preference. No JSON import or editor is exposed in the app.

TLS-record splitting modifies the TLS ClientHello into separate TLS records. It is not the same as Xray's TCP `fragment` outbound; Xray-specific `length` and `interval` values are not used by ByeDPI. The application uses the pinned ByeDPI v0.17.3 engine and retains the direct VPN stop path from the previous stop-fix build.

## Build

```bash
./gradlew :app:assembleDebug
```

The build requires Android SDK Platform 36 and Android NDK 28.2.13676358. The native build script downloads the pinned ByeDPI v0.17.3 source if it is not already present.

### Battery optimization
The DNS relay uses a bounded positive-response cache (128 entries) and honors
answer-record TTLs, capped at 60 seconds. Cached replies have the requesting
client's DNS transaction ID restored. The cache is cleared on relay shutdown
and whenever upstream network DNS servers are refreshed. DNS worker threads
run at minimum Java thread priority. These changes reduce repeated upstream
lookups while preserving the existing VPN and ByeDPI configuration paths.
