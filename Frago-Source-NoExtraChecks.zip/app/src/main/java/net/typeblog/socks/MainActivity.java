package net.typeblog.socks;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

/** Single-screen Frago UI with a compact VPN switch and dark native preferences. */
public class MainActivity extends Activity {
    private Switch mVpnSwitch;
    private TextView mVpnStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(15, 19, 29));
        getWindow().setNavigationBarColor(Color.rgb(10, 13, 20));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(17, 22, 33));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(20), 0, dp(16), 0);
        toolbar.setBackgroundColor(Color.rgb(25, 32, 47));
        toolbar.setElevation(dp(2));

        TextView title = new TextView(this);
        title.setText("FRAGO");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setLetterSpacing(0.08f);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        toolbar.addView(title, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        root.addView(toolbar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58)));

        FrameLayout content = new FrameLayout(this);
        content.setId(R.id.main_fragment_container);
        root.addView(content, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout connectionBar = new LinearLayout(this);
        connectionBar.setOrientation(LinearLayout.HORIZONTAL);
        connectionBar.setGravity(Gravity.CENTER_VERTICAL);
        connectionBar.setPadding(dp(18), dp(8), dp(18), dp(8));
        connectionBar.setBackgroundColor(Color.rgb(25, 32, 47));
        connectionBar.setElevation(dp(5));

        LinearLayout statusColumn = new LinearLayout(this);
        statusColumn.setOrientation(LinearLayout.VERTICAL);
        statusColumn.setGravity(Gravity.CENTER_VERTICAL);
        TextView statusTitle = new TextView(this);
        statusTitle.setText("VPN CONNECTION");
        statusTitle.setTextColor(Color.LTGRAY);
        statusTitle.setTextSize(11);
        statusTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        mVpnStatus = new TextView(this);
        mVpnStatus.setText("DISCONNECTED");
        mVpnStatus.setTextColor(Color.WHITE);
        mVpnStatus.setTextSize(14);
        mVpnStatus.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        statusColumn.addView(statusTitle);
        statusColumn.addView(mVpnStatus);
        connectionBar.addView(statusColumn, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        mVpnSwitch = new Switch(this);
        mVpnSwitch.setText("VPN");
        mVpnSwitch.setTextOn("ON");
        mVpnSwitch.setTextOff("OFF");
        mVpnSwitch.setTextColor(Color.WHITE);
        mVpnSwitch.setShowText(true);
        connectionBar.addView(mVpnSwitch, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(connectionBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(72)));

        setContentView(root);

        if (savedInstanceState == null) {
            getFragmentManager().beginTransaction()
                    .replace(R.id.main_fragment_container, new ProfileFragment())
                    .commit();
        }
    }

    public Switch getVpnSwitch() {
        return mVpnSwitch;
    }

    public void setVpnUiState(boolean running, boolean starting, boolean stopping) {
        if (mVpnStatus == null) return;
        if (starting) mVpnStatus.setText("CONNECTING…");
        else if (stopping) mVpnStatus.setText("DISCONNECTING…");
        else mVpnStatus.setText(running ? "CONNECTED" : "DISCONNECTED");
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
