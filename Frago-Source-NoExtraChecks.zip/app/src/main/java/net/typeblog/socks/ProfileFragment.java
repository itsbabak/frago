package net.typeblog.socks;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.VpnService;
import android.os.Bundle;
import android.os.IBinder;
import android.os.SystemClock;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;


import net.typeblog.socks.util.Profile;
import net.typeblog.socks.util.ProfileManager;
import net.typeblog.socks.util.Utility;
import net.typeblog.socks.util.XrayConfig;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static net.typeblog.socks.util.Constants.*;

/** One-page Frago settings: Fragment JSON, local SOCKS5 input, Private DNS and app selection. */
public class ProfileFragment extends PreferenceFragment implements
        Preference.OnPreferenceClickListener,
        Preference.OnPreferenceChangeListener,
        CompoundButton.OnCheckedChangeListener {

    private static final int REQUEST_VPN_PERMISSION = 0;
    private static final long STATE_POLL_MS = 450L;
    private static final long START_TIMEOUT_MS = 50000L;

    private ProfileManager mManager;
    private Profile mProfile;
    private Switch mSwitch;
    private boolean mRunning;
    private boolean mStarting;
    private boolean mStopping;
    private boolean mBound;
    private boolean mUiResumed;
    private long mTransitionStartedAt;
    private String mPendingXrayConfig;
    private boolean mServiceStartDispatched;
    private IVpnService mBinder;

    private CheckBoxPreference mPrefPerApp;
    private CheckBoxPreference mPrefAppBypass;
    private CheckBoxPreference mPrefPrivateDnsEnabled;
    private Preference mPrefPrivateDnsAddress;
    private Preference mPrefSocksInput;
    private Preference mPrefOutputConfig;
    private Preference mPrefOutputStatus;
    private Preference mPrefAppPicker;
    private Preference mPrefPing;

    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            mBinder = IVpnService.Stub.asInterface(binder);
            updateState();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mBinder = null;
            updateState();
        }
    };

    private final Runnable mStateRunnable = new Runnable() {
        @Override
        public void run() {
            if (mSwitch == null || !mUiResumed) return;
            updateState();
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings_single);
        mManager = new ProfileManager(getActivity().getApplicationContext());
        initPreferences();
        reload();
    }

    private void initPreferences() {
        mPrefPerApp = (CheckBoxPreference) findPreference(PREF_ADV_PER_APP);
        mPrefAppBypass = (CheckBoxPreference) findPreference(PREF_ADV_APP_BYPASS);
        mPrefPrivateDnsEnabled = (CheckBoxPreference) findPreference("private_dns_enabled");
        mPrefPrivateDnsAddress = findPreference("private_dns_address");
        mPrefSocksInput = findPreference("socks_input");
        mPrefOutputConfig = findPreference("output_config");
        mPrefOutputStatus = findPreference("output_status");
        mPrefAppPicker = findPreference("adv_app_picker");
        mPrefPing = findPreference("ping_test");

        setChangeListener(mPrefPerApp);
        setChangeListener(mPrefAppBypass);
        setChangeListener(mPrefPrivateDnsEnabled);

        setClickListener(mPrefOutputConfig);
        setClickListener(mPrefPrivateDnsAddress);
        setClickListener(mPrefAppPicker);
        setClickListener(mPrefPing);
    }

    private void setChangeListener(Preference preference) {
        if (preference != null) preference.setOnPreferenceChangeListener(this);
    }

    private void setClickListener(Preference preference) {
        if (preference != null) preference.setOnPreferenceClickListener(this);
    }

    @Override
    public boolean onPreferenceClick(Preference preference) {
        if (preference == mPrefOutputConfig) {
            editJsonManually();
            return true;
        }
        if (preference == mPrefPrivateDnsAddress) {
            editPrivateDnsAddress();
            return true;
        }
        if (preference == mPrefAppPicker) {
            showAppPicker();
            return true;
        }
        if (preference == mPrefPing) {
            runPingTest();
            return true;
        }
        return false;
    }

    @Override
    public boolean onPreferenceChange(Preference preference, Object newValue) {
        if (preference == mPrefPerApp) {
            boolean enabled = Boolean.parseBoolean(String.valueOf(newValue));
            mProfile.setIsPerApp(enabled);
            return true;
        }
        if (preference == mPrefAppBypass) {
            mProfile.setIsBypassApp(Boolean.parseBoolean(String.valueOf(newValue)));
            return true;
        }
        if (preference == mPrefPrivateDnsEnabled) {
            boolean enabled = Boolean.parseBoolean(String.valueOf(newValue));
            if (enabled && TextUtils.isEmpty(mProfile.getPrivateDnsAddress())) {
                Toast.makeText(getActivity(),
                        "Enter and save a DNS-over-HTTPS address first.",
                        Toast.LENGTH_LONG).show();
                return false;
            }
            mProfile.setPrivateDnsEnabled(enabled);
            updatePrivateDnsSummary();
            return true;
        }
        return false;
    }

    @Override
    public void onResume() {
        super.onResume();
        mUiResumed = true;
        if (getActivity() instanceof MainActivity) {
            mSwitch = ((MainActivity) getActivity()).getVpnSwitch();
            if (mSwitch != null) {
                mSwitch.removeCallbacks(mStateRunnable);
                mSwitch.setOnCheckedChangeListener(this);
            }
        }
        checkState();
    }

    @Override
    public void onPause() {
        mUiResumed = false;
        if (mSwitch != null) {
            mSwitch.removeCallbacks(mStateRunnable);
            mSwitch.setOnCheckedChangeListener(null);
        }
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        if (mSwitch != null) {
            mSwitch.removeCallbacks(mStateRunnable);
            mSwitch.setOnCheckedChangeListener(null);
            mSwitch = null;
        }
        if (mBound) {
            try { getActivity().unbindService(mConnection); }
            catch (Exception ignored) { }
            mBound = false;
            mBinder = null;
        }
        super.onDestroyView();
    }

    @Override
    public void onCheckedChanged(CompoundButton button, boolean checked) {
        if (checked) startVpn();
        else stopVpn();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_VPN_PERMISSION) return;
        if (resultCode == Activity.RESULT_OK && mProfile != null
                && !TextUtils.isEmpty(mPendingXrayConfig)) {
            mServiceStartDispatched = true;
            Utility.startVpn(getActivity(), mProfile, mPendingXrayConfig);
            mPendingXrayConfig = null;
            checkState();
            scheduleStatePoll();
        } else {
            mPendingXrayConfig = null;
            mServiceStartDispatched = false;
            mStarting = false;
            updateState();
        }
    }

    private void editJsonManually() {
        String current = mProfile.getXrayConfig();
        if (current == null) current = "";
        final EditText editor = createEditor(current,
                "Paste or type the complete Fragment Xray JSON here");
        editor.setMinLines(16);
        editor.setMaxLines(28);
        new AlertDialog.Builder(getActivity())
                .setTitle("Fragment · JSON configuration")
                .setView(editor)
                .setPositiveButton("Save", (dialog, which) -> saveJson(editor.getText().toString()))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void editPrivateDnsAddress() {
        final EditText editor = createEditor(mProfile.getPrivateDnsAddress(),
                "https://dns.google/dns-query or dns.example/dns-query");
        editor.setSingleLine(true);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        new AlertDialog.Builder(getActivity())
                .setTitle("Private DNS · DoH")
                .setMessage("Use an HTTPS DNS-over-HTTPS endpoint. When enabled, Frago applies it to the active Fragment JSON.")
                .setView(editor)
                .setPositiveButton("Save", (dialog, which) -> {
                    try {
                        String normalized = XrayConfig.normalizePrivateDnsAddress(
                                editor.getText().toString());
                        mProfile.setPrivateDnsAddress(normalized);
                        updatePrivateDnsSummary();
                        Toast.makeText(getActivity(), "Private DNS address saved.",
                                Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        showError(e.getMessage());
                    }
                })
                .setNeutralButton("Clear", (dialog, which) -> {
                    mProfile.setPrivateDnsAddress("");
                    mProfile.setPrivateDnsEnabled(false);
                    if (mPrefPrivateDnsEnabled != null) mPrefPrivateDnsEnabled.setChecked(false);
                    updatePrivateDnsSummary();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private EditText createEditor(String value, String hint) {
        EditText editor = new EditText(getActivity());
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editor.setTypeface(android.graphics.Typeface.MONOSPACE);
        editor.setText(value);
        editor.setHint(hint);
        editor.setSelection(editor.length());
        int padding = (int) (16 * getResources().getDisplayMetrics().density);
        editor.setPadding(padding, padding, padding, padding);
        return editor;
    }

    private void saveJson(String raw) {
        try {
            // Validate with a runtime copy; persist the user's exact JSON text unchanged.
            XrayConfig.prepare(raw);
            mProfile.setXrayConfig(raw);
            mProfile.setXrayMode(true);
            reload();
            Toast.makeText(getActivity(), "Fragment JSON saved without changing its formatting.",
                    Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            showError(e.getMessage());
        }
    }

    private void showError(String message) {
        Toast.makeText(getActivity(), "Invalid configuration: "
                + (TextUtils.isEmpty(message) ? "unknown error" : message), Toast.LENGTH_LONG).show();
    }

    private void showAppPicker() {
        final PackageManager packageManager = getActivity().getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN, null);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> resolved = packageManager.queryIntentActivities(launcher, 0);
        Collections.sort(resolved, new ResolveInfo.DisplayNameComparator(packageManager));

        final List<String> packages = new ArrayList<>();
        final List<CharSequence> labels = new ArrayList<>();
        Set<String> selected = new HashSet<>();
        String saved = mProfile.getAppList();
        if (!TextUtils.isEmpty(saved)) {
            for (String item : saved.split("\\n")) {
                if (!TextUtils.isEmpty(item.trim())) selected.add(item.trim());
            }
        }

        for (ResolveInfo info : resolved) {
            if (info.activityInfo == null) continue;
            String packageName = info.activityInfo.packageName;
            if (packageName.equals(getActivity().getPackageName()) || packages.contains(packageName)) continue;
            packages.add(packageName);
            labels.add(info.loadLabel(packageManager));
        }
        if (packages.isEmpty()) {
            Toast.makeText(getActivity(), "No launchable apps were found.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean[] checked = new boolean[packages.size()];
        for (int i = 0; i < packages.size(); i++) checked[i] = selected.contains(packages.get(i));
        new AlertDialog.Builder(getActivity())
                .setTitle("Choose apps")
                .setMultiChoiceItems(labels.toArray(new CharSequence[0]), checked,
                        (dialog, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton("Save", (dialog, which) -> {
                    StringBuilder list = new StringBuilder();
                    for (int i = 0; i < packages.size(); i++) {
                        if (checked[i]) {
                            if (list.length() > 0) list.append('\n');
                            list.append(packages.get(i));
                        }
                    }
                    mProfile.setAppList(list.toString());
                    mProfile.setIsPerApp(true);
                    if (mPrefPerApp != null) mPrefPerApp.setChecked(true);
                    updateAppPickerSummary();
                    Toast.makeText(getActivity(), "App selection saved.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void reload() {
        if (mProfile == null) mProfile = mManager.getDefault();
        if (mProfile == null) return;

        // This simplified build runs only the Fragment JSON engine.
        mProfile.setXrayMode(true);
        if (mPrefPerApp != null) mPrefPerApp.setChecked(mProfile.isPerApp());
        if (mPrefAppBypass != null) mPrefAppBypass.setChecked(mProfile.isBypassApp());
        if (mProfile.isPrivateDnsEnabled() && TextUtils.isEmpty(mProfile.getPrivateDnsAddress())) {
            mProfile.setPrivateDnsEnabled(false);
        }
        if (mPrefPrivateDnsEnabled != null) {
            mPrefPrivateDnsEnabled.setChecked(mProfile.isPrivateDnsEnabled());
        }
        updatePrivateDnsSummary();
        updateOutputSummary();
        updateAppPickerSummary();
        if (mPrefPing != null) mPrefPing.setSummary("Measure TCP latency through Fragment (VPN must be ON)");
    }

    private void updateOutputSummary() {
        String config = mProfile == null ? "" : mProfile.getXrayConfig();
        if (TextUtils.isEmpty(config)) {
            if (mPrefSocksInput != null) {
                mPrefSocksInput.setSummary("127.0.0.1:10808 · created by Frago when connected");
            }
            if (mPrefOutputStatus != null) mPrefOutputStatus.setSummary("Not configured");
            if (mPrefOutputConfig != null) {
                mPrefOutputConfig.setSummary("Tap to paste or type Fragment JSON manually · no import");
            }
            return;
        }
        try {
            XrayConfig.Prepared prepared = XrayConfig.prepare(config);
            if (mPrefSocksInput != null) {
                mPrefSocksInput.setSummary("127.0.0.1:" + prepared.socksPort
                        + " · local SOCKS5 input managed by Frago");
            }
            if (mPrefOutputStatus != null) {
                mPrefOutputStatus.setSummary("Fragment JSON saved · ready to connect");
            }
            if (mPrefOutputConfig != null) {
                mPrefOutputConfig.setSummary("JSON saved · tap to edit manually");
            }
        } catch (Exception e) {
            if (mPrefSocksInput != null) {
                mPrefSocksInput.setSummary("Local SOCKS5 input will be created after valid JSON is saved");
            }
            if (mPrefOutputStatus != null) mPrefOutputStatus.setSummary("Saved JSON is invalid");
            if (mPrefOutputConfig != null) {
                mPrefOutputConfig.setSummary("Tap to correct the Fragment JSON");
            }
        }
    }

    /** TCP reachability/latency test through Frago's local SOCKS5 inbound. */
    private void runPingTest() {
        if (mProfile == null || !mRunning) {
            Toast.makeText(getActivity(), "Connect Frago before running Ping.",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        if (mPrefPing != null) {
            mPrefPing.setEnabled(false);
            mPrefPing.setSummary("Testing 1.1.1.1:443 through Fragment…");
        }
        final Profile profile = mProfile;
        final Activity host = getActivity();
        new Thread(() -> {
            String result;
            try {
                XrayConfig.Prepared prepared = XrayConfig.prepare(profile.getXrayConfig(),
                        profile.isPrivateDnsEnabled(), profile.getPrivateDnsAddress());
                long elapsed = socksTcpPing("127.0.0.1", prepared.socksPort, 443);
                result = "Connected · " + elapsed + " ms (TCP) via Fragment";
            } catch (Exception e) {
                String message = e.getMessage();
                result = "Ping failed · " + (TextUtils.isEmpty(message) ? "connection error" : message);
            }
            final String finalResult = result;
            if (host != null) {
                host.runOnUiThread(() -> {
                    if (isAdded() && mPrefPing != null) {
                        mPrefPing.setEnabled(true);
                        mPrefPing.setSummary(finalResult);
                    }
                });
            }
        }, "Frago-Ping").start();
    }

    private long socksTcpPing(String proxyHost, int proxyPort, int targetPort) throws Exception {
        java.net.Socket socket = new java.net.Socket();
        try {
            socket.connect(new java.net.InetSocketAddress(proxyHost, proxyPort), 3500);
            socket.setSoTimeout(7000);
            java.io.DataInputStream input = new java.io.DataInputStream(socket.getInputStream());
            java.io.DataOutputStream output = new java.io.DataOutputStream(socket.getOutputStream());
            long started = SystemClock.elapsedRealtime();

            // SOCKS5 no-auth negotiation.
            output.write(new byte[] {0x05, 0x01, 0x00});
            output.flush();
            if (input.readUnsignedByte() != 0x05 || input.readUnsignedByte() != 0x00) {
                throw new java.io.IOException("SOCKS5 handshake was rejected");
            }

            // CONNECT to 1.1.1.1 using a literal IPv4 address (no local DNS lookup).
            output.write(new byte[] {0x05, 0x01, 0x00, 0x01,
                    1, 1, 1, 1,
                    (byte) ((targetPort >> 8) & 0xff), (byte) (targetPort & 0xff)});
            output.flush();

            int version = input.readUnsignedByte();
            int reply = input.readUnsignedByte();
            input.readUnsignedByte(); // reserved
            int addressType = input.readUnsignedByte();
            if (version != 0x05) throw new java.io.IOException("Invalid SOCKS5 response");
            if (reply != 0x00) throw new java.io.IOException(socksReplyMessage(reply));

            if (addressType == 0x01) {
                byte[] boundAddress = new byte[4];
                input.readFully(boundAddress);
            } else if (addressType == 0x04) {
                byte[] boundAddress = new byte[16];
                input.readFully(boundAddress);
            } else if (addressType == 0x03) {
                int length = input.readUnsignedByte();
                byte[] boundAddress = new byte[length];
                input.readFully(boundAddress);
            } else {
                throw new java.io.IOException("Unknown SOCKS5 address type");
            }
            input.readUnsignedShort(); // bound port
            return SystemClock.elapsedRealtime() - started;
        } finally {
            try { socket.close(); } catch (Exception ignored) { }
        }
    }

    private String socksReplyMessage(int code) {
        switch (code) {
            case 0x01: return "SOCKS5 general failure";
            case 0x02: return "Connection not allowed by SOCKS5 server";
            case 0x03: return "Network unreachable";
            case 0x04: return "Host unreachable";
            case 0x05: return "Connection refused";
            case 0x06: return "Connection timed out";
            case 0x07: return "SOCKS5 command not supported";
            case 0x08: return "SOCKS5 address type not supported";
            default: return "SOCKS5 connection failed (" + code + ")";
        }
    }

    private void updatePrivateDnsSummary() {
        if (mPrefPrivateDnsAddress == null || mProfile == null) return;
        String address = mProfile.getPrivateDnsAddress();
        boolean enabled = mProfile.isPrivateDnsEnabled();
        mPrefPrivateDnsAddress.setEnabled(true);
        if (TextUtils.isEmpty(address)) {
            mPrefPrivateDnsAddress.setSummary(enabled
                    ? "Enabled · address required · tap to enter a DoH URL"
                    : "Disabled · tap to enter an address");
        } else {
            mPrefPrivateDnsAddress.setSummary((enabled ? "Enabled · " : "Saved · ") + address);
        }
    }

    private void updateAppPickerSummary() {
        if (mPrefAppPicker == null || mProfile == null) return;
        String apps = mProfile.getAppList();
        int count = 0;
        if (!TextUtils.isEmpty(apps)) {
            for (String item : apps.split("\\n")) if (!TextUtils.isEmpty(item.trim())) count++;
        }
        mPrefAppPicker.setSummary(count + " app(s) selected · app names only");
    }

    private void checkState() {
        if (getActivity() == null) return;
        if (!mBound) {
            mBound = getActivity().bindService(new Intent(getActivity(), SocksVpnService.class),
                    mConnection, Context.BIND_AUTO_CREATE);
            if (!mBound) updateState();
        } else {
            updateState();
        }
    }

    private void scheduleStatePoll() {
        if (mSwitch != null && mUiResumed && (mStarting || mStopping)) {
            mSwitch.removeCallbacks(mStateRunnable);
            mSwitch.postDelayed(mStateRunnable, STATE_POLL_MS);
        }
    }

    private void updateState() {
        String serviceError = "";
        boolean serviceStopping = false;
        if (mBinder == null) {
            mRunning = false;
        } else {
            try {
                mRunning = mBinder.isRunning();
                serviceStopping = mBinder.isStopping();
                if (serviceStopping) mStopping = true;
                if (mStarting && mServiceStartDispatched) serviceError = mBinder.getLastError();
            } catch (Exception e) {
                mRunning = false;
                serviceStopping = false;
            }
        }

        long elapsed = SystemClock.elapsedRealtime() - mTransitionStartedAt;
        if (mStarting && mRunning) {
            mStarting = false;
            mServiceStartDispatched = false;
        }
        if (mStarting && mServiceStartDispatched && !mRunning
                && !TextUtils.isEmpty(serviceError)) {
            mStarting = false;
            mServiceStartDispatched = false;
            mPendingXrayConfig = null;
            showError(serviceError);
        }
        if (mStarting && elapsed > START_TIMEOUT_MS) {
            mStarting = false;
            mServiceStartDispatched = false;
            mPendingXrayConfig = null;
            if (getActivity() != null) {
                Toast.makeText(getActivity(), "VPN startup timed out. Check the saved proxy configuration.",
                        Toast.LENGTH_LONG).show();
            }
        }
        // Keep the control disabled until the service has actually finished
        // stopping its native processes and released the TUN interface.
        if (mStopping && !serviceStopping && !mRunning) mStopping = false;
        if (mStopping && elapsed > 20000L) {
            // Avoid leaving the screen permanently locked if Android kills the service.
            mStopping = false;
        }

        if (mSwitch != null) {
            mSwitch.setOnCheckedChangeListener(null);
            mSwitch.setChecked(mRunning);
            mSwitch.setEnabled(!mStarting && !mStopping);
            mSwitch.setOnCheckedChangeListener(this);
        }
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).setVpnUiState(mRunning, mStarting, mStopping);
        }
        scheduleStatePoll();
    }

    private void startVpn() {
        if (mStarting || mRunning) return;
        if (mProfile == null) {
            updateState();
            return;
        }
        if (mProfile.isPerApp() && !mProfile.isBypassApp()
                && TextUtils.isEmpty(mProfile.getAppList().trim())) {
            Toast.makeText(getActivity(), "Choose at least one app, or turn off app selection.",
                    Toast.LENGTH_LONG).show();
            updateState();
            return;
        }
        if (mProfile.isPrivateDnsEnabled()
                && TextUtils.isEmpty(mProfile.getPrivateDnsAddress())) {
            Toast.makeText(getActivity(), "Enter a Private DNS address first.",
                    Toast.LENGTH_LONG).show();
            updateState();
            return;
        }
        final String activeConfig;
        try {
            // Heavy JSON validation is done when saving the profile and again
            // inside the VPN service process. Keep the UI thread free on tap.
            activeConfig = Utility.buildActiveXrayConfig(mProfile);
        } catch (Exception e) {
            showError(e.getMessage());
            updateState();
            return;
        }

        mPendingXrayConfig = activeConfig;
        mServiceStartDispatched = false;
        if (mBinder != null) {
            try { mBinder.clearLastError(); } catch (Exception ignored) { }
        }
        mStarting = true;
        mTransitionStartedAt = SystemClock.elapsedRealtime();
        updateState();
        Intent permissionIntent = VpnService.prepare(getActivity());
        if (permissionIntent != null) {
            startActivityForResult(permissionIntent, REQUEST_VPN_PERMISSION);
        } else {
            mServiceStartDispatched = true;
            Utility.startVpn(getActivity(), mProfile, activeConfig);
            mPendingXrayConfig = null;
            checkState();
            scheduleStatePoll();
        }
    }

    private void stopVpn() {
        if (mBinder == null) {
            mStopping = false;
            updateState();
            return;
        }
        mStopping = true;
        mServiceStartDispatched = false;
        mTransitionStartedAt = SystemClock.elapsedRealtime();
        try { mBinder.stop(); }
        catch (Exception e) { mStopping = false; }
        updateState();
        scheduleStatePoll();
    }

}
