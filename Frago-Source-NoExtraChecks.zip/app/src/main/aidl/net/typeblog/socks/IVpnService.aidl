package net.typeblog.socks;

interface IVpnService
{
    boolean isRunning();
    boolean isStopping();
    String getLastError();
    void clearLastError();
    void stop();
}
