package net.typeblog.socks.util;

import android.util.Base64;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

/** Parser for common SIP002 and legacy Shadowsocks share links. */
public final class ShadowsocksUri {
    public static final class Config {
        public final String host;
        public final int port;
        public final String method;
        public final String password;

        Config(String host, int port, String method, String password) {
            this.host = host;
            this.port = port;
            this.method = method;
            this.password = password;
        }
    }

    private ShadowsocksUri() { }

    public static Config parse(String input) {
        if (input == null || input.trim().isEmpty()) {
            throw new IllegalArgumentException("Enter a Shadowsocks ss:// link.");
        }
        String value = input.trim();
        if (!value.regionMatches(true, 0, "ss://", 0, 5)) {
            throw new IllegalArgumentException("Shadowsocks link must start with ss://.");
        }
        String body = value.substring(5);
        int hash = body.indexOf('#');
        if (hash >= 0) body = body.substring(0, hash);
        int question = body.indexOf('?');
        if (question >= 0) {
            String query = body.substring(question + 1);
            if (query.toLowerCase(java.util.Locale.ROOT).contains("plugin=")) {
                throw new IllegalArgumentException("Plugin-based Shadowsocks links are not supported. Use a standard ss:// link.");
            }
            body = body.substring(0, question);
        }
        if (body.endsWith("/")) body = body.substring(0, body.length() - 1);

        String credentials;
        String endpoint;
        int at = body.lastIndexOf('@');
        if (at >= 0) {
            credentials = body.substring(0, at);
            endpoint = body.substring(at + 1);
            if (credentials.indexOf(':') < 0) credentials = decodeBase64(credentials);
        } else {
            String decoded = decodeBase64(body);
            int decodedAt = decoded.lastIndexOf('@');
            if (decodedAt < 0) {
                throw new IllegalArgumentException("Invalid Shadowsocks link: credentials and server address are missing.");
            }
            credentials = decoded.substring(0, decodedAt);
            endpoint = decoded.substring(decodedAt + 1);
        }

        credentials = urlDecode(credentials);
        int separator = credentials.indexOf(':');
        if (separator <= 0 || separator == credentials.length() - 1) {
            throw new IllegalArgumentException("Invalid Shadowsocks credentials. Expected method:password.");
        }
        String method = credentials.substring(0, separator).trim();
        String password = credentials.substring(separator + 1);
        if (method.isEmpty() || password.isEmpty()) {
            throw new IllegalArgumentException("Shadowsocks encryption method and password are required.");
        }

        endpoint = urlDecode(endpoint);
        String host;
        String portText;
        if (endpoint.startsWith("[")) {
            int end = endpoint.indexOf(']');
            if (end <= 1 || end + 2 > endpoint.length() || endpoint.charAt(end + 1) != ':') {
                throw new IllegalArgumentException("Invalid IPv6 address in Shadowsocks link.");
            }
            host = endpoint.substring(1, end);
            portText = endpoint.substring(end + 2);
        } else {
            int colon = endpoint.lastIndexOf(':');
            if (colon <= 0 || colon == endpoint.length() - 1) {
                throw new IllegalArgumentException("Invalid Shadowsocks server. Expected host:port.");
            }
            host = endpoint.substring(0, colon);
            portText = endpoint.substring(colon + 1);
        }
        int port;
        try { port = Integer.parseInt(portText); }
        catch (NumberFormatException e) { throw new IllegalArgumentException("Shadowsocks port must be a number."); }
        if (host.trim().isEmpty() || port < 1 || port > 65535) {
            throw new IllegalArgumentException("Invalid Shadowsocks server address or port.");
        }
        return new Config(host, port, method, password);
    }

    private static String decodeBase64(String value) {
        try {
            byte[] bytes;
            try { bytes = Base64.decode(value, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING); }
            catch (IllegalArgumentException first) { bytes = Base64.decode(value, Base64.DEFAULT); }
            return new String(bytes, StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid Base64 in Shadowsocks link.");
        }
    }

    private static String urlDecode(String value) {
        try { return URLDecoder.decode(value.replace("+", "%2B"), "UTF-8"); }
        catch (Exception e) { return value; }
    }
}
