package net.typeblog.socks.util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;

/** Validates and adapts an Xray JSON profile for Frago's local SOCKS and DNS bridges. */
public final class XrayConfig {
    public static final int DNS_INBOUND_BASE_PORT = 10530;
    private static final String DNS_IN_TAG = "socksdroid-dns-in";
    private static final String DNS_OUT_TAG = "socksdroid-dns-out";

    private XrayConfig() { }

    public static final class Prepared {
        public final String json;
        public final int socksPort;
        public final int dnsPort;

        private Prepared(String json, int socksPort, int dnsPort) {
            this.json = json;
            this.socksPort = socksPort;
            this.dnsPort = dnsPort;
        }
    }

    /**
     * Normalization is deliberately idempotent: the UI may validate a saved config
     * more than once, and the service validates it again immediately before launch.
     */
    public static Prepared prepare(String raw) throws JSONException {
        return prepare(raw, false, null);
    }

    /**
     * Applies an optional encrypted DNS-over-HTTPS resolver to the active Xray profile.
     * The override is applied to the runtime copy only; the user's saved JSON stays intact.
     */
    public static Prepared prepare(String raw, boolean privateDnsEnabled,
                                   String privateDnsAddress) throws JSONException {
        if (raw == null || raw.trim().isEmpty()) {
            throw new JSONException("The JSON configuration is empty.");
        }

        JSONObject root = new JSONObject(raw);
        if (privateDnsEnabled) {
            String address;
            try {
                address = normalizePrivateDnsAddress(privateDnsAddress);
            } catch (IllegalArgumentException e) {
                throw new JSONException(e.getMessage());
            }
            JSONObject dnsConfig = root.optJSONObject("dns");
            if (dnsConfig == null) {
                dnsConfig = new JSONObject();
                root.put("dns", dnsConfig);
            }
            // Frago's optional Private DNS is authoritative while enabled. Keeping only
            // this server avoids silently falling back to a plaintext DNS entry in the JSON.
            dnsConfig.put("servers", new JSONArray().put(address));
            dnsConfig.put("disableFallback", true);
        }
        JSONArray inbounds = root.optJSONArray("inbounds");
        if (inbounds == null) {
            inbounds = new JSONArray();
            root.put("inbounds", inbounds);
        }

        JSONObject socks = null;
        int socksPort;
        for (int i = 0; i < inbounds.length(); i++) {
            JSONObject inbound = inbounds.optJSONObject(i);
            if (inbound != null && "socks".equalsIgnoreCase(inbound.optString("protocol"))) {
                socks = inbound;
                break;
            }
        }
        if (socks == null) {
            socks = new JSONObject();
            socks.put("tag", "frago-socks-in");
            socksPort = nextFreePort(inbounds, 10808);
            socks.put("port", socksPort);
            socks.put("protocol", "socks");
            inbounds.put(socks);
        } else {
            socksPort = socks.optInt("port", -1);
            if (socksPort < 1 || socksPort > 65535) {
                socksPort = nextFreePort(inbounds, 10808);
                socks.put("port", socksPort);
            }
        }

        // Xray and the VPN bridge communicate over loopback only; do not expose a LAN proxy.
        socks.put("listen", "127.0.0.1");
        JSONObject socksSettings = socks.optJSONObject("settings");
        if (socksSettings == null) {
            socksSettings = new JSONObject();
            socks.put("settings", socksSettings);
        }
        // This private loopback listener is only for the app's own bridge; disable
        // inbound credentials so the existing tun2socks client can connect to it.
        socksSettings.put("auth", "noauth");
        socksSettings.remove("accounts");
        socksSettings.put("udp", false);


        JSONArray outbounds = root.optJSONArray("outbounds");
        if (outbounds == null || outbounds.length() == 0) {
            throw new JSONException("Xray config must contain at least one outbound.");
        }

        int dnsPort = 0;
        if (root.optJSONObject("dns") != null) {
            JSONObject dnsInbound = findManagedDnsInbound(inbounds);
            String dnsInTag;
            if (dnsInbound == null) {
                dnsInTag = uniqueTag(inbounds, DNS_IN_TAG);
                dnsPort = nextFreePort(inbounds, DNS_INBOUND_BASE_PORT);
                dnsInbound = new JSONObject();
                dnsInbound.put("tag", dnsInTag);
                inbounds.put(dnsInbound);
            } else {
                dnsInTag = dnsInbound.optString("tag");
                dnsPort = dnsInbound.optInt("port", -1);
                if (dnsPort < 1 || dnsPort > 65535) {
                    throw new JSONException("The saved Frago DNS inbound has an invalid port.");
                }
            }

            // pdnsd sends TCP DNS to this private inbound. The dns outbound's default
            // A/AAAA fallback imports those queries into Xray's configured DNS module.
            dnsInbound.put("listen", "127.0.0.1");
            dnsInbound.put("port", dnsPort);
            dnsInbound.put("protocol", "dokodemo-door");
            JSONObject dnsInboundSettings = dnsInbound.optJSONObject("settings");
            if (dnsInboundSettings == null) dnsInboundSettings = new JSONObject();
            dnsInboundSettings.put("address", "127.0.0.1");
            dnsInboundSettings.put("port", 53);
            dnsInboundSettings.put("network", "tcp,udp");
            dnsInbound.put("settings", dnsInboundSettings);

            JSONObject dnsOutbound = findManagedDnsOutbound(outbounds);
            String dnsOutTag;
            if (dnsOutbound == null) {
                dnsOutTag = uniqueTag(outbounds, DNS_OUT_TAG);
                dnsOutbound = new JSONObject();
                dnsOutbound.put("tag", dnsOutTag);
                dnsOutbound.put("protocol", "dns");
                outbounds.put(dnsOutbound);
            } else {
                dnsOutTag = dnsOutbound.optString("tag");
                dnsOutbound.put("protocol", "dns");
            }

            JSONObject routing = root.optJSONObject("routing");
            if (routing == null) {
                routing = new JSONObject();
                routing.put("domainStrategy", "AsIs");
                root.put("routing", routing);
            }
            JSONArray rules = routing.optJSONArray("rules");
            if (rules == null) rules = new JSONArray();

            if (!hasDnsRoute(rules, dnsInTag, dnsOutTag)) {
                JSONObject dnsRule = new JSONObject();
                dnsRule.put("type", "field");
                JSONArray inboundTags = new JSONArray();
                inboundTags.put(dnsInTag);
                dnsRule.put("inboundTag", inboundTags);
                dnsRule.put("outboundTag", dnsOutTag);
                JSONArray orderedRules = new JSONArray();
                orderedRules.put(dnsRule);
                for (int i = 0; i < rules.length(); i++) orderedRules.put(rules.get(i));
                routing.put("rules", orderedRules);
            }
        }

        return new Prepared(root.toString(2), socksPort, dnsPort);
    }

    /**
     * Accepts an HTTPS DoH URL or a host/path and normalizes it to an HTTPS endpoint.
     * A bare hostname gets the standard /dns-query path.
     */
    public static String normalizePrivateDnsAddress(String raw) {
        if (raw == null || raw.trim().isEmpty()) {
            throw new IllegalArgumentException("Enter a Private DNS DoH address first.");
        }
        String value = raw.trim();
        if (!value.contains("://")) value = "https://" + value;
        try {
            URI uri = new URI(value);
            if (!"https".equalsIgnoreCase(uri.getScheme())) {
                throw new IllegalArgumentException("Private DNS must use HTTPS, for example https://dns.google/dns-query.");
            }
            if (uri.getHost() == null || uri.getHost().trim().isEmpty()
                    || uri.getUserInfo() != null || uri.getFragment() != null
                    || uri.getPort() == 0 || uri.getPort() > 65535) {
                throw new IllegalArgumentException("The Private DNS address is not a valid HTTPS URL.");
            }
            String path = uri.getPath();
            if (path == null || path.isEmpty() || "/".equals(path)) path = "/dns-query";
            URI normalized = new URI("https", null, uri.getHost(), uri.getPort(),
                    path, uri.getQuery(), null);
            return normalized.toASCIIString();
        } catch (java.net.URISyntaxException e) {
            throw new IllegalArgumentException("The Private DNS address is not a valid HTTPS URL.");
        }
    }

    private static JSONObject findManagedDnsInbound(JSONArray inbounds) {
        for (int i = 0; i < inbounds.length(); i++) {
            JSONObject inbound = inbounds.optJSONObject(i);
            if (inbound == null) continue;
            String tag = inbound.optString("tag");
            if (isManagedTag(tag, DNS_IN_TAG)
                    && "dokodemo-door".equalsIgnoreCase(inbound.optString("protocol"))) {
                return inbound;
            }
        }
        return null;
    }

    private static JSONObject findManagedDnsOutbound(JSONArray outbounds) {
        for (int i = 0; i < outbounds.length(); i++) {
            JSONObject outbound = outbounds.optJSONObject(i);
            if (outbound == null) continue;
            String tag = outbound.optString("tag");
            if (isManagedTag(tag, DNS_OUT_TAG)
                    && "dns".equalsIgnoreCase(outbound.optString("protocol"))) {
                return outbound;
            }
        }
        return null;
    }

    private static boolean isManagedTag(String tag, String base) {
        return base.equals(tag) || (tag != null && tag.startsWith(base + "-"));
    }

    private static boolean hasDnsRoute(JSONArray rules, String inboundTag, String outboundTag) {
        for (int i = 0; i < rules.length(); i++) {
            JSONObject rule = rules.optJSONObject(i);
            if (rule == null || !outboundTag.equals(rule.optString("outboundTag"))) continue;
            JSONArray tags = rule.optJSONArray("inboundTag");
            if (tags == null) continue;
            for (int j = 0; j < tags.length(); j++) {
                if (inboundTag.equals(tags.optString(j))) return true;
            }
        }
        return false;
    }

    private static int nextFreePort(JSONArray inbounds, int start) throws JSONException {
        for (int port = start; port < start + 100; port++) {
            boolean used = false;
            for (int i = 0; i < inbounds.length(); i++) {
                JSONObject inbound = inbounds.optJSONObject(i);
                if (inbound != null && inbound.optInt("port", -1) == port) {
                    used = true;
                    break;
                }
            }
            if (!used) return port;
        }
        throw new JSONException("Could not find a free local port for the DNS bridge.");
    }

    private static String uniqueTag(JSONArray items, String base) {
        String candidate = base;
        int suffix = 1;
        while (hasTag(items, candidate)) candidate = base + "-" + suffix++;
        return candidate;
    }

    private static boolean hasTag(JSONArray items, String tag) {
        if (items == null) return false;
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item != null && tag.equals(item.optString("tag"))) return true;
        }
        return false;
    }
}
