package net.typeblog.socks;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.util.Log;

import net.typeblog.socks.util.Routes;
import net.typeblog.socks.util.Utility;
import net.typeblog.socks.util.XrayConfig;

import java.io.File;
import java.io.FileOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.Locale;
import java.util.Objects;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.TimeUnit;

import static net.typeblog.socks.util.Constants.*;
import static net.typeblog.socks.BuildConfig.DEBUG;

public class SocksVpnService extends VpnService {
    class VpnBinder extends IVpnService.Stub {
        @Override
        public boolean isRunning() {
            return mRunning;
        }

        @Override
        public boolean isStarting() {
            return mStarting;
        }

        @Override
        public boolean isStopping() {
            return mStopping;
        }

        @Override
        public String getLastError() {
            return mLastError == null ? "" : mLastError;
        }

        @Override
        public void clearLastError() {
            mLastError = null;
        }

        @Override
        public void stop() {
            stopMe();
        }
    }

    private static final String TAG = SocksVpnService.class.getSimpleName();
    private static final long XRAY_START_TIMEOUT_MS = 25000L;

    private volatile ParcelFileDescriptor mInterface;
    private final Object mInterfaceLock = new Object();
    private final Object mLifecycleLock = new Object();
    private final Object mProcessLock = new Object();
    private volatile boolean mRunning = false;
    private volatile boolean mStarting = false;
    private volatile boolean mStopping = false;
    private volatile Process mXrayProcess;
    private volatile String mLastError;
    private final AtomicBoolean mStopStarted = new AtomicBoolean(false);
    private volatile int mLastStartId;
    private volatile int mStopStartId;
    // Every stop invalidates the active generation, preventing an old worker from
    // starting native daemons after a fast OFF -> ON transition.
    private volatile long mSessionGeneration;
    private final IBinder mBinder = new VpnBinder();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_STOP_VPN.equals(intent.getAction())) {
            boolean cleanupAlreadyFinished = false;
            synchronized (mLifecycleLock) {
                mLastStartId = startId;
                if (mStopping) {
                    // Make stopSelfResult account for duplicate OFF commands while
                    // the same cleanup worker is still running.
                    mStopStartId = startId;
                } else if (mStopStarted.get()) {
                    // Cleanup completed just before this duplicate stop arrived.
                    // Finish the stop request without launching another worker.
                    try { stopForeground(true); } catch (Exception ignored) { }
                    notifyUiState();
                    cleanupAlreadyFinished = true;
                }
            }
            if (cleanupAlreadyFinished) stopSelfResult(startId);
            else stopMe();
            return START_NOT_STICKY;
        }
        final long sessionId;
        synchronized (mLifecycleLock) {
            if (mRunning || mStarting || mStopping) return START_NOT_STICKY;
            // The service may remain bound after stop. A new generation is accepted
            // only after the previous cleanup has completed.
            mStopStarted.set(false);
            mLastStartId = startId;
            sessionId = ++mSessionGeneration;
            mLastError = null;
            mStopping = false;
            mRunning = false;
            mStarting = true;
        }
        notifyUiState();

        final String name = intent.getStringExtra(INTENT_NAME);
        // Promote immediately; Android may terminate a service that does not call
        // startForeground soon after startForegroundService(), especially on 12+.
        startVpnForeground(name);

        String server = intent.getStringExtra(INTENT_SERVER);
        int port = intent.getIntExtra(INTENT_PORT, 1080);
        String username = intent.getStringExtra(INTENT_USERNAME);
        String passwd = intent.getStringExtra(INTENT_PASSWORD);
        final String route = intent.getStringExtra(INTENT_ROUTE);
        final String dns = intent.getStringExtra(INTENT_DNS);
        final int dnsPort = intent.getIntExtra(INTENT_DNS_PORT, 53);
        final boolean perApp = intent.getBooleanExtra(INTENT_PER_APP, false);
        final boolean appBypass = intent.getBooleanExtra(INTENT_APP_BYPASS, false);
        final String[] appList = intent.getStringArrayExtra(INTENT_APP_LIST);
        final boolean ipv6 = intent.getBooleanExtra(INTENT_IPV6_PROXY, false);
        final boolean xrayMode = intent.getBooleanExtra(INTENT_XRAY_MODE, false);
        String xrayConfig = intent.getStringExtra(INTENT_XRAY_CONFIG);
        final boolean privateDnsEnabled = intent.getBooleanExtra(INTENT_PRIVATE_DNS_ENABLED, false);
        final String privateDnsAddress = intent.getStringExtra(INTENT_PRIVATE_DNS_ADDRESS);
        int xrayDnsPort = 0;

        if (xrayMode) {
            try {
                XrayConfig.Prepared prepared = XrayConfig.prepare(
                        xrayConfig, privateDnsEnabled, privateDnsAddress);
                xrayConfig = prepared.json;
                xrayDnsPort = prepared.dnsPort;
                server = "127.0.0.1";
                port = prepared.socksPort;
                username = null;
                passwd = null;
            } catch (Exception e) {
                mLastError = "Invalid Frago configuration: " + e.getMessage();
                notifyUiState();
                stopMe();
                return START_NOT_STICKY;
            }
        }

        try {
            // Serialize TUN creation with stop requests. This closes a race where
            // cleanup could finish before Builder.establish() returned its descriptor.
            synchronized (mLifecycleLock) {
                if (!isSessionActive(sessionId)) return START_NOT_STICKY;
                configure(name, route, perApp, appBypass, appList, ipv6);
            }
        } catch (Exception e) {
            if (isSessionActive(sessionId)) {
                mLastError = "Could not create the Android VPN interface: " + e.getMessage();
                Log.e(TAG, "VPN interface setup failed", e);
                stopMe();
            }
            return START_NOT_STICKY;
        }
        final String finalServer = server;
        final int finalPort = port;
        final String finalUsername = username;
        final String finalPasswd = passwd;
        final String finalXrayConfig = xrayConfig;
        final int finalXrayDnsPort = xrayDnsPort;
        int interfaceFd = -1;
        Exception descriptorError = null;
        synchronized (mLifecycleLock) {
            if (!isSessionActive(sessionId)) return START_NOT_STICKY;
            try {
                ParcelFileDescriptor tun = mInterface;
                if (tun != null) interfaceFd = tun.getFd();
            } catch (Exception e) {
                descriptorError = e;
            }
            if (interfaceFd >= 0) {
                final int fd = interfaceFd;
                new Thread(() -> start(sessionId, fd, finalServer, finalPort,
                        finalUsername, finalPasswd, dns, dnsPort, ipv6, xrayMode,
                        finalXrayConfig, finalXrayDnsPort), "Frago-Connect").start();
            }
        }
        if (interfaceFd < 0) {
            if (isSessionActive(sessionId)) {
                mLastError = "Android could not create the VPN interface. Check VPN permission and app settings."
                        + (descriptorError == null ? "" : " " + descriptorError.getMessage());
                Log.e(TAG, "Could not obtain the VPN interface descriptor", descriptorError);
                stopMe();
            }
            return START_NOT_STICKY;
        }

        return START_NOT_STICKY;
    }

    @Override
    public void onRevoke() {
        super.onRevoke();
        stopMe();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onDestroy() {
        stopMe();
        super.onDestroy();
    }

    private void stopMe() {
        synchronized (mLifecycleLock) {
            if (!mStopStarted.compareAndSet(false, true)) return;
            mStopping = true;
            mStarting = false;
            mStopStartId = mLastStartId;
            ++mSessionGeneration; // invalidate every worker belonging to the stopped session
        }
        notifyUiState();
        new Thread(this::finishStop, "Frago-Stop").start();
    }

    private void finishStop() {
        // Stop the SocksDroid tunnel bridge and DNS daemon before releasing TUN.
        Utility.killPidFile(getFilesDir() + "/tun2socks.pid", "libtun2socks.so");
        Utility.killPidFile(getFilesDir() + "/pdnsd.pid", "libpdnsd.so");
        deleteLocalSocketPath();

        Process xray;
        synchronized (mProcessLock) {
            xray = mXrayProcess;
            mXrayProcess = null;
        }
        if (xray != null) {
            try {
                xray.destroy();
                if (Build.VERSION.SDK_INT >= 26 && !xray.waitFor(1500L, TimeUnit.MILLISECONDS)) {
                    xray.destroyForcibly();
                }
            } catch (Exception e) {
                try { xray.destroy(); } catch (Exception ignored) { }
            }
        }

        ParcelFileDescriptor tun;
        synchronized (mInterfaceLock) {
            tun = mInterface;
            mInterface = null;
        }
        if (tun != null) {
            // Transfer FD ownership out of ParcelFileDescriptor, then close it
            // through the same native helper used by SocksDroid. This guarantees
            // the descriptor is closed exactly once after tun2socks has stopped.
            try {
                int fd = tun.detachFd();
                if (fd >= 0) System.jniclose(fd);
            } catch (Exception e) {
                try { tun.close(); } catch (Exception ignored) { }
                if (DEBUG) Log.d(TAG, "TUN descriptor was already detached", e);
            }
        }

        final int completedStartId;
        synchronized (mLifecycleLock) {
            mRunning = false;
            mStarting = false;
            // Remove the old notification before allowing a new session to enter
            // onStartCommand. Otherwise a fast ON could have its notification
            // removed by this older stop worker.
            try { stopForeground(true); } catch (Exception ignored) { }
            mStopping = false;
            completedStartId = mStopStartId;
            notifyUiState();
        }
        if (completedStartId > 0) stopSelfResult(completedStartId);
        else stopSelf();
    }

    private boolean deleteLocalSocketPath() {
        File socketPath = new File(getApplicationInfo().dataDir, "sock_path");
        return !socketPath.exists() || socketPath.delete();
    }

    private void startVpnForeground(String name) {
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            String channelId = "net.typeblog.socks";
            NotificationChannel channel = new NotificationChannel(channelId,
                    getString(R.string.channel_name), NotificationManager.IMPORTANCE_MIN);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            Objects.requireNonNull(notificationManager).createNotificationChannel(channel);
            builder = new Notification.Builder(this, channelId);
        } else {
            builder = new Notification.Builder(this);
        }

        int intentFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) intentFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), intentFlags);
        startForeground(1, builder
                .setContentTitle(getString(R.string.notify_title))
                .setContentText(String.format(getString(R.string.notify_msg), name))
                .setPriority(Notification.PRIORITY_MIN)
                .setSmallIcon(R.drawable.ic_vpn)
                .setContentIntent(contentIntent)
                .build());
    }

    private void notifyUiState() {
        Intent state = new Intent(ACTION_VPN_STATE);
        state.setPackage(getPackageName());
        state.putExtra(EXTRA_VPN_RUNNING, mRunning);
        state.putExtra(EXTRA_VPN_STARTING, mStarting);
        state.putExtra(EXTRA_VPN_STOPPING, mStopping);
        state.putExtra(EXTRA_VPN_ERROR, mLastError == null ? "" : mLastError);
        sendBroadcast(state);
    }

    private void configure(String name, String route, boolean perApp, boolean bypass, String[] apps, boolean ipv6) {
        Builder b = new Builder();
        b.setMtu(1500)
                .setSession(name)
                .addAddress("26.26.26.1", 24)
                .addDnsServer("8.8.8.8");

        if (ipv6) {
            b.addAddress("fdfe:dcba:9876::1", 126).addRoute("::", 0);
        }

        Routes.addRoutes(this, b, route);
        // DNS packets are sent to the local pdnsd gateway; in Xray mode pdnsd
        // forwards them to Xray's private DNS inbound.
        b.addRoute("8.8.8.8", 32);

        if (!perApp) {
            try { b.addDisallowedApplication("net.typeblog.socks"); }
            catch (Exception e) { Log.w(TAG, "Could not bypass Frago", e); }
        } else if (bypass) {
            try { b.addDisallowedApplication("net.typeblog.socks"); }
            catch (Exception e) { Log.w(TAG, "Could not bypass Frago", e); }
            if (apps != null) {
                for (String p : apps) {
                    if (TextUtils.isEmpty(p)) continue;
                    try { b.addDisallowedApplication(p.trim()); }
                    catch (Exception e) { Log.w(TAG, "Could not bypass " + p, e); }
                }
            }
        } else if (apps != null) {
            for (String p : apps) {
                if (TextUtils.isEmpty(p) || p.trim().equals("net.typeblog.socks")) continue;
                try { b.addAllowedApplication(p.trim()); }
                catch (Exception e) { Log.w(TAG, "Could not include " + p, e); }
            }
        }

        ParcelFileDescriptor established = b.establish();
        synchronized (mInterfaceLock) {
            if (mStopping) {
                if (established != null) try { established.close(); } catch (Exception ignored) { }
            } else {
                mInterface = established;
            }
        }
    }

    private void start(long sessionId, int fd, String server, int port, String user, String passwd,
                       String dns, int dnsPort, boolean ipv6, boolean xrayMode,
                       String xrayConfig, int xrayDnsPort) {
        if (!isSessionActive(sessionId)) return;

        // A previous Android process may have been killed before its native
        // daemons removed their pid/socket files. Clean only Frago-owned daemons
        // once at session start; this is not a background monitor or polling loop.
        Utility.killPidFile(getFilesDir() + "/tun2socks.pid", "libtun2socks.so");
        Utility.killPidFile(getFilesDir() + "/pdnsd.pid", "libpdnsd.so");
        if (!deleteLocalSocketPath() && isSessionActive(sessionId)) {
            mLastError = "Could not clear the previous local tunnel socket. Please stop Frago and try again.";
            stopMe();
            return;
        }

        if (xrayMode) {
            if (!startXray(xrayConfig, port, sessionId)) {
                if (isSessionActive(sessionId)) stopMe();
                return;
            }
            if (!isSessionActive(sessionId)) return;
        }
        int dnsExit;
        synchronized (mLifecycleLock) {
            if (!isSessionActive(sessionId)) return;
            // Write the DNS config and start pdnsd in the same lifecycle section.
            // An old worker can therefore never overwrite the next session's config.
            if (xrayMode && xrayDnsPort > 0) {
                Utility.makePdnsdConf(this, "127.0.0.1", xrayDnsPort);
            } else {
                Utility.makePdnsdConf(this, dns, dnsPort);
            }
            dnsExit = Utility.exec(String.format(Locale.US, "%s/libpdnsd.so -c %s/pdnsd.conf",
                    getApplicationInfo().nativeLibraryDir, getFilesDir()));
        }
        if (dnsExit != 0) {
            if (!isSessionActive(sessionId)) return;
            mLastError = "The local DNS relay could not start.";
            Log.e(TAG, "pdnsd failed to start");
            stopMe();
            return;
        }

        String socksAddress = server != null && server.indexOf(':') >= 0
                && !server.startsWith("[") ? "[" + server + "]" : server;
        java.util.ArrayList<String> command = new java.util.ArrayList<>();
        command.add(getApplicationInfo().nativeLibraryDir + "/libtun2socks.so");
        Collections.addAll(command,
                "--netif-ipaddr", "26.26.26.2",
                "--netif-netmask", "255.255.255.0",
                "--socks-server-addr", socksAddress + ":" + port,
                "--tunfd", Integer.toString(fd),
                "--tunmtu", "1500",
                "--loglevel", "3",
                "--pid", getFilesDir() + "/tun2socks.pid",
                "--sock", getApplicationInfo().dataDir + "/sock_path");

        if (user != null && !user.isEmpty()) {
            command.add("--username");
            command.add(user);
            command.add("--password");
            command.add(passwd == null ? "" : passwd);
        }
        if (ipv6) {
            command.add("--netif-ip6addr");
            command.add("fdfe:dcba:9876::2");
        }

        // DNS is handled by the existing pdnsd gateway in both modes. In Xray mode
        // pdnsd forwards it to the local Xray DNS inbound configured above.
        Collections.addAll(command, "--dnsgw", "26.26.26.1:8091");

        if (DEBUG) Log.d(TAG, "Launching tun2socks tunnel bridge");
        int tunnelExit;
        synchronized (mLifecycleLock) {
            if (!isSessionActive(sessionId)) return;
            tunnelExit = Utility.exec(command.toArray(new String[0]));
        }
        if (tunnelExit != 0) {
            if (!isSessionActive(sessionId)) return;
            mLastError = "The VPN tunnel engine (tun2socks) failed to start.";
            Log.e(TAG, "tun2socks failed to start");
            stopMe();
            return;
        }

        for (int i = 0; i < 5 && isSessionActive(sessionId); i++) {
            int sentFd;
            synchronized (mLifecycleLock) {
                if (!isSessionActive(sessionId)) return;
                sentFd = System.sendfd(fd, getApplicationInfo().dataDir + "/sock_path");
            }
            if (sentFd != -1) {
                synchronized (mLifecycleLock) {
                    if (!isSessionActive(sessionId)) return;
                    mRunning = true;
                    mStarting = false;
                    mLastError = null;
                }
                notifyUiState();
                return;
            }
            try { Thread.sleep(1000L * (i + 1)); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
        }
        if (isSessionActive(sessionId)) {
            mLastError = "Could not attach the VPN tunnel to the local proxy. Check the selected output.";
            stopMe();
        }
    }

    private boolean startXray(String config, int socksPort, long sessionId) {
        try {
            if (TextUtils.isEmpty(config)) throw new IllegalArgumentException("No Xray JSON configuration has been saved.");
            File core = new File(getApplicationInfo().nativeLibraryDir, "libxray.so");
            if (!core.exists()) throw new IllegalStateException("The bundled Xray engine is missing.");

            File configFile = new File(getFilesDir(), "xray-config.json");
            File logFile = new File(getFilesDir(), "xray.log");
            Process process;
            // Serialize file replacement and process creation with stop/start. This
            // prevents a stale connection worker from overwriting a newer JSON file.
            synchronized (mLifecycleLock) {
                if (!isSessionActive(sessionId)) return false;
                FileOutputStream out = new FileOutputStream(configFile, false);
                try {
                    out.write(config.getBytes(Charset.forName("UTF-8")));
                    out.flush();
                } finally {
                    out.close();
                }

                ProcessBuilder processBuilder = new ProcessBuilder(core.getAbsolutePath(),
                        "run", "-config", configFile.getAbsolutePath());
                processBuilder.directory(getFilesDir());
                processBuilder.redirectErrorStream(true);
                processBuilder.redirectOutput(logFile);
                process = processBuilder.start();
                synchronized (mProcessLock) {
                    if (!isSessionActive(sessionId)) {
                        process.destroy();
                        return false;
                    }
                    mXrayProcess = process;
                }
            }

            long deadline = java.lang.System.currentTimeMillis() + XRAY_START_TIMEOUT_MS;
            while (isSessionActive(sessionId) && java.lang.System.currentTimeMillis() < deadline) {
                if (!isProcessAlive(process)) {
                    mLastError = "Xray exited during startup. Check the Xray configuration and protocol settings.";
                    Log.e(TAG, "Xray exited during startup. Check " + logFile.getAbsolutePath());
                    return false;
                }
                Socket socket = null;
                try {
                    socket = new Socket();
                    socket.connect(new InetSocketAddress("127.0.0.1", socksPort), 350);
                    if (!isSessionActive(sessionId)) return false;
                    if (DEBUG) Log.d(TAG, "Xray local SOCKS inbound is ready.");
                    return true;
                } catch (Exception ignored) {
                    // The local inbound may need a short moment to start.
                } finally {
                    if (socket != null) try { socket.close(); } catch (Exception ignored) { }
                }
                try { Thread.sleep(200L); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
            }
            if (!isSessionActive(sessionId)) return false;
            mLastError = "Xray did not open its local SOCKS port " + socksPort + ". Check the proxy link and JSON.";
            Log.e(TAG, "Timed out waiting for Xray SOCKS inbound.");
            return false;
        } catch (Exception e) {
            if (isSessionActive(sessionId)) {
                mLastError = "Could not start Xray: " + e.getMessage();
                Log.e(TAG, "Could not start bundled Xray engine", e);
            }
            return false;
        }
    }

    private boolean isSessionActive(long sessionId) {
        return !mStopping && mSessionGeneration == sessionId;
    }

    private boolean isProcessAlive(Process process) {
        try {
            process.exitValue();
            return false;
        } catch (IllegalThreadStateException stillRunning) {
            return true;
        }
    }
}
