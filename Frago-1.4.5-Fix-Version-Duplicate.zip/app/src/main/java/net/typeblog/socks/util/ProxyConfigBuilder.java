package net.typeblog.socks.util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Builds small Xray proxy configs used behind Frago's SocksDroid-style TUN bridge. */
public final class ProxyConfigBuilder {
    private ProxyConfigBuilder() { }

    public static String build(Profile profile) throws Exception {
        if (profile == null) throw new IllegalArgumentException("No active profile.");
        String type = profile.getOutputType();
        if (Profile.OUTPUT_FRAGMENT.equals(type)) {
            String json = profile.getXrayConfig();
            if (json == null || json.trim().isEmpty()) {
                throw new IllegalArgumentException("Paste and save the Fragment JSON first.");
            }
            // Validate a copy but preserve the exact saved JSON string.
            XrayConfig.prepare(json);
            return json;
        }
        if (Profile.OUTPUT_SOCKS.equals(type)) return buildSocks(profile);
        if (Profile.OUTPUT_SHADOWSOCKS.equals(type)) return buildShadowsocks(profile);
        throw new IllegalArgumentException("Select SOCKS5, Shadowsocks or Fragment.");
    }

    private static String buildSocks(Profile profile) throws JSONException {
        String host = profile.getSocksHost();
        int port = profile.getSocksPort();
        if (host == null || host.trim().isEmpty()) {
            throw new IllegalArgumentException("Enter the SOCKS5 server address.");
        }
        if (port < 1 || port > 65535) {
            throw new IllegalArgumentException("SOCKS5 port must be between 1 and 65535.");
        }
        String user = profile.getSocksUsername();
        String password = profile.getSocksPassword();
        if ((user == null || user.isEmpty()) && password != null && !password.isEmpty()) {
            throw new IllegalArgumentException("Enter both SOCKS5 username and password, or leave both empty.");
        }

        JSONObject server = new JSONObject();
        server.put("address", host.trim());
        server.put("port", port);
        if (user != null && !user.isEmpty()) {
            JSONArray users = new JSONArray();
            JSONObject credentials = new JSONObject();
            credentials.put("user", user);
            credentials.put("pass", password == null ? "" : password);
            users.put(credentials);
            server.put("users", users);
        }
        JSONObject settings = new JSONObject();
        settings.put("servers", new JSONArray().put(server));
        return rootWithOutbound("socks", settings).toString(2);
    }

    private static String buildShadowsocks(Profile profile) throws JSONException {
        ShadowsocksUri.Config parsed = ShadowsocksUri.parse(profile.getShadowsocksUri());
        JSONObject server = new JSONObject();
        server.put("address", parsed.host);
        server.put("port", parsed.port);
        server.put("method", parsed.method);
        server.put("password", parsed.password);

        JSONObject settings = new JSONObject();
        settings.put("servers", new JSONArray().put(server));
        return rootWithOutbound("shadowsocks", settings).toString(2);
    }

    private static JSONObject rootWithOutbound(String protocol, JSONObject settings) throws JSONException {
        JSONObject root = new JSONObject();
        JSONObject log = new JSONObject();
        log.put("loglevel", "none");
        root.put("log", log);

        JSONObject outbound = new JSONObject();
        outbound.put("tag", "proxy");
        outbound.put("protocol", protocol);
        outbound.put("settings", settings);
        JSONArray outbounds = new JSONArray();
        outbounds.put(outbound);

        JSONObject direct = new JSONObject();
        direct.put("tag", "direct");
        direct.put("protocol", "freedom");
        outbounds.put(direct);
        root.put("outbounds", outbounds);
        return root;
    }
}
