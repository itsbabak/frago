# تغییرات Frago 1.4.1

- معماری VPN از الگوی SocksDroid حفظ شده است: Android VpnService، رابط TUN و tun2socks.
- در حالت SOCKS5 بدون Private DNS، tun2socks مستقیماً به سرور SOCKS وصل می‌شود و Xray اجرا نمی‌شود تا مصرف منابع کمتر باشد.
- در حالت SOCKS5 همراه Private DNS، Xray فقط برای مسیر DoH و پروکسی SOCKS انتخاب‌شده فعال می‌شود.
- سه خروجی SOCKS5، Shadowsocks و Fragment در یک رابط باقی مانده‌اند.
- SOCKS5 با آدرس، پورت و اطلاعات ورود اختیاری پشتیبانی می‌شود.
- Shadowsocks لینک‌های استاندارد ss:// در قالب SIP002 و Base64 قدیمی را می‌پذیرد؛ لینک‌های دارای plugin فعلاً پشتیبانی نمی‌شوند.
- Fragment از JSON کامل Xray که دستی وارد شده استفاده می‌کند و هنگام تغییر نوع خروجی بازنویسی نمی‌شود.
- Private DNS مبتنی بر DoH روی پیکربندی اجرایی هر سه خروجی اعمال می‌شود و متن پروفایل ذخیره‌شده را تغییر نمی‌دهد.
- انتخاب اپلیکیشن با نام نمایشی برنامه حفظ شده است.
- وضعیت روشن/خاموش سرویس با رویدادهای تغییر وضعیت به رابط اعلام می‌شود؛ polling دوره‌ای رابط حذف شده است.
- شروع/توقف با شناسهٔ نشست محافظت می‌شود تا پردازش قدیمی پس از خاموشی دوباره تونل را روشن نکند.
- درخواست توقف در صورت متصل‌نبودن Binder نیز به خود سرویس ارسال می‌شود.
- سرویس قبل از پردازش JSON، اعلان Foreground را فعال می‌کند تا با محدودیت زمانی Android برای Foreground Service برخورد نکند.
- در مسیر خاموشی، پاک‌سازی tun2socks، DNS relay، موتور Xray و TUN به‌صورت سریالی انجام می‌شود تا شروع مجدد با پاک‌سازی قبلی تداخل نکند.
- بسته فقط برای arm64-v8a ساخته می‌شود؛ کتابخانه یا موتور جدیدی افزوده نشده است.


## Frago 1.4.2 — SocksDroid-style lifecycle hardening

- The VPN transport remains the SocksDroid architecture: Android `VpnService`, a TUN descriptor, and the existing `tun2socks` native bridge.
- SOCKS5 direct mode uses that bridge directly. Shadowsocks and Fragment JSON use the bundled Xray process as the local SOCKS endpoint behind the same TUN service. Private DNS stays on the Xray DoH route when enabled.
- Stop now terminates only native daemons whose `/proc/<pid>/cmdline` matches Frago's expected binary, avoiding stale PID files killing an unrelated process.
- Stale PID and Unix socket files are cleared once at start and at stop. TUN ownership is detached and closed through the existing JNI close helper after native tunnel shutdown.
- No background polling, periodic health check, extra log polling, or new third-party dependency was added.
