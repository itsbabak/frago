# Frago

Frago is an Android ARM64 VPN client built around the SocksDroid-style Android `VpnService` + TUN + `tun2socks` bridge. Xray is used as the local proxy backend for the selected output; it does not replace Android VPN/TUN management.

## One-screen interface
- SOCKS5 output: server, port and optional username/password.
- Shadowsocks output: manual standard `ss://` share-link entry. SIP002 and legacy Base64 forms are supported; plugin-based links are not.
- Fragment output: full Xray JSON entered manually; the saved text is not rewritten when another output type is selected.
- Optional Private DNS over HTTPS, applied to the runtime configuration for the selected output.
- Per-app selection, shown with app display names.
- TCP latency test through the selected output.
- One VPN start/stop control shared by all output types.

## Runtime architecture
All modes use the SocksDroid-style Android `VpnService` + TUN + `tun2socks` bridge.

- SOCKS5 without Private DNS: `tun2socks` connects directly to the remote SOCKS5 server. Xray is not started, reducing memory and CPU use.
- SOCKS5 with Private DNS: Xray is used as the DoH helper and SOCKS5 outbound so encrypted DNS follows the selected proxy.
- Shadowsocks and Fragment: Xray exposes a loopback SOCKS inbound; `tun2socks` forwards traffic to it and Xray handles the selected outbound/JSON.

The same VPN service owns all TUN creation, start/stop transitions and cleanup. A session-generation guard prevents an old connection worker from launching native processes after a stop request. The UI receives state-change broadcasts and has no periodic status polling or background health monitor. The existing one-time local proxy startup coordination remains only for modes that actually start Xray.

## Build
Use the GitHub Actions workflow at `.github/workflows/build-arm64-apk.yml` to build the ARM64 APK.

## Architecture

Frago keeps the SocksDroid VPN transport model: Android `VpnService` establishes the TUN interface and the bundled `tun2socks` bridge forwards traffic to a loopback or remote SOCKS endpoint. SOCKS5 can use the native bridge directly; Shadowsocks and Fragment JSON use Xray behind the same SOCKS bridge. Private DNS is provided by Xray DoH when enabled.

The service start/stop lifecycle is serialized and session-scoped. Native PID cleanup checks the actual process command line, stale local socket files are removed between sessions, and the TUN file descriptor is released through the JNI close helper after tunnel processes stop. No periodic monitoring or polling service is used.
