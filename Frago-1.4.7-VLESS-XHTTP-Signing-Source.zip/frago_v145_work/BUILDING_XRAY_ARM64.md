# Building the ARM64 Xray-enabled APK

The app itself uses the legacy Gradle wrapper (Gradle 7.2 / Android Gradle Plugin 7.1.3) and Android SDK platform 31. Use JDK 11.

The Xray executable is not checked into this source archive. The GitHub Actions workflow downloads the official Android ARM64 Xray release, verifies its SHA-256, adds it as `app/src/main/jniLibs/arm64-v8a/libxray.so`, and runs `./gradlew clean assembleDebug`.

To build locally, perform the same download/checksum/unzip/copy steps from `.github/workflows/build-arm64-apk.yml`, then run:

```bash
./gradlew --no-daemon clean assembleDebug
```

The generated file is `app/build/outputs/apk/debug/app-debug.apk`. It is debug-signed for local installation/testing.
