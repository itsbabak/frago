## Privacy policy for Frago

Frago is a generic VPN application that connects to a SOCKS5 server specified by the user.
It doesn't connect to any other service, in particular it doesn't collect any data for the Frago developers.

As a VPN application Frago forwards all or some of the device's network traffic to the server specified,
so it is important that the user trusts this server. In particular if the server is maintained by a third-party
VPN provider, this provider will be able to read or modify data transmitted from any application using non-encrypted
protocols or block access to applications using encrypted protocols.
This is not specific to Frago, any VPN application has the same concerns.

Frago is [open source](https://github.com/bndeff/socksdroid), which makes it easier to review its security
by independent researchers.
