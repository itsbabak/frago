package net.typeblog.socks;

interface IVpnService
{
    boolean isRunning();
    boolean isStarting();
    boolean isStopping();
    String getLastError();
    void clearLastError();
    void stop();
}
