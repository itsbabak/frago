# Frago VLESS XHTTP and release signing notes

## VLESS XHTTP source support
- The VLESS URI parser now accepts `type=xhttp`.
- It reads `path`, `host`, `mode` (`auto`, `packet-up`, `stream-up`) and optional JSON `extra`.
- The generated Xray outbound includes `streamSettings.xhttpSettings`.

This is source-level configuration support. Runtime compatibility still depends on the exact Xray-core binary packaged by the build workflow and on the server's XHTTP configuration. The project ZIP does not contain the Xray executable; the workflow downloads it at build time. Validate with a matching server profile before distributing.

## Release APK signing
The previous project signed `release` builds with Android's debug key. This has been changed:
- Set `FRAGO_KEYSTORE`, `FRAGO_STORE_PASSWORD`, `FRAGO_KEY_ALIAS`, and `FRAGO_KEY_PASSWORD` in the build environment to sign release APKs with the owner's private key.
- If those variables are absent, the release APK is intentionally unsigned.
- Keep the keystore and passwords private and backed up. Use the same key for future updates, or Android will reject an in-place update.

A valid signature does not guarantee that Google Play Protect will suppress every warning. New or sideloaded apps may still show an unknown-source/reputation warning. Do not disable device security to install an APK.
